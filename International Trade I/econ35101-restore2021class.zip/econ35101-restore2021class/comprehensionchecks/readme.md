There are three comprehension checks.

1. Popular demand systems
2. Can there be immiserizing growth in the Armington model?
3. Open-economy growth models

Submit your completed checks via Canvas.