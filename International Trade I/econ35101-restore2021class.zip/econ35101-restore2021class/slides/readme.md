I am indebted to Arnaud Costinot, Dave Donaldson, and Ralph Ossa,
as my slides draw heavily from materials that they have kindly shared.

If you find typos or mistakes in the slides, please help me by correcting the relevant TeX file and submitting a pull request.
If you are unfamiliar with GitHub pull requests, please follow [these instructions](https://codeyourfuture.github.io/syllabus-scotland/others/making-a-pull-request.html) to create a fork, edit the relevant file, and then submit your pull request.