%% ch8_figure_3.m
% Compares outcomes in basic NK model under optimal commitment and
% discretion and a Taylor rule
clear all
close all
clc
%% run the dynare files
dynare NKM_optc_phi.dyn;   % optimal commentment
dynare NKM_optd_phi.dyn;   % optimal discretion using targeting rule

%% Transitory Cost Push Shock
savefig = 0;
niter = 2; %Number of different models 

load OOPT_NKM_optc_phi; % Optimal Commitment
load OOPT_NKM_optd_phi; % Optimal Discretion

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% IRFS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Persistent Cost Push Shock
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Obtaining the data
% Cost Shock
x_e_u_NKM_optc_phi = OOPT_NKM_optc_phi.irfs.x_e_u;
pi_e_u_NKM_optc_phi = OOPT_NKM_optc_phi.irfs.pi_e_u;
i_e_u_NKM_optc_phi = OOPT_NKM_optc_phi.irfs.i_e_u;
r_e_u_NKM_optc_phi = OOPT_NKM_optc_phi.irfs.r_e_u;
rn_e_u_NKM_optc_phi = OOPT_NKM_optc_phi.irfs.rn_e_u;
u_e_u_NKM_optc_phi = OOPT_NKM_optc_phi.irfs.u_e_u;

% NKM_optd
% Cost Push Shock
x_e_u_NKM_optd_phi = OOPT_NKM_optd_phi.irfs.x_e_u;
pi_e_u_NKM_optd_phi = OOPT_NKM_optd_phi.irfs.pi_e_u;
i_e_u_NKM_optd_phi = OOPT_NKM_optd_phi.irfs.i_e_u;
r_e_u_NKM_optd_phi = OOPT_NKM_optd_phi.irfs.r_e_u;
rn_e_u_NKM_optd_phi = OOPT_NKM_optd_phi.irfs.rn_e_u;
u_e_u_NKM_optd_phi = OOPT_NKM_optd_phi.irfs.u_e_u;

%%
n_imp=size(x_e_u_NKM_optd_phi(1,1:10),2);
t=1:1:n_imp;
nn=n_imp;
tt=t;
%%
figure('Name',['Orthogonalized shock to an iid Cost Shock']); 
%figure;
subplot(2,1,1);
handy1=plot(tt,pi_e_u_NKM_optc_phi(1,1:nn));
set(handy1(1,1),'Color','b');
set(handy1(1,1),'LineWidth',2);
set(handy1(1,1),'LineStyle','-');
set(handy1(1,1),'Marker','d');
set(handy1(1,1),'MarkerSize',10);
hold on;
handy2=plot(tt,pi_e_u_NKM_optd_phi(1,1:nn));
set(handy2(1,1),'Color','r');
set(handy2(1,1),'LineWidth',2.5);
set(handy2(1,1),'LineStyle','--');
set(handy2(1,1),'Marker','o');
set(handy2(1,1),'MarkerSize',8);
handy3=plot(tt,tt-tt,'k','LineWidth',1);
title('Inflation');
xlim([1 nn]);
set(gcf,'Position',[1 31 1024 664]);
legend('Optimal commitment','Optimal discretion');

hold on;
subplot(2,1,2)
handy1=plot(tt,x_e_u_NKM_optc_phi(1,1:nn));
set(handy1(1,1),'Color','b');
set(handy1(1,1),'LineWidth',2);
set(handy1(1,1),'LineStyle','-');
set(handy1(1,1),'Marker','d');
set(handy1(1,1),'MarkerSize',10);
hold on;
handy2=plot(tt,x_e_u_NKM_optd_phi(1,1:nn));
set(handy2(1,1),'Color','r');
set(handy2(1,1),'LineWidth',2.5);
set(handy2(1,1),'LineStyle','--');
set(handy2(1,1),'Marker','o');
set(handy2(1,1),'MarkerSize',8);
hold on;
title('Output Gap');
xlim([1 nn]);
grid on;
hold off
%%
figure('Name',['Orthogonalized shock to an iid Cost Shock']); 
handy1=plot(tt,4*pi_e_u_NKM_optc_phi(1,1:nn));
set(handy1(1,1),'Color','b');
set(handy1(1,1),'LineWidth',2);
set(handy1(1,1),'LineStyle','-');
set(handy1(1,1),'Marker','d');
set(handy1(1,1),'MarkerSize',10);
hold on;
handy2=plot(tt,4*pi_e_u_NKM_optd_phi(1,1:nn));
set(handy2(1,1),'Color','b');
set(handy2(1,1),'LineWidth',2.5);
set(handy2(1,1),'LineStyle','--');
set(handy2(1,1),'Marker','o');
set(handy2(1,1),'MarkerSize',8);
handy3=plot(tt,tt-tt,'k','LineWidth',1);
xlim([1 nn]);
set(gcf,'Position',[1 31 1024 664]);
%legend('Optimal commitment','Optimal discretion');

hold on;
handy3=plot(tt,x_e_u_NKM_optc_phi(1,1:nn));
set(handy3(1,1),'Color','r');
set(handy3(1,1),'LineWidth',2);
set(handy3(1,1),'LineStyle','-');
set(handy3(1,1),'Marker','d');
set(handy3(1,1),'MarkerSize',10);
hold on;
handy4=plot(tt,x_e_u_NKM_optd_phi(1,1:nn));
set(handy4(1,1),'Color','r');
set(handy4(1,1),'LineWidth',2.5);
set(handy4(1,1),'LineStyle','--');
set(handy4(1,1),'Marker','o');
set(handy4(1,1),'MarkerSize',8);
text(2.5,-2,'Output gap')
text(2.1,1,'Inflation')
text(2.1,1,'Inflation')
text(6,2,'Solid lines: Optimal commitment')
text(6,1.75,'Dashed lines: Optimal discretion')
hold on;

xlim([1 nn]);
grid on;

if savefig == 1;
    print -depsc2 'c:\Users\cewjl\Dropbox\4thedition\Chpt8\graphics_ch8\ch8_figure_3';
end
