%% ch11_figure_2.m
% Eggertsson and Woodford ZLB model
% 
% negative shock to natural real rate in period 1
% thereafter, probability q of exiting ZLB
% discretionary equilibrium (inflation and output at zero) after exit.
%
% See ZLB_future_inflation.tex (or pdf) in Courses\Lecture_Notes_Misc folder
clear all
savefig = 0; % = 1 to save figures
%% 
rbad = -0.05;
rnormal = 0.04;
pitarget = 0; %%0.02/4;
sigma = 1;
kappa = 0.15;
beta = 0.99;

%% q is probability of remaining at ZLB
q = 0.05:0.05:0.8;
q = q';
N = size(q,1);

for i=1:N
    A = [sigma*(1-q(i)) -q(i)
         kappa     -(1-beta*q(i))];
    B = [rbad 0]';
    z = A\B;
    zlb(i,:) = z';
end

%%
% output gap at zlb is zlb(:,1)
% inflation at zlb is zlb(:,2)
% plot(q,zlb)

%%
nk = kappa./(1-beta.*q);
x = -20:20;
x = 0.01*x';
M = size(x,1);
Q = 8;
K = 2;
pink1 = nk(Q)*x;
piis1 = (sigma*(1-q(Q))/q(Q))*x - (1/q(Q))*rbad*ones(M,1);
pink2 = nk(Q+K)*x;
piis2 = (sigma*(1-q(Q+K))/q(Q+K))*x - (1/q(Q+K))*rbad*ones(M,1);
[x pink1 pink2]
%pink3 = nk(Q)*x + 0.025;


%%
figure1 = figure
hold on
plot(x,pink1,'r','LineWidth',1.5)
plot(x,piis1,'b','LineWidth',1.5)
%plot(x,pink2,'rLineWidth',1.5)
%plot(x,piis2,'r:','LineWidth',1.5)
plot(x,x-x,'k','LineWidth',2)
text(0.125,0.1,'NKPC q=0.4')
text(0.11,0.4,'IS q=0.4')
%text(0.1,0.09,'NKPC q=0.5')
%text(0.125,0.17,'IS q=0.5')
xlabel('output gap')
ylabel('inflation rate')
annotation(figure1,'line',[0.519642857142857 0.519642857142857],...
    [0.106142857142857 0.919047619047619],'LineWidth',2);
hold off
if savefig == 1
    print -depsc2 'xzlb_pizlb_graph_base';
end
%%
figure2 = figure
hold on
plot(x,pink1,'r','LineWidth',1.5)
plot(x,piis1,'b','LineWidth',1.5)
plot(x,pink2,'r--','LineWidth',1.5)
plot(x,piis2,'b--','LineWidth',1.5)
plot(x,x-x,'k','LineWidth',2)
text(0.12,0.02,'NKPC q=0.4')
text(0.11,0.4,'IS q=0.4')
text(0.12,0.07,'NKPC q=0.5')
text(0.11,0.2,'IS q=0.5')
xlabel('output gap')
ylabel('inflation rate')
text(-0.14,-0.1,'Equilibrium with q = 0.4')
text(-0.17,0.1,'Equilibrium with q = 0.5')
annotation(figure2,'line',[0.519642857142857 0.519642857142857],...
    [0.106142857142857 0.919047619047619],'LineWidth',2);
% Create arrows
annotation('arrow',[0.342857142857143 0.326785714285714],...
    [0.249 0.290476190476191]);
annotation('arrow',[0.276785714285714 0.258035714285714],...
    [0.424 0.315476190476191]);
hold off
if savefig == 1;
    print -depsc2 'c:\Users\cewjl\Dropbox\4thedition\Chpt11\graphics_ch11\ch11_figure_2';
end
%%
skip = 0
if skip == 1
figure3 = figure
hold on
plot(x,pink1,'b','LineWidth',1.5)
plot(x,piis1,'b','LineWidth',1.5)
%plot(x,pink3,'r:','LineWidth',1.5)
%plot(x,piis2,'r:','LineWidth',1.5)
plot(x,x-x,'k','LineWidth',2)
text(0.1,0.025,'NKPC q=0.6')
text(0.05,0.25,'IS q=0.6')
%text(0.1,0.09,'NKPC q=0.5')
%text(0.125,0.17,'IS q=0.5')
xlabel('output gap')
ylabel('inflation rate')
annotation(figure3,'line',[0.519642857142857 0.519642857142857],...
    [0.106142857142857 0.919047619047619],'LineWidth',2);
hold off
end
%% 
%disp('Hit key to continue')
%pause

disp('type 2 equilibrium of Braun, Korbre and Waki, Atlanta Fed WP 20102-05a')
%% 
rbad = -0.05;
rnormal = 0.04;
pitarget = 0; %0.02/4;
sigma = 1;
kappa = 1.7; %0.24; %0.024;
beta = 0.99;

%% q is probability of remaining at zlb
q = 0.05:0.05:0.8;
q = q';
N = size(q,1);

for i=1:N
    A = [sigma*(1-q(i)) q(i)
         kappa   -(1-beta*q(i))];
    B = [rbad 0]';
    z = A\B;
    zlb(i,:) = z';
end

%%
% output gap at zlb is zlb(:,1)
% inflation at zlb is zlb(:,2)
%plot(q,zlb)

%%
nk = kappa./(1-beta.*q);
x = -20:20;
x = 0.01*x';
M = size(x,1);
Q = 8;
K = 0; %-2;
pink1 = nk(Q)*x;
piis1 = (sigma*(1-q(Q))/q(Q))*x - (1/q(Q))*rbad*ones(M,1)


%pink2 = nk(Q+K)*x + 0.05;
%piis2 = (sigma*q(Q+K)/(1-q(Q+K)))*x - (1/(1-q(Q+K)))*rbad*ones(M,1)

%%
figure5 = figure
hold on
plot(x,pink1,'r','LineWidth',1.5)
plot(x,piis1,'b','LineWidth',1.5)
%plot(x,pink2,'r:','LineWidth',1.5)
%plot(x,piis2,'r:','LineWidth',1.5)
plot(x,x-x,'k','LineWidth',2)
text(0.075,0.45,'NKPC q=0.4')
text(0.15,0.3,'IS q=0.4')
%text(0.1,0.09,'NKPC q=0.5')
%text(0.125,0.17,'IS q=0.5')
xlabel('output gap')
ylabel('inflation rate')
annotation(figure5,'line',[0.519642857142857 0.519642857142857],...
    [0.106142857142857 0.919047619047619],'LineWidth',2);
hold off

%%
if skip == 1
figure4 = figure
hold on
plot(x,pink1,'r','LineWidth',1.5)
plot(x,piis1,'b','LineWidth',1.5)
plot(x,pink2,'r:','LineWidth',1.5)
%plot(x,piis2,'r:','LineWidth',1.5)
plot(x,x-x,'k','LineWidth',2)
text(0.075,0.4,'NKPC q=0.4')
text(0.05,-0.1,'IS q=0.4')
%text(0.1,0.09,'NKPC q=0.5')
%text(0.125,0.17,'IS q=0.5')
xlabel('output gap')
ylabel('inflation rate')
annotation(figure4,'line',[0.519642857142857 0.519642857142857],...
    [0.106142857142857 0.919047619047619],'LineWidth',2);
hold off
end
%% Type 2 equilibrium

