%% zlb.m
%  files for Chapter 11 graphs illustrating equilibrium at the ZLB
clear all
close all
clc
%% parameters
sigma   = 1;
kappa   = 0.15;
beta    = 0.99;
rnzlb   = -0.05;
%% Serially uncorrelated demand shock
%  optimal discretion
% figures
x1 = -0.10:0.01:0.10; x1 = x1';
x = -0.13:0.01:0.13; x = x';
is = (1/sigma)*rnzlb;
z  = x - x;
pc1 = kappa*x1;

figure1 = figure
axes1 = axes('Parent',figure1);
hold(axes1,'on');

plot(x1,pc1,x,z,'k','LineWidth',2.0)
box(axes1,'on');
axis(axes1,'tight');
% Create line
annotation(figure1,'line',[0.367857142857143 0.367857142857143],...
    [0.112095238095238 0.921428571428571],'LineWidth',2,'Color',[1 0 0]);

% Create line
annotation(figure1,'line',[0.516964285714286 0.517857142857143],...
    [0.113285714285714 0.915476190476191],'LineWidth',2);

%axis([min(x)-0.03 max(x)+0.03 -0.06 0.06]);
%axis tight

%% Figure illustrating effects of probability q of remaining at ZLB
q = 0.01:0.01:1;

kappa = 0.15;
denom = sigma*(1-q).*(1 - beta*q)- kappa*q;
xzlb = rnzlb*(1 - beta*q)./denom;
pizlb = rnzlb*kappa./denom;

%%
N = 60;
figure3 = figure
plot(q(1:N),xzlb(1:N),'LineWidth',1.5); %q(1:N),pizlb(1:N),'b:'); %,q,pizlb,'LineWidth',1.5)
xlabel('probability of remaining at the ZLB (q)')
ylabel('output gap (x)')
print -depsc2 'q_x_graph';