%% Ch2_figure_3.m
%  Welfare costs of inflation as area under demand curve
%  Figure 3, Chapter 2, 4th edition
%  Carl E. Walsh, Monetary Theory and Policy
clear all
close all
clc
savefig = 0; % =1 to save figure to Ch2_figure_3.eps
%% Parameters of the money demand function, equation 33
%  Based on Chari, Kehoe, and McGrattan (2000)
a = 0.992; %0.9;
b = 2.56;
% note: in simulations, I use b = 9 from ireland (2009) and a = 0.9982 to
% be consistent with average real M1 to consumption ratio of 0.7811 for 1985:1-2014:12.
% 
% Money demand equation is m = (((1-a)/a)^(1/b))*((i/(1+i))^(-1/b))*c
%
% normalization
c = 1;

% range for nominal interest rate
incr = 0.0005;
ni = 0.00005:incr:0.10;   % zero to 10 percent
ni = ni';               % make ni a column vector
N = size(ni,1);
m = zeros(N,1);

d = (a/(1-a))^(1/b)*c;
m = d*((ni./(1+ni)).^(-1/b));

%% Nominal rate for r*
NN = (0.04/incr) + 1;
nistar = ni(NN);
mstar = d*((nistar/(1+nistar))^(-1/b));
rr = ni; %zeros(N,1);
rr(NN:N) = nistar;
[m ni rr];
rr2 = zeros(N,1);
rr2(NN:N,1) = nistar;


%% Chapter 2, figure 3 (money demand same as used in 3rd edition)
skip = 1;
if skip == 0
% This figure is not used in the fourth edition.
figure (1)
h = area(m,100*rr,'FaceColor',[0.75 0.75 0.75])
ylabel('Nominal interest rate (percent)')
xlabel('Real money balances')
axis([min(m) 60 0 8])
set(gca,'YTick',[0 2 4 6 8 ]);
set(gca,'YTickLabels',{'0' '2' 'i*' '6' '8' '10'})
set(gca,'XTickLabel',{'',''})
str = {'m(i*)'};
text(m(NN+6),-0.25,str);
% Create line
annotation('line',[0.25 0.25],...
    [0.515 0.11]);
%annotation('line',[0.25 0.251785714285714],...
%    [0.510904761904762 0.10952380952381]);

hold on
plot(m,100*ni,'k')
area(m,100*rr2,'FaceColor',[0.25 0.75 0.75])
hold off
end

%% Chapter 2, figure 3 (uses Ireland semi-log money demand)
% Nominal rate for r*
NN = (0.04/incr) + 1;
nistar2 = ni(NN);
mstar2 = exp(d - 20*b*((nistar2/(1+nistar2))));  %d*((nistar/(1+nistar))^(-1/b));
rr2 = ni; %zeros(N,1);
rr2(NN:N) = nistar2;
m2 = exp(d - 20*b*((ni./(1+ni))));
mm2 = zeros(N,1);
mm2(NN:N,1) = nistar2
%%

figure (2)
h = area(m2,100*rr2,'FaceColor',[0.75 0.75 0.75])
ylabel('Nominal interest rate (percent)')
xlabel('Real money balances')
axis([min(m2) 800 0 8])
set(gca,'YTick',[0 2 4 6 8 ]);
set(gca,'YTickLabels',{'0' '2' 'i*' '6' '8' '10'})
set(gca,'XTickLabel',{'',''})
str = {'m(i*)'};
text(m2(NN+6),-0.25,str);
% Create line
%annotation('line',[0.217857142857143 0.21875],...
%    [0.514476190476191 0.10952380952381]);
hold on
area(m2,100*mm2,'FaceColor',[0.5 0.5 0.5])
plot(m2,100*ni,'k')
hold off
if savefig == 1;
    print -depsc2 'C:\Users\cewjl\Dropbox\4thedition\Chpt2\graphics_ch2\Ch2_figure_3'
    %print -depsc2 '\graphics_ch2\Ch2_figure_3';
end

