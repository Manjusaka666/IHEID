%% Ch3_figures.m
%  
%  Runs the MIU simulations and generates figures 4-6
%  for Chapter 3, 4th edition
%  Carl E. Walsh, Monetary Theory and Policy
clear all
close all
clc

dynare cia_4e
