%% ch8_figure_2.m
% Compares outcomes in basic NK model under optimal commitment and
% discretion and a Taylor rule
clear all
close all
clc
%% run the dynare files
dynare NKM_optc.dyn;   % optimal commentment
dynare NKM_optd.dyn;   % optimal discretion using targeting rule

%% Transitory Cost Push Shock
savefig = 0;
niter = 2; %Number of different models 

load OOPT_NKM_optc; % Optimal Commitment
load OOPT_NKM_optd; % Optimal Discretion

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% IRFS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Persistent Cost Push Shock
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Obtaining the data
% Cost Shock
x_e_u_NKM_optc = OOPT_NKM_optc.irfs.x_e_u;
pi_e_u_NKM_optc = OOPT_NKM_optc.irfs.pi_e_u;
i_e_u_NKM_optc = OOPT_NKM_optc.irfs.i_e_u;
r_e_u_NKM_optc = OOPT_NKM_optc.irfs.r_e_u;
rn_e_u_NKM_optc = OOPT_NKM_optc.irfs.rn_e_u;
u_e_u_NKM_optc = OOPT_NKM_optc.irfs.u_e_u;

% NKM_optd
% Cost Push Shock
x_e_u_NKM_optd = OOPT_NKM_optd.irfs.x_e_u;
pi_e_u_NKM_optd = OOPT_NKM_optd.irfs.pi_e_u;
i_e_u_NKM_optd = OOPT_NKM_optd.irfs.i_e_u;
r_e_u_NKM_optd = OOPT_NKM_optd.irfs.r_e_u;
rn_e_u_NKM_optd = OOPT_NKM_optd.irfs.rn_e_u;
u_e_u_NKM_optd = OOPT_NKM_optd.irfs.u_e_u;

%%
n_imp=size(x_e_u_NKM_optd(1,1:10),2);
t=1:1:n_imp;
nn=n_imp;
tt=t;
%%
figure('Name',['Orthogonalized shock to an iid Cost Shock']); 
%figure;
subplot(2,1,1);
handy1=plot(tt,4*pi_e_u_NKM_optc(1,1:nn));
set(handy1(1,1),'Color','b');
set(handy1(1,1),'LineWidth',2);
set(handy1(1,1),'LineStyle','-');
set(handy1(1,1),'Marker','d');
set(handy1(1,1),'MarkerSize',10);
hold on;
handy2=plot(tt,4*pi_e_u_NKM_optd(1,1:nn));
set(handy2(1,1),'Color','r');
set(handy2(1,1),'LineWidth',2.5);
set(handy2(1,1),'LineStyle','--');
set(handy2(1,1),'Marker','o');
set(handy2(1,1),'MarkerSize',8);
handy3=plot(tt,tt-tt,'k','LineWidth',1);
title('Inflation');
xlim([1 nn]);
set(gcf,'Position',[1 31 1024 664]);
legend('Optimal commitment','Optimal discretion');
%grid on;

hold on;
subplot(2,1,2)
handy1=plot(tt,x_e_u_NKM_optc(1,1:nn));
set(handy1(1,1),'Color','b');
set(handy1(1,1),'LineWidth',2);
set(handy1(1,1),'LineStyle','-');
set(handy1(1,1),'Marker','d');
set(handy1(1,1),'MarkerSize',10);
hold on;
handy2=plot(tt,x_e_u_NKM_optd(1,1:nn));
set(handy2(1,1),'Color','r');
set(handy2(1,1),'LineWidth',2.5);
set(handy2(1,1),'LineStyle','--');
set(handy2(1,1),'Marker','o');
set(handy2(1,1),'MarkerSize',8);
hold on;
title('Output Gap');
xlim([1 nn]);
%grid on;

if savefig == 1;
    print -depsc2 'c:\Users\cewjl\Dropbox\4thedition\Chpt8\graphics_ch8\ch8_figure_2';
end
