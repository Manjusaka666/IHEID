%% ch11_figure_3_4_5.m
%  Based on \ZLB\commitment_zlb.m but made consistent with notation of
%  Chapter 11, 4th edition.
%  ZLB binds from  t to t+T-1.
%  Assumes path of nominal rate is equal to 0 until t = t+ S => T-1 and then equal to
%  r(t) + delta*(pi(t) - pi*(t)) after that point where delta satisfies the Taylor Principle. 
%
%  Derives equilibrium for t-q to t+T+q for "arbitrary" values for x(T) and
%  pi(T) -- these values must be consistent with NKPC.
%
% See Werner, NBER 17344, August 2011
% See Cochrane, NBER, 2014

clear all
close all
clc
savefig = 0; % = 1 to save figures
%% housekeeping
T       = 11;
q       = 4;       % so ZLB binds beginning in T - q = period 5 and binds for 
                   % t = 5, 6, 7, 8, 9, i.e., for q-1 periods
S       = 0;       % nominal rate zero from T-q to T+S
t       = 1:2*T-1; % so t = 1,....,21
t       = t';
d       = t - T ;  % so d = -10,...10, ZLB will bind from d = -5  to d = -1
N       = size(t,1);
r       = zeros(size(t,1),1);
x       = zeros(size(t,1),1);
pi      = zeros(size(t,1),1);
x1      = x;
pi1     = pi;
pistar  = pi;
xstar   = x;
z       = x;
z1      = x;
z2      = x;
ni      = r;

%% parameters   
sig     = 1;
beta    = 0.99;
eta     = 1;
w       = 0.75;  % Calvo parameter
kappa   = (1-w)*(1-beta*w)*(sig+eta)/w;
delta   = 1.5;   % Taylor parameter
rho     = 0.;    % decay of pi*
rn      = 0.01;
rnzlb   = -0.01;

%% Model
% When ZLB does not bind:
% x(t)  = x(t+1) - (1/sig)*(ni(t) - pi(t+1) - r(t)
% pi(t) = beta*pi(t+1) + kappa*x(t)
%
% Z(t) = [x(t) pi(t)]'
%
% [1  1/sig; 0 beta]*Z(t+1) = [1 0; -kappa 1]*Z(t) + [(1/sig) ; 0]*(ni(t) - r(t))
%  A*Z(t+1) = B*Z(t) +C*(ni(t) - r(t))
%  Z(t+1) = D*Z(t) + E*(ni(t) - r(t))
A = [1  1/sig; 0 beta];
B = [1 0; -kappa 1];
C = [(1/sig) ; 0];
D = A\B;
E = A\C;
%
% [1 0; -kappa 1]*Z(t) = [1  1/sig; 0 beta]*Z(t+1) - [(1/sig) ; 0]*(ni(t) - r(t))
% B*Z(t) = A*Z(t+1) - C((ni(t) - r(t))
% Z(t) = F*Z(t+1) - G*(ni(t)-r(t))
F = B\A;
G = B\C;

%% Specify path for r, i, and values for x(T), pi(T), pi*(t) and x*(t) for t => T
%  ZLB binds until t+T-1 and then ni = r + delta*pi(t) for t+T on
% So from t+T on, x = pi = 0 and  ni = r;
for i = 1:size(t,1);
    if i >= T-q && i < T;
        r(i) = rnzlb;
    else
        r(i) = rn;
    end
end
%% For S = 0

for i = 1:size(t,1);
    if i >= T-q && i < T+S;
        ni(i) = 0;
    else
        ni(i) = r(i);
    end
end

%% Equilibrium once rates increased
for j = T+S:size(t,1);
    pi(j)       = 0;
    x(j)        = 0;
end

%% Equilibrium from  T-q to t+T+S when S = 0 is the standard discretionary case
% See equation fg111 of chapter 11, 4th edition
% start of ZLB is T-q
    
z = zeros(2,size(x,1));
for j = 2:N+1-T+q
    z(:,N+1-j) = F*z(:,N+2-j) - G*(ni(N+1-j) - r(N+1-j));
end
[z' ni-r];

xzlb = z(1,:)';
pizlb = z(2,:)';

%% start of ZLB is T-(q+1) (i.e., one period sooner)
z = zeros(2,size(x,1));
for j = 2:N+1-T+q+1
    z(:,N+1-j) = F*z(:,N+2-j) - G*(ni(N+1-j) - r(N+1-j));
end
xzlb2 = z(1,:)';
pizlb2 = z(2,:)';

%%
figure1 = figure(1)
    plot(d,xzlb,'b',d,pizlb,'r:',d,d-d,'k','LineWidth',1.25)
    hold on
    plot(d,xzlb2,'bo-',d,pizlb2,'ro:',d,d-d,'k','LineWidth',1.25,'MarkerSize',5)
    %plot(d,100*xzlb,d,400*pizlb,d,100*xzlb2,'b:',d,400*pizlb2,'r:',d,400*ni,'k',d,400*r,'k:','LineWidth',1.25)
    axis([min(d) max(d) -.1 .1])
    % Create line
    annotation(figure1,'line',[0.51754 0.51754],[0.111 0.924],'LineWidth',1.25);
    text(1.7,.04,'ELB binds for 4 periods')
    text(-8,-.09,'ELB binds for 5 periods')
    % Create arrow
    annotation(figure1,'arrow',[0.216071428571429 0.2875],...
    [0.177571428571429 0.383333333333333]);
    % Create arrow
    annotation(figure1,'arrow',[0.563392857142857 0.35],...
    [0.668047619047619 0.457142857142857]);
    %annotation(figure1,'arrow',[0.563392857142857 0.35],...
    %[0.668047619047619 0.457142857142857]);
    legend('output gap','inflation rate')
    ylabel('Percent')
    hold off
if savefig == 1
    if S == 0
        print -depsc2 'c:\Users\cewjl\Dropbox\4thedition\Chpt11\graphics_ch11\ch11_figure_3';
    end            
end

%% S = 1
S = 1;
for i = 1:size(t,1);
    if i >= T-q && i < T+S;
        ni1(i) = 0;
    else
        ni1(i) = r(i);
    end
end

%% Equilibrium once rates increased
for j = T+S:size(t,1);
    pi(j)       = 0;
    x(j)        = 0;
end

%% Equilibrium from  T-q to t+T+S when S = 0 is the standard discretionary case
% See equation fg111 of chapter 11, 4th edition
% start of ZLB is T-q
    
z = zeros(2,size(x,1));
for j = 2:N+1-T+q
    z(:,N+1-j) = F*z(:,N+2-j) - G*(ni1(N+1-j) - r(N+1-j));
end
[z' ni-r];

xzlbS1 = z(1,:)';
pizlbS1 = z(2,:)';


%% S = 2
S = 2;

for i = 1:size(t,1);
    if i >= T-q && i < T+S;
        ni2(i) = 0;
    else
        ni2(i) = r(i);
    end
end

%% Equilibrium once rates increased
for j = T+S:size(t,1);
    pi2(j)       = 0;
    x2(j)        = 0;
end

%% Equilibrium from  T-q to t+T+S when S = 0 is the standard discretionary case
% See equation fg111 of chapter 11, 4th edition
% start of ZLB is T-q
    
z = zeros(2,size(x,1));
for j = 2:N+1-T+q
    z(:,N+1-j) = F*z(:,N+2-j) - G*(ni2(N+1-j) - r(N+1-j));
end
[z' ni-r];

xzlbS2 = z(1,:)';
pizlbS2 = z(2,:)';

%%
figure2 = figure(2)
    plot(d,xzlb,'b',d,pizlb,'r--',d,xzlbS2,'bo-',d,pizlbS2,'r--o',d,d-d,'k','LineWidth',1.25,'MarkerSize',4)
    %plot(d,100*xzlb,d,400*pizlb,d,100*xzlb2,'b:',d,400*pizlb2,'r:',d,400*ni,'k',d,400*r,'k:','LineWidth',1.25)
    axis([min(d) max(d) -.1 .1])
    % Create line
    annotation(figure2,'line',[0.51754 0.51754],[0.111 0.924],'LineWidth',1.25);
    text(-4,.03,'i = 0 for two periods after ELB no longer binds')
    text(-4,-.065,'i = r as soon as ELB no longer binds')
    % Create arrow
    %annotation(figure2,'arrow',[0.216071428571429 0.2875],...
    %[0.177571428571429 0.383333333333333]);
    % Create arrow
    %annotation(figure2,'arrow',[0.563392857142857 0.35],...
    %[0.668047619047619 0.457142857142857]);
    legend('output gap','inflation rate')
    ylabel('Percent')

if savefig == 1
    if S == 2
       print -depsc2 'c:\Users\CEW\Dropbox\4thedition\Chpt11\graphics_ch11\ch11_figure_4'; 
    end
end

%%
skip = 1;
if skip == 0
%% Now ni is kept at zero until T+S
S1 = 1;
S2 = 2;
q = q-1;
%% Equilibrium from  t to t+T when S = T as under discretion
% See equation fg111 of chapter 11, 4th edition
B = [1 1/sig; kappa beta+kappa/sig];
% start of ZLB is T-q
z1 = zeros(2,size(x,1));
z2 = zeros(2,size(x,1));
z1(:,T) = B*[0 0]' + (1/sig)*[1 kappa]'*r(T)';
z2(:,T+1) = B*[0 0]' + (1/sig)*[1 kappa]'*r(T+1)';
z2(:,T) = B*z2(:,T+1) + (1/sig)*[1 kappa]'*(z2(2,T+1)+r(T))';
%%
for j = 1:T-1-q
    z1(:,T-j) = B*z1(:,T-j+1) + (1/sig)*[1 kappa]'*r(T-j)';
    z2(:,T-j) = B*z2(:,T-j+1) + (1/sig)*[1 kappa]'*r(T-j)';
end
xzlb3 = z1(1,:)';
pizlb3 = z1(2,:)';
xzlb4 = z2(1,:)';
pizlb4 = z2(2,:)';

%%
figure2 = figure
plot(d,xzlb,'b',d,pizlb,'r:',d,xzlb4,'b',d,pizlb4,'r:',d,d-d,'k','LineWidth',1.25)
%plot(d,100*xzlb2,d,400*pizlb2,'r:',d,100*xzlb3,'b',d,400*pizlb3,'r:',d,xzlb4,'b',d,pizlb4,'r:',d,d-d,'k','LineWidth',1.25)
%plot(d,100*xzlb,d,400*pizlb,d,100*xzlb2,'b:',d,400*pizlb2,'r:',d,400*ni,'k',d,400*r,'k:','LineWidth',1.25)
axis([min(d) max(d) -.1 .1])
% Create line
annotation(figure2,'line',[0.51754 0.51754],[0.111 0.924],'LineWidth',1.25);
legend('output gap','inflation rate')
text(-5,.04,'i = 0 for two periods after ZLB no longer binds')
text(-3,-.06,'i = r when ZLB no longer binds')
% Create arrow
%annotation(figure1,'arrow',[0.216071428571429 0.2875],...
%    [0.177571428571429 0.383333333333333]);
% Create arrow
%annotation(figure1,'arrow',[0.563392857142857 0.35],...
%    [0.668047619047619 0.457142857142857]);
ylabel('Percent')
if savefig == 1
    print -depsc2 'fig_fg_ch11';
end
end
%% Cochrane (2015) in discrete time
%  pistar(T) is a free parameter set to pick the equilibrium where T is the
%  exit time from the ZLB
%  code below from \ZLB\commitment_zlb.m

%% Specify matrices for solving for t => T
% Z* = [x* pi*]'
% A*Z*(t+1) = B*Z*(t)
A = [1 1/sig; 0 beta];
B = [1 0; -kappa 1];
%   Z*(t+1) = C*Z*(t)
M   = A\B;
[V L] = eig(M);
%%
K   = inv(V);
L1  = L(1,1);
L2  = L(2,2);


%% Constructing the equilibrium for t => T
for s = 1:1:3;
xstar = zeros(3,size(t,1))';
pistar = xstar;
%%
Z  = [xstar(:,s)  pistar(:,s)]';
z1 = Z(:,1);
z2 = Z(:,2);
% choice of inflation rate on exit
pistar(T,s) = 0 + (s-1)*0.005;
xstar(T,s)  = -(K(1,2)/K(1,1))*pistar(T,s);
Z(:,T)    = [xstar(T,s) pistar(T,s)];
z2(T) = K(2,1)*xstar(T,s) + K(2,2)*pistar(T,s);
% Solve for equilibrium from T+1 to N, given pistar(T) and xstar(T)
for j = T+1:1:N
    z2(j)  = (L2^(j-T))*z2(T);
    Z(:,j) = V*[0; z2(j)]
end

% Solve backwards from T
% Z*(t) = B(-1)*A*Z*(t+1) + S*r^ZLB
%       = Q*Z*(t+1) + S*r^ZLB
Q = B\A;
S = [1/sig ; kappa/sig];
%
for i = 1:1:q;
    Z(:,T-i) = Q*Z(:,T-i+1) + S*rnzlb;
end
%if s == 1;
    xstareq(:,s) = Z(1,:)';
    pistareq(:,s) = Z(2,:)';
%end
%if s == 2;
%    xstareq2 = Z(1,:)';
%    pistareq2 = Z(2,:)';
%end
end; % loop over s, different pistar(T) values
%% figure of equilibrium for pistar(T) given
%xstareq = zeros(1,size(t,1))';
%pistareq = xstareq;

fig_cochrane(d,[pistareq xstareq d-d])
if savefig == 1
       print -depsc2 'c:\Users\CEW\Dropbox\4thedition\Chpt11\graphics_ch11\ch11_figure_5'; 
end
%%
skip = 1;
if skip == 0
figure3 = figure
hold on
plot(d,xstareq(:,1),'b',d,pistareq(:,1),'r','LineWidth',1.25);
plot(d,xstareq(:,2),'b:',d,pistareq(:,2),'r:','LineWidth',1.25);
plot(d,xstareq(:,3),'b--',d,pistareq(:,3),'r--','LineWidth',1.25);
%plot(d,xstareq1,'b',d,pistareq1,'r',d,xstareq2,'b:',d,pistareq2,'r:','LineWidth',1.25);
plot(d,d-d,'k','LineWidth',1.5)
legend('\pi*(T) = 0','\pi*(T) = 0.005','\pi*(T) = 0.01')
hold off

%% old stuff from \Matlab\ZLB\commitment_zlb.m

B1  = [1 0 ; -k 1]; % Will pick x(T) consistent with pi(T) to zero out explosive root
K   = inv(B1);
D   = A\B1;
H   = B1\A;
abs(eig(C))
abs(eig(D))
[V L] = eig(D)
IV = inv(V);
% So Z(t+1) = D(Z(t) ==> inv(V)*Z(t+1) = L*inv(V)*Z(t) ==> z(t+1) = L*z(t)
% Need z_1(t) = 0 so explosive first root becomes z_1(t+1) = L(1)*z_1(t) = 0;
% This requires iv(1,1)*x(T) + iv(1,2)*pi(T) = 0 where iv(i,j) is i,jth element of inv(V)
%%
pistar(T)   = 0.0015;
xstar(T)    = -IV(1,2)*pistar(T)/IV(1,1); %(1-beta*rho)*(1/k)*pistar(T); %k*pi(T)/(1-beta);
x1(T) = xstar(T);
pi1(T) = pistar(T);
z1(T) = IV(1,1)*x1(T) + IV(1,2)*pi1(T);
z2(T) = IV(2,1)*x1(T) + IV(2,2)*pi(T);

%% For t > T

% Z(T+i+1) = C*Z(T+i) for i = 0,1,...size(t,1)
i   = 0;
while i < S ; %size(t,1)-1
    %z = [x(i) pi(i)]';
    %z = C*z;    
    %x(i+1) = z(1);
    %pi(i+1) = z(2);
    %z1 = [x1(i) pi1(i)]';
    %z1 = C*z1 - H*[(1/s)*delta 0]'*pistar(i) ;
    %x1(i+1) = z1(1);
    %pi1(i+1) = z1(2);
    %x1(i) = xstar(i);
    %pi1(i) = pistar(i);
    %x1(i+1) = x(i) + (1/s)*(delta - rho)*pi1(i) - (delta/s)*pistar(i);
    %pi1(i+1) = (
    z1(T+i+1)   = 0;
    z2(T+i+1) = L(2,2)*z2(T+i); 
    X = V*[z1(T+i+1) z2(T+i+1)]';
    x1(T+i+1) = X(1);
    pi1(T+i+1) = X(2);
    i = i + 1;
end
%% Solving backwards from T
% A*Z(t+1) = B*Z(t) - (delta/s)*pistar(t)
% inv(B)*A*Z(t+1) = Z(t) - inv(B)*(delta/s)*pistar(t)
%            Z(t) = D*Z(t+1) + K*[(delta/s) 0]'*pistar(t)
% for i = T-1, T-2< T-3, .....1
i       = 0;
while i < q; %T-q-1;
    zz = H*[x(T-i) pi(T-i)]' + (1/sig)*K*[r(T-1-i) 0]';
    x(T-i-1)    = zz(1);
    pi(T-i-1)   = zz(2);
    zz1 = H*[x1(T-i) pi1(T-i)]' + (1/sig)*K*[r(T-1-i) 0]';
    x1(T-i-1)    = zz1(1);
    pi1(T-i-1)   = zz1(2);
    i = i + 1;
end
%%
[d(T-q:T+q) pi(T-q:T+q) x(T-q:T+q) pi1(T-q:T+q) x1(T-q:T+q) r(T-q:T+q) ni(T-q:T+q)];
%%
dd = d-d;
o  = ones(size(d,1),1);
figure(3)
plot(d,x,'b',d,pi,'r',d,dd,'k',dd,d,'k',(S+1-T-q)*o,d,'k','LineWidth',1.3)
axis tight
legend('x: discretion', '\pi: discretion')
axis([-Inf Inf -.05 .05])
text(-6,.03,'Period of ZLB')
%%
figure(4)
plot(d,x,'b',d,pi,'r',d,x1,'b:',d,pi1,'r:',d,dd,'k',dd,d,'k',(S+1-T-q)*o,d,'k','LineWidth',1.3)
axis tight
legend('x: discretion', '\pi: discretion', 'x^*', '\pi^*')
axis([-Inf Inf -.05 .05])
text(-6,.03,'Period of ZLB')
text(1,-0.02,'Both equilibrium involve same')
text(1,-0.025,'path for the nominal interest rate')
 
%%
figure(5)
plot(d,x,'b',d,pi,'r',d,x1,'b:',d,pi1,'r:',d,ni,'ko-',d,dd,'k',dd,d,'k',(S+1-T-q)*o,d,'k','LineWidth',1.3)
axis tight
legend('x: discretion', '\pi: discretion', 'x^*', '\pi^*', 'i')
axis([-Inf Inf -.05 .05])
text(-6,.03,'Period of ZLB')
text(1,-0.02,'Both equilibrium involve same')
text(1,-0.025,'path for the nominal interest rate')
 
%%
end

    
    
    

