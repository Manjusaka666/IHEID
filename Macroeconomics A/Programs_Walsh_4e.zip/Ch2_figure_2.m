%% Ch2_figure_2.m
%  Equilibrium with fixed nominal moneyy supply
%  Figure 2, Chapter 2, 4th edition
%  Carl E. Walsh, Monetary Theory and Policy
% See Figure 4-3 equilibrium with fixed m.xlsx from Ch. 4, 3rd edition.
clear all
close all
clc
savefig = 0; % =1 to save figure to Ch2_figure_1.eps
%% Parameters of the money demand function, equation 23
a = 0.5;
phi = 1;
theta = 0.05;
beta = 0.95;
b = 1;
muc = 5;
M = 1;
N = 100;
dd = 1:N; dd = dd';
incre = 0.01;
p = zeros(N,1);
p(1) = -.1;
for i = 2:N
    p(i) = p(i-1) + incre;
end

%pf = (beta*muc./(muc - phi.*(p.^a)/(M^a))).*p;
%%
% figure 2.2
%plot(p,p,p,pf)

%%
a = -0.0252;
b = 1;
c = 7;
pstar = 0.03;
r = 0.03;
rp = r + p;
g = a + b.*(p - pstar) + c.*(p - pstar).^2 + r + pstar;
[dd p rp g]

%% figure 2, chapter 2, 4th edition
ST = 8;
figure(1)
plot(rp(ST:N),rp(ST:N),'k:',rp(ST:N),g(ST:N),'r','LineWidth',1.5)
axis([0 .275 0 .275]); % square; %tight
set(gca,'XTickLabel',{'',''})
set(gca,'YTickLabel',{'',''})
text(0.14,0.23,'\phi(P_t)')
text(0.2,-0.01,'P_t')
text(-0.025,0.25,'P_{t+1}')
text(0.115,-0.01,'P*')
text(0.148,-0.01,'P_0')
% Create lines
annotation('line',[0.47 0.47],[0.47 0.11]); 
annotation('line',[0.55 0.55],[0.64 0.11]);
% Create arrow
annotation('arrow',[0.55 0.64],[0.64 0.64]);
annotation('arrow',[0.64 0.64],[0.64 0.86]);
annotation('arrow',[0.64 0.76],[0.86 0.86]);

if savefig == 1;
    print -depsc2 'Ch2_figure_2';
end