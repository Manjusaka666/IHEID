%% ch11_figure_6.m
%  Program to generate plots of Federal Reserve balance sheet
%
% Used for chapter 11 figures
%  fbs_ch11.m
% OLD VERSION USE fbschart.m TO CORRECTLY IMPORT DATA
clear all

%% Import data
% Import the data, extracting spreadsheet dates in MATLAB serial date number format (datenum)
[~, ~, raw, dateNums] = xlsread('C:\Users\cewjl\Dropbox\4thedition\Chpt11\Programs_ch11\BalanceSheetChartData_4thedition.xlsx','Data','A2:F476','',@convertSpreadsheetDates);

% Replace date strings by MATLAB serial date numbers (datenum)
R = ~cellfun(@isequalwithequalnans,dateNums,raw) & cellfun('isclass',raw,'char'); % Find spreadsheet dates
raw(R) = dateNums(R);

% Create output variable
data = reshape([raw{:}],size(raw));

% Allocate imported array to column variable names
Date = data(:,1);
TraditionalSecurity = data(:,2);
LongTermTreasury = data(:,3);
LendingtoFinancialInstitu = data(:,4);
LiquiditytoKeyMarkets = data(:,5);
FedAgencyDebtMortgageDebt = data(:,6);

% Clear temporary variables
clearvars data raw dateNums R;
%% Rename
Traditional = TraditionalSecurity;
Lending = LendingtoFinancialInstitu;
Liquidity = LiquiditytoKeyMarkets;
LTTP = LongTermTreasury;
MBS = FedAgencyDebtMortgageDebt;

%% colors
Fig1 = [0.1 0.8 0.4; 0.5 0.9 0.6];
%% figures
figure(1)
area1 = area(Date,[Traditional Lending+Liquidity ]); %colormap('winter');
set(area1(1),'FaceColor',[0.2 0.2 0.9],'DisplayName','Traditional Security holdings');
set(area1(2),'FaceColor',[0.2 0.4 0.7],'DisplayName','Lending to financial inst.+Liquidity');
%set(area1(3),'FaceColor',[0.2 0.6 0.5],'DisplayName','Liquidity provision');
%area(daten,unc1,'Facecolor',[.5 .5 .6])
datetick('x',12)
%hold on 
%area(daten,unc1(:,2),'Facecolor',[.9 .85 .7])
%hold off
%axis('tight')
axis([-Inf Inf 0 5000000])
ylabel('billions of $')
title('Conventional policies')
legend('Traditional Security holdings','Lending to financial inst. + Liquidity provision')


%%
figure(2)
area1 = area(Date,[Traditional Lending+Liquidity MBS LTTP]); colormap('winter');
%area(Date,[Traditional+Lending+Liquidity MBS LTTP],'FaceColor',[0.9 0.9 0.2]); %colormap('default');
set(area1(1),'FaceColor',[0.2 0.2 0.9],'DisplayName','Traditional Security holdings');
set(area1(2),'FaceColor',[0.2 0.4 0.7],'DisplayName','Lending to financial inst.+Liquidity');
%set(area1(3),'FaceColor',[0.2 0.6 0.5],'DisplayName','Liquidity provision');
set(area1(3),'FaceColor',[0.2 0.8 0.3],'DisplayName','Mortgage Backed Securities');
set(area1(4),'FaceColor',[0.2 0.95 0.1],'DisplayName','L-T Treasuries');
datetick('x',12)
axis([-Inf Inf 0 5000000])
%axis([min(Date) 735488 0 4000000])
%set(gca,'XTick',[Date(1) Date(24) Date (36) Date(48)])
%set(gca,'XTick',[datenum('01-Jan-2008') datenum('01-Jan-2010') datenum('01-Jan-2012') datenum('01-Jan-2014')])
%set(gca,'XTickLabel','01-Jan-2008|01-Jan-2010|01-Jan-2012|01-Jan-2014')

ylabel('billions of $')
%title('The conventional and unconventional parts')
legend('Traditional Security holdings','LOLR',....
    'Mortgage Backed Securities','L-T Treasuries')
%    'Liquidity provision','Mortgage Backed Securities','L-T Treasuries')
print -depsc2 'FRB_balance_sheet';

