%% ch8_figure_1.m
%  generates figure 1 of chapter 8, 4th edition
clear all
close all
clc
savefig = 0;
%%
dynare NKM_figure1

%% figure 8.1
%  response to a policy shock
output      = [0 ; x_e_v];
inflation   = [0 ; pi_e_v];
ni          =  [0 ; i_e_v];
r           =  [0 ; r_e_v];
%%
periods = -1:1:size(output,1)-2;
periods = periods';
%%
figure(1)
plot(periods,output,'-',periods,inflation,'--',periods,ni','r-o',periods,r,'b:*','LineWidth',1.3)
axis([-1 11 -1.75 1.25])
hold on
plot(periods,zeros(size(periods,1),1),'k','LineWidth',1.2)
%text(1.5,-0.75,'Output gap','FontSize',9)
%text(0.5,0.75,'Real interest rate','FontSize',9)
%text(2.0,0.5,'Nominal interest rate','FontSize',9)
%text(2.0,-0.4,'Inflation','FontSize',9)
xlabel('periods')
legend('Output gap','Inflation','Nominal interest rate','Real interest rate')
%%
if savefig == 1;
    print -depsc2 'c:\Users\cewjl\Dropbox\4thedition\Chpt8\graphics_ch8\ch8_figure_1';
end

