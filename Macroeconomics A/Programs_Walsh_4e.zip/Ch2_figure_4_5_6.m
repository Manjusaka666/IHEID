%% Ch2_figure_4_5_6.m
%  
%  Runs the MIU simulations and generates figures 4-6
%  for Chapter 2, 4th edition
%  Carl E. Walsh, Monetary Theory and Policy
clear all
close all
clc

dynare miu_4e
