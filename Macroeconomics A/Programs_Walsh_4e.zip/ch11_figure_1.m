%% ch11_figure_1.m
%  Program to generate plots Fisher eq. and Taylor rule
%
% Used for chapter 11 figure 1
clear all
close all
clc
savefig = 0;
%% parameters
phi     = 1.5; % response to inflation in the policy rule
r       = 0.02
pi      = -0.03:0.0033:0.08;
pi      = pi';
pistar  = 0.02;
line45  = pi;
pi1     = pistar + phi*(pi - pistar);
pi2     = -r*ones(size(pi,1),1);

for i = 1:size(pi,1)
    if pi1(i)-pi2(i) <= 0;
        N = i;
    end
end 
[pi1 pi2]
%%
for i = 1:N-1
    pi1(i) = nan;
end
for i = N+1:size(pi,1)
    pi2(i) = nan;
end

[pi1 pi2]
%% Plot
figure(1)
plot(pi,pi1,'r',pi,line45,'k--','LineWidth',1.3)
hold on
plot(pi,pi-pi,'k','LineWidth',1.3)
plot(pi,pi2,'r','LineWidth',1.3)
annotation('line',[0.415 0.415],[0.106 0.921],'LineWidth',2);
axis([-0.035 0.06 -0.035 0.06])
set(gca,'XTickLabel',{'',''})
set(gca,'YTickLabel',{'',''})

% Create line
annotation('line',[0.250892857142857 0.251785714285714],...
    [0.241857142857143 0.40952380952381],'LineWidth',1);

annotation('line',[0.4875 0.488392857142857],...
    [0.407142857142857 0.439285714285714],'LineWidth',1);

annotation('arrow',[0.485745614035088 0.447848788638262],...
    [0.440149625935162 0.440701816886356]);

annotation('arrow',[0.446063074352548 0.446637426900585],...
    [0.439511340695879 0.372817955112219]);

annotation('arrow',[0.447002923976608 0.387061403508772],...
    [0.376182044887781 0.372817955112219]);

annotation('line',[0.576785714285714 0.575292397660819],...
    [0.575190476190476 0.407107231920199],'LineWidth',1);
text(0.05,-0.005,'\pi(t)','FontSize',10)
text(-0.012,0.05,'\pi(t+1)','FontSize',10)
text(-0.021,0.0025,'\pi**')
text(0.008,-0.0025,'\pi_0')
text(0.02,-0.0025,'\pi*')
text(0.04,0.035,'45^o line')
hold off

if savefig == 1;
    print -depsc2 'c:\Users\cewjl\Dropbox\4thedition\Chpt11\graphics_ch11\ch11_figure_1';
end
