%% figures2_3_loss.m
%  calculates loss associated with the discretionary and committment
%  solutions illustrated in figures 2 and 3 of chaptre 8, 4th edition.
clear all
%% parameters
beta    = 0.99;
kappa   = 0.05;
lambda  = 0.25;
rho     = 0.0;

%% discretion
% pi = bpi*e
bpi     = lambda/(lambda*(1-beta*rho)+kappa^2);
bx      = -kappa/(lambda*(1-beta*rho)+kappa^2);
varxd   = bx^2'
varpid  = bpi^2;
lossd   = varpid + lambda*varxd;
%% commitment
CX      = [beta -(1+beta+ (kappa^2)/lambda) 1];
ax      = min(roots(CX));
cx      = -kappa/(lambda*(1 + beta*(1-rho-ax))+kappa^2);
cpi     = (lambda/kappa)*cx;
varxc   = (cx^2)/(1 - (ax^2));
varpic  = ((lambda/kappa)^2)*((1-ax)^2)*varxc + cpi^2;
lossc   = varpic + lambda*varxc;

disp('Loss under discretion and commitment and % gain from commitment')
[lossd lossc -100*(lossc - lossd)/lossd]
