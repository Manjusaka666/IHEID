%% Ch2_figure_1.m
%  Steady-state real money balances
%  Figure 1, Chapter 2, 4th edition
%  Carl E. Walsh, Monetary Theory and Policy
clear all
close all
clc
savefig = 0; % =1 to save figure to Ch2_figure_1.eps
%% Parameters of the money demand function, equation 23
a = 0.5;
phi = 1;
theta = 0.05;
beta = 0.95;
b = 1;
muc = 5;
N = 30;
dd = 1:N; dd = dd';
incre = 0.005;
m = zeros(N,1);
m(1) = 0.0000001;
for i = 2:N
    m(i) = m(i-1) + incre;
end

%% equation 23
% the function A(m(t)) = [muc - mum(t)]*m(t)
A = (muc - phi*m.^(-a)).*m;
% B(m(t+1)) = (beta/(1+theta))*muc*m(t+1) = A(m(t))
B = ((beta)/(1+theta)).*m;
d = ((beta*muc)/(1+theta));
C = A/d;
[ dd A B]
%% figure 1, chapter 2, 4th edition
figure (1)
plot(m,m-m,'k',m,A,m,B,'r:','LineWidth',1.5)
axis([0 max(m) -0.1 0.2])
set(gca,'XTickLabel',{'',''})
set(gca,'YTickLabel',{'',''})% Create text
text(0.02,-0.05,'A(m)');
text(0.08,0.06,'B(m)');
text(0.04,-0.01,'m"');
text(0.0578,-0.01,'m*');
text(0.13,-0.01,'m(t)');
% Create arrow
annotation('arrow',[0.532142857142857 0.532142857142857],...
    [0.377571428571429 0.647619047619048]);
% Create arrow
annotation('arrow',[0.5325 0.6975],...
    [0.650510204081633 0.650510204081633]);
% Create arrow
annotation('arrow',[0.699553571428571 0.699375],...
    [0.64806462585034 0.89030612244898]);
% Create line
annotation('line',[0.444642857142857 0.444375],...
    [0.522809523809524 0.378826530612245]);

if savefig == 1;
    print -depsc2 'Ch2_figure_1';
end