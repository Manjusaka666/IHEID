%simu_welf.m
%Compute the probability distribution of the  welfare cost of a currency peg 
%in the  tradable-endowment,  open economy with  downward nominal wage rigidity and a currency peg
%studied in the chapter ``Nominal Rigidity, Exchange Rates,  And Unemployment'' of the book Open Economy Macroeconomics, by Mart�n Uribe and Stephanie Schmitt-Groh�, Princeton University Press, 2017. 
%� Mart�n Uribe and Stephanie Schmitt-Groh�. 

clear all

%simulation horizon and burn-in period

T = 4e6;
Tburn = 100000;

%set randomization seed
rand('state',0);

load pfi_peg.mat v  dp w y r d wb pai  hbar a alfa xi ny nw nd rstar gama betta sigg 
%produced by running
%pfi_peg.m in
%c:\data\uribe\book\dnwr
v_peg = v(:);
dp_peg = dp;
w_peg = w;
clear v dp w

load vfi_opt v
%produced by running
%vfi_opt.m in
%c:\data\uribe\book\dnwr
v_opt = repmat(v(:),[nw 1]);
clear v

%Welfare cost of a peg
WC = (((v_opt*(1-sigg)+1/(1-betta)) ./ (v_peg*(1-sigg)+1/(1-betta))).^(1/(1-sigg))-1)*100;  %this is the percentage increase in the consumpiton stream of a household living under a peg  necessary to make him as happy as living under the optimal exchange-rate policy, at a perticular state of the economy. 
WC = reshape(WC,ny,nd,nw);

%Set initial conditios of tradable output, debt, and past wage equal to their respective unconditional means
y0 = y(round(ny/2));
r0 = r(round(ny/2));
d0_peg = d(round(nd/2));
wb0_peg = wb(round(nw/2));

i = find(y==y0&r==r0);


%pai is the transition probability matrix of tradable output. Cpai is the cumulative probability matrix (useful for drawing tradable output realizations)
Cpai = cumsum(pai,2); 

%Initialize vector of tradable output and debt
wc =  zeros(T,1);

%Draw tradable output and debt realizations

for t=1:T

yT(t,1) = y0;
R(t,1) = r0;
D(t,1) = d0_peg;
Wb(t,1) = wb0_peg; 
j_peg = find(d==d0_peg);
k_peg = find(wb==wb0_peg);
wc(t,1) = WC(i,j_peg,k_peg); 


wb0_peg = w_peg(i,j_peg,k_peg); %real wage rate
d0_peg = dp_peg(i,j_peg,k_peg); 

i = sum(Cpai(i,:)<rand)+1;
y0 = y(i);
r0 = r(i);
end %for t

%Eliminate burn-in periods
wc = wc(Tburn+1:end);
yT = yT(Tburn+1:end);
Wb = Wb(Tburn+1:end);
D = D(Tburn+1:end);
R = R(Tburn+1:end);


Ewc = mean(wc);

disp(['Mean welfare cost of a currency peg  ' num2str(mean(wc))]);

disp(['Median welfare cost of a currency peg ' num2str(median(wc))]);


save simu_welf.mat  wc yT R D Wb  y r d wb pai  hbar a alfa xi ny nw nd rstar gama betta sigg