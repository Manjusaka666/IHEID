%ir_opt.m
% Produce the dynamics of a typical crisis in  the  tradable-endowment, open economy with downward nominal wage rigidity under  optimal exchange-rate policy
%studied in the chapter ``Nominal Rigidity, Exchange Rates,  And Unemployment'' of the book Open Economy Macroeconomics, by Mart�n Uribe and Stephanie Schmitt-Groh�, Princeton University Press, 2017. 
% The resulting equilibrium also pertains to an economy with flexible wages. 
%Note: before running this program, one must run at least once the program vfi_opt.m.
%� Mart�n Uribe and Stephanie Schmitt-Groh�. 

clear all

disp('For N=2e7, this program takes about 1.5 hour to run')

filename = 'vfi_opt';
%produced by running vfi_opt.m in
%z:\uribe\book\dnwr

gama = 0.99;

N = 2e7;
Nburn = 10000;
Tshock = 101; %period in which shock occurs
TIR = -20:20; %window of time around Tshock 
T = Tshock*2-1; %length of each episode

output_shock = -0.12*2;

%load parameter values
eval(['load ' filename  ' y r d  pai  dp  hbar a alfa xi ny nd rstar ' ])

rr = r; clear r;

uy = unique(y);
[ans,iyTshock] = min(abs(log(uy)-output_shock));
yTshock = uy(iyTshock);

%Set initial conditios of tradable output, debt, and past wage equal to their respective unconditional means
y0 = y(round(ny/2));
r0 = rr(round(ny/2));
d0 = d(round(nd/2));

%pai is the transition probability matrix of tradable output. Cpai is the cumulative probability matrix (useful for drawing tradable output realizations)
Cpai = cumsum(pai,2); 

%Initialize vector of tradable output and debt
Nvar = 17;
X = zeros(T,Nvar);
EY = zeros(1,Nvar);
Yshock = zeros(T,Nvar);
Elog_epsi = 0;
Elog_infl = 0;

pb = 1;
wb = pb*alfa*hbar^(alfa-1);

n = 0;
nshock = 0;

nyT=1; nwcpi=2; ncT=3; nwf=4; nh=5; ncN=6; nc=7; np=8; nD=9; nr=10; nepsi=11; ninfl=12; nunempl=13;ntby=14; 
ndy = 15; nw = 16; nGDP = 17; 

while n<=N
n = n+1;

yT = y0;
r = r0;
D = d0;
i = find(y==y0&rr==r0);
j = find(d==d0);
d0 = dp(i,j); 
L = sum(Cpai(i,:)<rand)+1;
y0 = y(L);
r0 = rr(L);
cT = yT + d0 ./ (1+r) - D;
wf = (1-a) / a * (hbar^alfa./cT).^(-1/xi) * alfa * hbar^(alfa-1);%full-employment real wage rate in terms of tradables
w = wf;
h = hbar;
cN = h.^alfa; %nontradable consumption
c = (a*cT.^(1-1/xi) + (1-a) * cN.^(1-1/xi)).^(1/(1-1/xi)); 
p = (1-a) / a * (cN./cT).^(-1/xi);
pc = (a^xi + (1-a)^xi * p.^(1-xi)).^(1/(1-xi));
wcpi = w ./ pc;
%epsi = max(1,gama*wb/w);
epsi = wb/w;
infl = epsi .* ((a^xi + (1-a)^xi * p.^(1-xi)) ./ (a^xi + (1-a)^xi * pb.^(1-xi))).^(1/(1-xi));

pb = p;
wb = w;

x = [yT wcpi cT wf h cN c p D r epsi infl 1-h (yT-cT)./(yT+p.*cN)    D./(4*(yT+p.*cN)) w    yT+p.*cN    ];

X = [X(2:end,:); x];

if n > Nburn
m = n-Nburn;

Y = X;

%Express yT wcpi cT wf  h cN c p w GDP in logs and multiply by 100 so that later, by subtracting their mean values, they end up expressed as percent deviaitions form trend
Y(:,[nyT nwcpi ncT nwf  nh ncN nc np nw nGDP]);
Y(:,[nyT nwcpi ncT nwf  nh ncN nc np nw nGDP]) = log(ans)*100;

%Express the interest rate in percent per annum
Y(:,nr);
Y(:,nr) = ((1+ans).^4-1)*100;

%Express epsi and infl in percent per annum
Y(:, [nepsi ninfl]);
%Y(:, [nepsi ninfl]) = (ans.^4-1)*100;
Y(:, [nepsi ninfl]) = log(ans);

%Express unempl in percent
Y(:, [nunempl ntby ndy ]);
Y(:, [nunempl ntby ndy ]) = ans*100;

%Compute the unconditional mean
EY = EY *(m-1)/m + Y(end,:)/m;

if X(Tshock,1) <= yTshock & X(Tshock-10,1)>=  1
   nshock = nshock+1;
   Yshock = Yshock *(nshock-1)/nshock + Y / nshock;
end %if X(Tshock,1) <= yTshock & ...

end %if n>Nburn

end %while n<=N

%Express the inflaiton and devaluation rates in percent per year
EY(nepsi) = (exp(EY(nepsi))^4-1)*100;
EY(ninfl) = (exp(EY(ninfl))^4-1)*100;

Yshock(:,nepsi);
Yshock(:,nepsi) = (exp(ans).^4-1)*100;

Yshock(:,ninfl);
Yshock(:,ninfl) = (exp(ans).^4-1)*100;

%Express as deviations from unconditional mena
IR = Yshock - repmat(EY,T,1); 

save ir_opt.mat