%vfi_opt.m
% Use a value-function-iteration procedure to obtain the policy function in the  tradable-endowment, open economy with downward nominal wage rigidity under  optimal exchange-rate policy
%studied in the chapter ``Nominal Rigidity, Exchange Rates,  And Unemployment'' of the book Open Economy Macroeconomics, by Mart�n Uribe and Stephanie Schmitt-Groh�, Princeton University Press, 2017. 
% The resulting equilibrium also pertains to an economy with flexible wages. 
%� Mart�n Uribe and Stephanie Schmitt-Groh�. 

clear all

%load joint stochastic process of the driving forces: vectors of discretized values of the log of tradable output (ygrid) and the log deviations of the gross country interest rate from the gross mean interest rate, log((1+r_t)/(1+r^*)), (rgrid) and transition probability matrix (pai)
load tpm.mat pai ygrid rgrid; %produced by running tpm.m 
%in
%c:\data\uribe\default\mfiles\one_bond\two_shocks\

ny = numel(ygrid); %number of grid points for log of tradable ouput

nd = 501;% # of grid points for debt, d_t

filename = [ 'vfi_opt']

rstar = 0.0316;  %average Argentine quarterly interest rate. Estimated using data from 1983:1 to 2001:4 in the program  c:\data\uribe\default\data\exogenous_process.m (we cut the post 2001 period because of the great default of 2001, since our current model does not feature default).

r = exp(rgrid)*(1+rstar)-1; 

betta = 0.9635; %discount factor

alfa = 0.75;%hours elasticity of nontraded output (Uribe, JME1997)

hbar = 1;  %full-employment hours

a = 0.26;%Share of traded consu mption (own computation)

xi = 0.5;% Elasticity of substitution between traded and nontraded goods

sigg = 1/xi; %intertemporal elasticity of consumption

y = exp(ygrid(:)); %level of tradable output

%Natural borrowing limit
dupper = 8; 
dlower =1;
d = dlower:(dupper-dlower)/(nd-1):dupper;
d = d(:);

n = ny*nd;

dtry = repmat(d',[ny 1  nd]);
dtry = reshape(dtry,n,nd);

dptryix = repmat(1:nd,n,1);

dptry = d(dptryix);


rtry = repmat(r,[nd nd]);

cTtry =  dptry ./ (1+rtry) - dtry;% consumption of tradables

clear dptry dtry rtry

yTtry = repmat(y(:),[nd nd]);
yTtryix = repmat((1:ny)',nd,nd);

cTtry = yTtry + cTtry;

clear yTtry 

if min(max(cTtry,[],2))<0
error('Natural debt limit violated')
end

ctry = (a * cTtry.^(1-1/xi) + (1-a) * (hbar^alfa).^(1-1/xi)).^(1/(1-1/xi));%composite consumption 

utry = (ctry.^(1-sigg) - 1) / (1-sigg);

utry(cTtry<=0) = -inf;

clear ctry cTtry

v = zeros(ny,nd);

Itry = sub2ind([ny nd],yTtryix,dptryix);

dpixold = 0;

dist = 1; h=1;

while dist> 1e-8

ev = pai *  v;

Evptry = ev(Itry);

clear ev

[vnew, dpix] = max(utry+betta*Evptry,[],2);

dist = max(abs(vnew(:)-v(:))) + max(abs(dpix(:)-dpixold(:)))

v = vnew;

v = reshape(v,ny,nd);
dpix = reshape(dpix,ny,nd);

dpixold = dpix;

end %while dist>1e-8

dp = d(dpix);

 	
eval(['save ' filename '.mat filename nd ny   rstar betta sigg alfa hbar a xi pai y r  d  v dpix dp    nd ' ])