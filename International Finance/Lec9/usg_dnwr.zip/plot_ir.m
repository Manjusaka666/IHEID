%plot_ir.m
%Plot the dynamics of a typical crisis in  the  tradable-endowment, open economy with downward nominal wage rigidity under  
%a currency peg and under the optimal exchange-rate   policy studied in the chapter ``Nominal Rigidity, 
%Exchange Rates,  And Unemployment'' of the book Open Economy Macroeconomics, by Mart�n 
%Uribe and Stephanie Schmitt-Groh�, Princeton University Press, 2017. 
%Note: before running this program one must run at least once the programs vfi_opt.m, pfi_peg.m, ir_opt.m, and ir_peg.m.
%� Mart�n Uribe and Stephanie Schmitt-Groh�. 

clf , clear all

load ir_opt  TIR IR  nvar Tshock nyT ntby  nunempl ncN nD nr np nwcpi nepsi ninfl  ncT
%produced by running
%c:\data\uribe\book\dnwr\ir_opt.m


TIR = -20:20;

%the order of the variables is: x = [yT wcpi cT wf h cN c p D r epsi infl 1-h (yT-cT)    D./(4*(yT+p.*cN)) w        ];%./(yT+p*cN)];

var_name = {'Tradable Output', 'Real  (CPI) Wage',    'Consumption of Tradables', 'Full-Employment Real Wage (in tradables)',    'Hours', 'Consumption of Nontradables',    'Total Consumption', 'Relative Price of Nontradables ($P^N_t/E_t$)', 'Net External Debt','Interest Rate Minus Mean', 'Annualized Devaluation Rate', 'Annual CPI Inflation Rate',    'Unemployment Rate','Trade-Balance-To-Output Ratio', 'Debt-To-Output Ratio (Annual)', 'Real  Wage (in terms of tradable)'};


ylabels = {'\% dev. from trend', '\% dev. from trend',    '\% dev. from trend', '\% dev. from trend',    '\% dev. from trend', '\% dev. from trend',    '\% dev. from trend', '\% dev. from trend', '  ','\% per year', '\%', '\%',    '\% ','\%', '\%', '\% dev. from trend'};


nyT=1; nwcpi=2; ncT=3; nwf=4; nh=5; ncN=6; nc=7; np=8; nD=9; nr=10; nepsi=11; ninfl=12; nunempl=13;ntby=14; 
ndy = 15; nw = 16; 

nvar = [nunempl nw nepsi np ninfl ncT ntby ndy];
%nvar = [nunempl nwcpi nepsi np ninfl ncT ntby ndy];

figure(1) 
orient tall

    for j=1:8
subplot(4,2,j)
kkk=plot(TIR+10,IR(TIR+Tshock,nvar(j)),' --')
set(kkk, 'linewidth',4)
title(var_name{nvar(j)},'interpreter','LaTeX')
hold on

end





load  ir_peg.mat IR
%produced by running  
%ir_peg.m in
%c:\data\uribe\book\dnwr

orient tall
for j=1:8
subplot(4,2,j)
kkk=plot(TIR+10,IR(TIR+Tshock,nvar(j)),' ')
set(kkk, 'linewidth',4)
ylabel(ylabels{nvar(j)},'interpreter','LaTeX')
xlabel('$t$','interpreter','Latex')
end

    

figure(2)
nvar = [nyT nr nunempl nwcpi nepsi np ninfl ncT ntby ndy];

orient tall

    for j=1:10
subplot(5,2,j)
kkk=plot(TIR+10,IR(TIR+Tshock,nvar(j)),' --')
set(kkk, 'linewidth',4)
title(var_name{nvar(j)},'interpreter','LaTeX')
hold on

end





load  ir_peg.mat IR
%produced by running  
%ir_peg.m in
%c:\data\uribe\book\dnwr

orient tall
for j=1:10
subplot(5,2,j)
kkk=plot(TIR+10,IR(TIR+Tshock,nvar(j)),' ')
set(kkk, 'linewidth',4)
ylabel(ylabels{nvar(j)},'interpreter','LaTeX')

end

    


figure(3)
nvar = [nyT nr ];

orient tall

    for j=1:2
subplot(3,2,j+2)
kkk=plot(TIR+10,IR(TIR+Tshock,nvar(j)),' --')
set(kkk, 'linewidth',4)
title(var_name{nvar(j)},'interpreter','LaTeX')
hold on

end

load  ir_peg.mat IR
%produced by running  
%ir_peg.m in
%c:\data\uribe\book\dnwr

orient tall
for j=1:2
subplot(3,2,j+2)
kkk=plot(TIR+10,IR(TIR+Tshock,nvar(j)),' ')
set(kkk, 'linewidth',4)
ylabel(ylabels{nvar(j)},'interpreter','LaTeX')
xlabel('$t$','interpreter','Latex')

end

figure(1)