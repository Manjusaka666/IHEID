function  simu(filename,T);
%simu.m Simulate equilibrium dynamics in  a tradable-endowment, open economy with downward nominal wage rigidity, a currency peg, and possibly optimal capital controls.  The economy is the one studied in 
% the chapter ``Nominal Rigidity, Exchange Rates,  And Unemployment'' of the book Open Economy Macroeconomics, by Mart�n Uribe and Stephanie Schmitt-Groh�, Princeton University Press, 2017. 
%To simulate the baseline  economy, set filaname='pfi_peg'.
%� Mart�n Uribe and Stephanie Schmitt-Groh�. 

%load parameter values
eval(['load ' filename  '.mat y r d wb pai v w dp hbar a alfa xi ny nw nd rstar gama betta sigg taud' ])

if exist('taud') ==0
taud = 0*v;
end

%simulation horizon and burn-in period
if nargin<2
T = 3e6;
end

Tburn = 1000;

%Set initial conditios of tradable output, debt, and past wage equal to their respective unconditional means
y0 = y(round(ny/2));
r0 = r(round(ny/2));
d0 = d(round(nd/2));
wb0 = wb(round(nw/2));

%pai is the transition probability matrix of tradable output. Cpai is the cumulative probability matrix (useful for drawing tradable output realizations)
Cpai = cumsum(pai,2); 

%Initialize vector of tradable output and debt
yT = zeros(T,1);
D = zeros(T,1);
W = zeros(T,1);
V = zeros(T,1);
R = zeros(T,1);
TAUD = zeros(T,1);

%Draw tradable output and debt realizations
for t=1:T
yT(t,1) = y0;
R(t,1) = r0;
D(t,1) = d0;
i = find(y==y0&r==r0);
j = find(d==d0);
k = find(wb==wb0);
W(t,1) =w(i,j,k); %real wage rate
V(t,1) = v(i,j,k);
wb0 = W(t);
TAUD(t,1) = taud(i,j,k);
d0 = dp(i,j,k); 
L = sum(Cpai(i,:)<rand)+1;
y0 = y(L);
r0 = r(L);
end %for t

%Eliminate burn-in periods
yT = yT(Tburn+1:end);
R = R(Tburn+1:end);
D = D(Tburn+1:end);
W = W(Tburn+1:end);
V = V(Tburn+1:end);
TAUD = TAUD(Tburn+1:end);

for i=1:nd
lad(i,1) = mean(D==d(i)); %prob. distribution of debt
end

for i=1:nw
law(i,1) = mean(W==wb(i)); %prob. distribution of wages
end

%Construct vector of current, past, and future values of debt and tradable output (necessary because inflation and devaluation are variables that involve past, preent, and future value aof these debt and tradable output).
lagg(yT,2);
yT = ans(:,2);
yTp = ans(:,1);
yTb = ans(:,3);

lagg(R,2);
R = ans(:,2);
Rp = ans(:,1);
Rb = ans(:,3);

lagg(D,2);
D = ans(:,2);
Dp = ans(:,1);
Db = ans(:,3);

lagg(W,2);
W = ans(:,2);
Wp = ans(:,1);
Wb = ans(:,3);

lagg(V,2);
V = ans(:,2);
Vp = ans(:,1);
Vb = ans(:,3);

lagg(TAUD,2);
TAUD = ans(:,2);
TAUDp = ans(:,1);
TAUDb = ans(:,3);

%Produce simulations of other endogenous variables of the model
cT = yT + Dp ./ (1+R) - D;
wf= (1-a) / a * (hbar^alfa./cT).^(-1/xi) * alfa * hbar^(alfa-1);%full-employment real wage rate in terms of tradables
h = (a / (1-a) * W  / alfa.* cT .^(-1/xi) ).^(1/(alfa-1-alfa/xi)); %hours
h = min(hbar,h);
cN = h.^alfa; %nontradable consumption
tau = cT - yT; %international transfers
c = (a*cT.^(1-1/xi) + (1-a) * cN.^(1-1/xi)).^(1/(1-1/xi)); %consumption
p = (1-a) / a * (cN./cT).^(-1/xi); %relative price of nontradables in terms of tradables

%lagged variables
cTb = yTb + D ./ (1+Rb) - Db;
wfb = (1-a) / a * (hbar^alfa./cTb).^(-1/xi) * alfa * hbar^(alfa-1);%full-employment real wage rate in terms of tradables
hb  = (a / (1-a) * Wb  / alfa.* cTb .^(-1/xi) ).^(1/(alfa-1-alfa/xi)); %hours
hb = min(hb,hbar);
cNb = hb.^alfa;
pb = (1-a) / a * (cNb./cTb).^(-1/xi);

%Devaluations and Inflation Rates
epsi =0*W+1;
infl = epsi .* ((a^xi + (1-a)^xi * p.^(1-xi)) ./ (a^xi + (1-a)^xi * pb.^(1-xi))).^(1/(1-xi));

dy = D./(yT+p.*cN)/4;

tby = (yT-cT) ./(yT+p.*cN);

A1 = a * (c./cT).^(1/xi); %marginal utility of tradable consumption

pc = A1.^(-1); %pice of c in terms of cT

output = (yT+p.*cN).*A1; %ouput measured in terms of c units

dy = D./(yT+p.*cN)/4;
Edy = mean(dy);

Eu = mean(hbar-h); 

disp(['Mean unemployment rate ' num2str(Eu*100) ' percent'])


eval(['save simu_' filename '.mat d lad wb law y r d wb pai hbar a alfa xi ny nw nd rstar gama betta sigg  Edy Eu']);