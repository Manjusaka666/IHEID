%plot_welf.m
%figure(1) plots the unconditional distribution of the welfare cost of a currency peg relative to the optimal exchange-rate policy. The unconditional distribution is computed using the distribution of the state (yT,r,d,wb) induced by the peg economy
%figure(2) plots the welfare cost of a peg as a function of a particular state variable, holding all other state variables at their unconditional mean levels.
%The economy is the one studied in the chapter ``Nominal Rigidity, Exchange Rates,  And Unemployment'' of the book Open Economy Macroeconomics, by Mart�n Uribe and Stephanie Schmitt-Groh�, Princeton University Press, 2017. 
%� Mart�n Uribe, September 2013

clear all
clf

load simu_welf
%produced by running
%simu_welf.m in
%z:\uribe\book\dnwr

figure(1)
[a,b] = pdf(wc,80,3.5,22);
plot(b,a,' ','linewidth',4)
xlabel('welfare cost of a peg (\% of $c_t$ per quarter)','interpreter','Latex')
ylabel('density','interpreter','Latex')
xlim([3.5 22])

[ss, meanDix]=min(abs(d-mean(D)));
[ss, meanWbix]=min(abs(wb-mean(Wb)));
[ss, meanyTix]=min(abs(y-mean(yT)));
[ss, meanRix]=min(abs(r-mean(R)));

uWb = unique(Wb);
for j=1:numel(uWb)
Ewc_Wb(j,1) = mean(wc(Wb==uWb(j)&D==d(meanDix)&yT==y(meanyTix)&R==r(meanRix)));
end

uR = unique(R);
for j=1:numel(uR)
Ewc_R1(j,1) = mean(wc(R==uR(j)&D==d(meanDix)&yT==y(meanyTix)&Wb==wb(meanWbix)));
end

uyT = unique(yT);
for j=1:numel(uyT)
Ewc_yT1(j,1) = mean(wc(yT==uyT(j)&D==d(meanDix)&R==r(meanRix)&Wb==wb(meanWbix)));
end

uD = unique(D);
for j=1:numel(uD)
Ewc_d1(j,1) = mean(wc(D==uD(j)&yT==y(meanyTix)&R==r(meanRix)&Wb==wb(meanWbix)));
end

figure(2)
subplot(2,2,1)
z1 = uWb;z2 = Ewc_Wb;z3=mean(Wb);
kk=plot(z1(~isnan(z2)),z2(~isnan(z2)),[z3 z3],[min(z2) max(z2)],'--'),shg
set(kk, 'linewidth',4)
xlabel('$w_{t-1}$','interpreter','Latex'),
ylabel('welfare cost','interpreter','Latex')
ylim([min(z2) max(z2)]);

subplot(2,2,2)
z1=uD;z2=Ewc_d1; z3 = mean(D);
kk=plot(z1(~isnan(z2)),z2(~isnan(z2)),[z3 z3],[min(z2) max(z2)],'--'),shg
set(kk, 'linewidth',4)
xlabel('$d_t$','interpreter','Latex'),
ylabel('welfare cost','interpreter','Latex')
ylim([min(z2) max(z2)]);

subplot(2,2,3)
z1=log(uyT);z2=Ewc_yT1; z3 = 0;
kk=plot(z1(~isnan(z2)),z2(~isnan(z2)),[z3 z3],[min(z2) max(z2)],'--'),
set(kk, 'linewidth',4)
xlabel('$\log(y^T_t)$','interpreter','Latex')
ylabel('welfare cost','interpreter','Latex')
ylim([min(z2) max(z2)]);

subplot(2,2,4)
z1=((1+uR).^4-1)*100;z2=Ewc_R1; z3 = mean(((1+R).^4-1)*100);
kk=plot(z1(~isnan(z2)),z2(~isnan(z2)),[z3 z3],[min(z2) max(z2)],'--'),shg
set(kk, 'linewidth',4)
ylabel('welfare cost','interpreter','Latex')
xlabel('$r_t$ (annual)','interpreter','Latex')
ylim([min(z2) max(z2)]);