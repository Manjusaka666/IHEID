Data Set and Replication files for the Empirical Analysis in  Chapter 8  entitled ``Nontradable Goods And The Real Exchange Rate''  of the book `Open Economy Macroeconomics,' by Mart�n Uribe and Stephanie Schmitt-Groh�, Princeton University Press 2017. 
� Mart�n Uribe and Stephanie Schmitt-Groh�, 2016. 

Data Set
usg_rer_detrended_data.mat  
 This file contains the detrended data used in the SVAR analysis.  The data is contained in the cell rer_data. Each element of rer_data is a 7-column matrix for a particular  country. Rows are years and columns are variables (date,  tot, tb, gdp, c, i, rer in this order). The order of countries is given in the cell country. For example rer_data{23} is a 32x7 matrix containing the data for Korea, Rep.

Replication Files
Figure 8.1 rer_ir.m 
Table 8.1 table_v_share_cbc.m

Note. Some scripts require downloading the toolkkit for  solving DSGE models up to first order, available at http://www.columbia.edu/~mu2166/1st_order/1st_order.htm 