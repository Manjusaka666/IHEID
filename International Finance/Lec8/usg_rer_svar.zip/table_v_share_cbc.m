%table_v_share_cbc.m 
%produces Table 8.1. Returns the country-by-country estimates of the shares of the variances of [tot tb y c i rer] explained by tot shocks  predicted by the  SVAR model of Chapter 8 entitled ``Nontradable Goods And The Real Exchange Rate'' of the book Open Economy Macroeconomics, by Mart�n Uribe and Stephanie Schmitt-Groh�, Princeton University Press, 2017.
%�Mart�n Uribe and Stephanie Schmitt-Groh�, 2016. 

clc
load rer_cbcs6.mat filename hx PI R2 ncou country nv ssigx v_share
%produced by running 
%rer_cbcs.m 

disp('Table 8.1 of Open Economy Macroeconomics, by Mart�n Uribe and Stephanie Schmitt-Groh�')
for k=1:ncou
a = [country{k} ' ' num2str(v_share(:,k)')];
disp(a)
end
b = ['Median ' num2str(median(v_share'))];
disp(b)
c = ['Median Absolute Deviation' num2str(mad(v_share',1))];
disp(c)