%rer_ir.m
%Figure 8.1. Returns the impulse responses of the Real Exchange Rate  and Aggregate Activity to An Innovation in the Terms of Trade predicted by the  SVAR model of Chapter 8 entitled ``Nontradable Goods And The Real Exchange Rate'' of the book Open Economy Macroeconomics, by Mart�n Uribe and Stephanie Schmitt-Groh�, Princeton University Press, 2017.
%�Mart�n Uribe and Stephanie Schmitt-Groh�, 2016. 

clear all

%read the matrices hx and PI defining the country-by-country estimated  SVAR systems
load rer_cbcs6.mat PI  country   hx nv ncou      
%produced by running rer_cbcs.m in
%z:\uribe\book\rer\data

paper=1; 
%paper =0
if paper ==1
    rows=3
    cols=2
    orient tall
else
    rows =3 
    cols =3
    orient portrait
end

T = 11;
IR = zeros(T,2*nv,ncou);
for k=1:ncou
P = PI(:,:,k);
HX = hx(:,:,k);
x0 = P(:,1)/P(1,1)*10;;
IR(:,:,k) = ir(eye(nv),HX,x0,T);
end

pIR = median(IR,3);

t=(0:T-1)';

subplot(rows, cols,1)
plot(t,pIR(:,1),'linewidth',3)
hold on

plot(t,pIR(:,1)*0);
hold off
title('Terms of Trade')

ylabel('% dev. from trend')

subplot(rows, cols,2)
plot(t,pIR(:,2),'linewidth',3)
hold on
plot(t,pIR(:,2)*0);
hold off
title('Trade Balance')
ylabel('% dev. from GDP trend')

subplot(rows, cols,3)
plot(t,pIR(:,3),'linewidth',3)
hold on
plot(t,pIR(:,3)*0);
hold off
title('Output')
ylabel('% dev. from trend')

subplot(rows, cols,4)
plot(t,pIR(:,4),'linewidth',3)
hold on
plot(t,pIR(:,4)*0);
hold off
title('Consumption')
ylabel('% dev. from trend')

subplot(rows, cols,5)
plot(t,pIR(:,5),'linewidth',3)
hold on
plot(t,pIR(:,5)*0);
hold off
title('Investment')
ylabel('% dev. from trend')

subplot(rows, cols,6)
plot(t,pIR(:,6),'linewidth',3)
hold on
plot(t,pIR(:,6)*0);
hold off
title('Real Exchange Rate')
ylabel('% dev. from trend')
shg