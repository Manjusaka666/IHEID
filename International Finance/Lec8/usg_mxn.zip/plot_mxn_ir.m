% plot_mxn_ir.m 
% Plot impulse responses to a terms-of-trade shock implied by the MXN model developed in chapter 8 entitled 
% `Nontradable Goods And The Real Exchange' of the textbook 
% `Open Economy Macroeconomics' by M. Uribe and S. %Schmitt-Grohe, Princeton University Press, 2017.
% Figure 8.2 
% � Mart�n Uribe and Stephanie Schmitt-Groh�, May 2015.

clear all
clf
orient tall 
load mxn_var.mat IR_cbc n* Tir
%Produced by running 
% mxn_var.m 
% in directory 
% Z:\uribe\tot\IER\mfiles\match_std

%Compute cross-country medians of impluse responses
IR = median(IR_cbc,3); 
IR = 10*IR; 

rows =5;
cols = 3;

thick = 2;
thin = 1; 

t=0:Tir-1;

nvar = [ny+ntot ;  nptau;npn;ntby;nm; nx; noutput_constant_prices; nc_constant_prices; nivv_constant_prices;nym;nyx;nyn;nim;nix;nivn];

%note y, c, ivv, and tby are at constant prices, 

TITLE = {'Terms of Trade',
    'Real Exchange Rate', 
    'Rel Price of Nontradables',
    'Trade Balance', 
    'Imports', 
    'Exports', 
    'Output', 
    'Consumption',
    'Investment',
    'Output in Import Sector', 
    'Output in Export Sector', 
    'Output in Nontraded Sector',
    'Investment in Import Sector',
    'Investment in Export Sector',
    'Investment in Nontraded Sector'};
    

for i = 1:15
        k=nvar(i); 
        subplot(rows,cols,i)
        plot(t, IR(:,k),'linewidth',thick)
        title(TITLE{i})
        hold on
end

shg