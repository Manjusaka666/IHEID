% mxn_versus_svar.m 
% Figures 8.3 and 8.4  of  chapter 8 entitled 
% `Nontradable Goods And The Real Exchange' of the textbook 
% `Open Economy Macroeconomics' by M. Uribe and S. %Schmitt-Grohe, Princeton University Press, 2017.
% Returns plots of the variance of output explained by TOT shocks predicted by the SVAR model against the corresponding one predicted by the MXN model for each of the 38 countreis included in the panel. 
% � Mart�n Uribe and Stephanie Schmitt-Groh�, May 2015.

clear all, clf, clc

load mxn_var.mat   var_model_tot_ratio_cbc var_data_tot_ratio_cbc country
%produced by running
% mxn_var.m 

tb_data = var_data_tot_ratio_cbc(2,:); 

tb_model = var_model_tot_ratio_cbc(2,:); 

y_data = var_data_tot_ratio_cbc(3,:); 

y_model = var_model_tot_ratio_cbc(3,:); 

c_data = var_data_tot_ratio_cbc(4,:); 

c_model = var_model_tot_ratio_cbc(4,:); 

ivv_data = var_data_tot_ratio_cbc(5,:); 

ivv_model = var_model_tot_ratio_cbc(5,:); 

rer_data = var_data_tot_ratio_cbc(6,:); 

rer_model = var_model_tot_ratio_cbc(6,:); 

figure(1)
clf 
plot(y_data*100, min(60,y_model*100),'.')
hold on
plot([0 60], [0 60])
ylim([0 60])
xlim([0 60])
axis('square')

corr(y_data(:), y_model(:)); %correlatioin between the predictions of the SVAR and the MXN models

A = country; 
B = cellfun(@(x) x(1:3),A,'un',0);
C = cellstr(B);
text(y_data*100, min(60,y_model*100), B);

text(57,57, '45^o')
xlabel('SVAR Model')
ylabel('MXN Model')
set(gca,'XTick', [0 10 20 30 40 50 60])
set(gca,'YTick', [0 10 20 30 40 50 60])

data={c_data, ivv_data, rer_data, tb_data} ;
model = {c_model, ivv_model, rer_model, tb_model};
TITLE = {'Consumption', 'Investment', 'Real Exchange Rate', 'Trade Balance'};

disp('Press ENTER to display figure 8.4')
shg, pause, 
figure(2)
clf
for i = 1:4
    subplot(2,2,i)
    plot(data{i}*100, min(60,model{i}*100),'.')
    corr(data{i}(:), model{i}(:));
    hold on
    plot([0 60], [0 60])
    ylim([0 60])
    xlim([0 60])
    set(gca,'XTick', [0 20 40  60])
    set(gca,'YTick', [0 20 40 60])
    text(50,50, '45^o')
    axis('square')
    title(TITLE{i})
    xlabel('SVAR Model')
    ylabel('MXN Model')
end