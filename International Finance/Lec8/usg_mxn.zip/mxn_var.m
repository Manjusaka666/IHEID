% mxn_var.m
% Computes variances conditional on terms-of-trade shocks implied by the MXN model
% as a fraction of the population SVAR total variances. 
% The MXN model is  developed in chapter 8, entitled
% ``Nontradable Goods And The Real Exchange'' of the textbook 
% `Open Economy Macroeconomics' by M. Uribe and S. Schmitt-Grohe, Princeton University Press, 2017.
% Tables 8.4 and 8.5
% � Mart�n Uribe and Stephanie Schmitt-Groh�, May 2015.

clear all
clc

%read empirical  share of variances explained by tot shocks in SVAR
load rer_cbcs6.mat v_share country var_svar var_svar_tot
%produced by running
%rer_cbcs.m  in usg_rer_svar.zip
% directory z:\uribe\book\rer\data

ncou = length(country);

nv = size(v_share,1); 

var_model_tot = zeros(nv,ncou);

%theoretical predictions from MXN  model
load phi_pssi_cbc.mat PHIM_cbc PHIX_cbc PHINT_cbc PSSI_cbc RHO_TOT_cbc STD_TOT_cbc 
%produced by running 
%phi_pssi_cbc.m in
%z:\uribe\book\rer\mxn
externallyset_parameters = 1;

%Read position of variables in control vector and in state vector
load mxn.mat n* statevar controlvar
%produced by running 
%mxn_model.m  in
%z:\uribe\book\rer\mxn

Tir = 11;  
nx = numel(statevar);
ny=numel(controlvar)+1;%Why plus 1? Because we add traded investment into the y vector below.  
IR_cbc= zeros(Tir, nx+ny, ncou);


for k=1:ncou
PHIM = PHIM_cbc(k);
PHIX = PHIX_cbc(k);
PHINT = PHINT_cbc(k); 
PSSI = PSSI_cbc(k);
RHO_TOT = RHO_TOT_cbc(k);
STD_TOT = STD_TOT_cbc(k);

mxn_ss %read steady state   and parmeter values

mxn_num_eval %this .m script was created by running mxn_model.m 

%The linearized equilibrium system is of the form
%y_t=gx x_t
%x_t+1 = hx x_t + ETASHOCK epsilon_t+1
[gx, hx, exitflag] = gx_hx(nfy, nfx, nfyp, nfxp); %this step uses the toolbox for first-order approximations of  DSGE models produced by S. Schmitt-Grohe and M. Uribe 
%available on line at  
%http://www.columbia.edu/~mu2166/1st_order/1st_order.htm

%Add tradable investment it=im+ix 
gxit = gx(nim,:)*im/(im+ix) + gx(nix,:)*ix/(im+ix);
gx = [gx;gxit];
nit = size(gx,1);

varshock = nETASHOCK*nETASHOCK';

%Compute impulse responses: 
x0 = zeros(nstate,1); 
x0(ntot,1) = 1; 
IR_cbc(:,:,k) = ir(gx,hx,x0,Tir);  %this step uses the toolbox for first-order approximations of  DSGE models produced by S. Schmitt-Grohe and M. Uribe 
%available on line at  
%http://www.columbia.edu/~mu2166/1st_order/1st_order.htm

%variance-covariance matrices conditional on tot shocks
[sigy0,sigx0]=mom(gx,hx,varshock); %this step uses the toolbox for first-order approximations of  DSGE models produced by S. Schmitt-Grohe and M. Uribe 
%available on line at  
%http://www.columbia.edu/~mu2166/1st_order/1st_order.htm

diag(sigy0);  %unconditional variances conditional on tot shocks
var_model_tot(2:end,k) = ans([ntby;  noutput_constant_prices ;nc_constant_prices ;nivv_constant_prices;nptau]'); %pick variables of interest (output, consumption, investment, trade balance divided by trend output)

var_model_tot(1,k) = sigx0(ntot,ntot);

end

var_model_tot_ratio_cbc = var_model_tot./ var_svar;

var_data_tot_ratio_cbc = var_svar_tot./var_svar;

var_model_tot_ratio = median(var_model_tot_ratio_cbc,2);

var_data_tot_ratio = median(var_data_tot_ratio_cbc,2);

disp('Table 8.4 of Open Economy Macroeconomics by Mart�n Uribe and Stephanie Schmitt-Groh�')
round(median(var_model_tot_ratio_cbc')*100)
round(median(var_data_tot_ratio_cbc')*100)

disp('Press ENTER to display Table 8.5')


pause
disp(' ')

disp('Table 8.5 of Open Economy Macroeconomics by Mart�n Uribe and Stephanie Schmitt-Groh�')

xxx = zeros(2*nv,ncou);
xxx(1:2:2*nv,:) =var_model_tot_ratio_cbc*100;
xxx(2:2:2*nv,:)  = var_data_tot_ratio_cbc*100;

for k=1:ncou
a = [country(k)   num2str(round(xxx(:,k))')];
disp(char(a))
end
b = ['Median ' num2str(round(median(xxx')))];
disp(b)
c = ['Median Absolute Deviation' num2str(round(mad(xxx',1)))];
disp(c)

save mxn_var.mat  IR_cbc  n* Tir var_model_tot_ratio_cbc var_data_tot_ratio_cbc country