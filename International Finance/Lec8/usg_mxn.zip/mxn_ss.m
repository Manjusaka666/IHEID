% mxn_ss.m
% Produce the the deterministic steady state of the MXN model developed in the chapter 8 
% entitled ``Nontradable Goods And The Real Exchange'' of the book 
% `Open Economy Macroeconomics' by M. Uribe and S. Schmitt-Grohe, Princeton Unversity Press, 2017.
% The solution of the steady state is for the case that MUTN not equal  to 1 and that ALFAN neq ALFAX=ALFAM
% � Mart�n Uribe and Stephanie Schmitt-Groh�, May 2015.

%Calibration

if externallyset_parameters  == 0;
PHIM = 0.9819;%capital adjustment cost cross-country median
PHIX = 0.9819;%capital adjustment cost cross-country median
PHINT = 0.9819;%capital adjustment cost cross-country median
PSSI = 0.0573; %debt elasticity of interest rate cross-country median
RHO_TOT = 0.5; %AR(1) coeff of tot
STD_TOT = 0.1; % std of innovation to tot
end

load get_distance.mat xs
%produced by running 
%set_fmin.m in
%z:\uribe\book\rer\mfiles
pn = xs(1);
pm=xs(2); 

PN = pn;
PM = pm; 

%This file solves for the steady state of the TNT model 
%for the case that MUTN not equal  to 1 and that ALFAN neq ALFAX=ALFAM

DELTA = 0.1; %depreciation rate
ALFAN = 1 - 0.75; %capital  share in the nontraded sector
ALFAX = 1 - 0.65; %capital share in the export sector
ALFAM = ALFAX;%capital share in the import sector
RSTAR = 0.11; %long-run interest rate
MUMX= 1;%Elasticity of Substitution between importables and exportables; 
MUTN=  0.5;%0.44;%Elasticity of Substitution between importables and exportables; 
SIGG = 2; %
OMEGAM = 1.455; %Frisch ela st. 
OMEGAX = 1.455; %Frisch ela st. 
OMEGAN = 1.455; %Frisch ela st. 
TFPM = 1;
TFPN = 1;
TOT = 1;

BETTA = 1/(1+RSTAR);

syx = 0.25;
sx=0.20;
syn=0.5; %computed from M:\uribe\book\tot\tradeshares\read_unctad.m as mean of share_ser = squeeze(data(: ,nsgdpser,:))
stb=0.01;
sym = 1-syx-syn; 
sm= sx-stb; 
tot = TOT; 
r = RSTAR; 

ux=1/BETTA-1+DELTA; 
um=1/BETTA-1+DELTA; 
un=1/BETTA-1+DELTA; 

K = syx/(1-syx-syn);
H = K^(1/OMEGAX);
W = K^((OMEGAX-1)/OMEGAX);
A = K^((1-ALFAX)*(OMEGAX-1)/OMEGAX)/TOT; 
TFPX = A*TFPM; 
UPSILON = (syx-sx)/(sym+sx-stb); 

CHIM = (UPSILON*TOT^(MUMX-1))^(-1/MUMX)/(1+(UPSILON*TOT^(MUMX-1))^(-1/MUMX));
ax_o_am = UPSILON/TOT; 

if MUMX ==1
am_o_atau = ax_o_am^(CHIM-1);    
else
    am_o_atau = (CHIM+(1-CHIM)*(ax_o_am)^(1-1/MUMX))^(-1/(1-1/MUMX))
end

pm_o_ptau = CHIM * (am_o_atau)^(-1/MUMX);

%71
px = pm/tot; 
PX = px; 

%51
ptau = pm/pm_o_ptau; 

km_o_hm  = (um/pm/ ALFAM/ TFPM)^(1/(ALFAM-1)); %58 

kx_o_hx  = (ux/px/ ALFAX/TFPX)^(1/(ALFAX-1));  %60

kn_o_hn  = (un/pn/ ALFAN/TFPN)^(1/(ALFAN-1));  %62

wm =  pm*(1-ALFAM)*TFPM * km_o_hm^(ALFAM); %59
 
wx = px* (1-ALFAX)*TFPX*kx_o_hx^(ALFAX);  %61

wn = pn* (1-ALFAN)*TFPN*kn_o_hn^(ALFAN);  %63

hm = wm^(1/(OMEGAM-1)); %44

hx = wx^(1/(OMEGAX-1)); %45 

hn = wn^(1/(OMEGAN-1)); %46 

kx = hx *kx_o_hx;  %60a

km = hm * km_o_hm;  %58a

kn = hn * kn_o_hn;  %62a

ym = TFPM * km^ALFAM * hm^(1-ALFAM);  %55

yx = TFPX * kx^ALFAX * hx^(1-ALFAX); %56

yn = TFPN * kn^ALFAN * hn^(1-ALFAN); %57

im = DELTA * km; %40 

ix = DELTA * kx; %41

in = DELTA * kn; %42

an = yn; %66

y=px*yx+pm*ym+pn*yn; 

%68
x = sx*y; 
%67
m = -stb*y+x; 

%69
d = (x-m)*(1+r)/r/ptau; 

am = ym + m/pm; 

ax = yx - x/px; 

DBAR = d; 


if MUMX==1 %65
atau = am^CHIM * ax^(1-CHIM);
else
atau = (CHIM * am^(1-1/MUMX) + (1-CHIM) * ax^(1-1/MUMX))^(1/(1-1/MUMX));
end


im = DELTA*km; 
ix=DELTA*kx; 
ivn=DELTA*kn; 


%54
CHITAU = pn/ptau *(an/atau)^(1/MUTN);
CHITAU = 1/(1+CHITAU); 

if MUTN==1 %53a
B = atau^CHITAU * an^(1-CHITAU);
else
B = (CHITAU * atau^(1-1/MUTN) + (1-CHITAU) * an^(1-1/MUTN))^(1/(1-1/MUTN));
end


c = B-im-ix-ivn; 
c_constant_prices=c; 


la  = c - hm^OMEGAM/OMEGAM - hx^OMEGAX/OMEGAX - hn^OMEGAN/OMEGAN;
la = la^(-SIGG);


eq53 = -ptau + CHITAU *(atau/B)^(-1/MUTN);

eq36 = -syn + pn*yn/y; 

dist = norm([eq53 eq36]);

tfp_x = TFPX;
tfp_n= TFPN;
tfp_m = TFPM; 
h_x = hx; 
clear hx; 

OUTPUT = y; 
output = y; 
output_constant_prices=output; 


ivv = ix+im+ivn;
ivv_constant_prices=ivv; 

tby = stb; 