%pfi_peg.m
% Use a policy-function-iteration procedure to obtain the policy function in a tradable-endowment, small open economy with  downward nominal wage rigidity and a currency peg. 
% analyzed in chapters 
% ``Nominal Rigidity, Exchange Rates,  And Unemployment'' and 
%``Exchange Rate Policy And Capital Controls,'' 
% of the book ``Open Economy Macroeconomics,'' 
% by Mart�n Uribe and Stephanie Schmitt-Groh�, Princeton University Press.
%� Mart�n Uribe and Stephanie Schmitt-Groh�, 2016.

clear all
format compact

nw = 500;

load vfi_opt dpix d nd
%produced by running vfi_opt.m [Because sigg=1/xi, the policy functions for
%dp and cT are the same as those under optimal monetary policy. Thus we
%load them instead of recomputing them here.]

dpix_peg = dpix;
clear dpix;

load tpm.mat ygrid rgrid; %produced by running tpm.m (for documentation, see ``Finite-State Approximation Of VAR Processes: A Simulation Approach, by Stephanie Schmitt-Groh� and Mart�n Uribe, November 2014. )

ny = numel(ygrid); %number of grid points for log of tradable ouput
y = exp(ygrid(:)); %level of tradable output
clear ygrid

gama = 0.99; %degree of nominal wage rigidity

dpix = repmat(dpix_peg(:),nw,1);

betta = 0.9635; %discount factor

alfa = 0.75; %hours elasticity of nontraded output (Uribe, JME1997)

hbar = 1;  %full-employment hours

a = 0.26;% Share of traded consu mption (own computation)

xi = 0.5;% Elasticity of substitution between traded and nontraded goods 

sigg = 1/xi; %intertemporal elasticity of consumption  substitution. 

rstar = 0.0316; %average Argentine quarterly interest rate. Estimated using data from 1983:1 to 2001:4 

r = exp(rgrid)*(1+rstar)-1;  %country interest rate

rr = repmat(r,[nd*nw 1]);

wblower = 0.25;
wbupper = 6;
wb = log(wblower):(log(wbupper)-log(wblower))/(nw-1):log(wbupper);
wb = exp(wb(:));

n = ny*nd*nw;

filename = ['pfi_peg'];

dp = d(dpix);
cT = dp;

cT = cT./(1+rr);

dd = repmat(d',[ny 1 nw ]);
dd = reshape(dd,n,1);

cT =  cT - dd;% consumption of tradables

yT = repmat(y(:),[nd*nw 1]);

cT = yT + cT;%Only now do we have consumption of tradables

if min(max(cT))<0
error('Natural debt limit violated')
end

wf =  (1-a) / a * (hbar^alfa./abs(cT)).^(-1/xi) * alfa * hbar^(alfa-1); %full-employment real wage

wwb = repmat(wb',[ny*nd 1]);
wwb = wwb(:);

w = max(gama * wwb,wf); %real wage

w(w<wb(1)) = wb(1);
w(w>wb(end)) = wb(end);

dlwb  = log(wb(2)) - log(wb(1));
wix = round((log(w)-log(wb(1))) / dlwb )+1;

w = wb(wix);

h = (a / (1-a) * w / alfa.* abs(cT).^(-1/xi) ).^(1/(alfa-1-alfa/xi)); %hours

h = min(h,hbar);

cN = h.^alfa;

c = (a * abs(cT).^(1-1/xi) + (1-a) * cN.^(1-1/xi)).^(1/(1-1/xi));%composite consumption 

%Marginal utility of consumption of tradables (lambda_t)
la = a * abs(cT).^(-1/xi);

la(cT<0) = -inf;

%done with constructing latry

load tpm.mat pai  %produced by running tpm.m (for documentation, see ``Finite-State Approximation Of VAR Processes: A Simulation Approach, by Stephanie Schmitt-Groh� and Mart�n Uribe, November 2014. )

u = (c.^(1-sigg)-1)/ (1-sigg); %period utility

u = u(:);

%Compute the Value Function
v = zeros(n,1);
distv = 1;
yix = repmat((1:ny)',nd*nw,1);
I = sub2ind([ny nd nw],yix,dpix,wix);

while distv>1e-8
pai * reshape(v,ny,nd*nw);
v1 = u + betta *ans(I);
distv = max(abs(v-v1))
v = v1;
end %while distv

v = reshape(v,ny,nd,nw);
w = reshape(w,ny,nd,nw);
dp = reshape(dp,ny,nd,nw);


eval(['save ' filename '.mat gama filename nd ny nw  rstar betta sigg alfa hbar a xi pai y r  d wb dp  w v   ' ])