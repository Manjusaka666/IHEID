%debt_distrib.m
% plots the debt destribution in peg economies with optimal capital
% controls and free capital mobility shown in the figure
% with the caption ``The Distribution of External Debt in a  Currency Peg Economy Under Free Capital Mobility and Under Optimal Capital Controls,'' 
% of the chapter: 
%``Exchange Rate Policy And Capital Controls,'' 
% of the book ``Open Economy Macroeconomics,'' 
% by Mart�n Uribe and Stephanie Schmitt-Groh�, Princeton University Press.
%� Mart�n Uribe and Stephanie Schmitt-Groh�, 2016.


clear all
clf

load simu_pfi_peg d lad
%produced by running
%simu.m with the sintax simu('pfi_peg') in
%c:\data\uribe\book\capital_controls
dp = d;
ladp = lad/(d(2)-d(1));
clear d lad 

load simu_vfi_ramsey d lad 
%produced by running
%simu('vfi_ramsey') in
%c:\data\uribe\book\capital_controls
dr = d;
ladr = lad/(d(2)-d(1));

clf
h = plot(dp,ladp)
set(h,'linewidth',4)
hold on
h = plot(dr,ladr,'--')
set(h,'linewidth',4)


xlabel('External Debt, $d_t$','interpreter','LaTeX')
ylabel('Density')
legend('Free Capital Mobility','Optimal Capital Controls','Location','NorthWest')


hold off
shg