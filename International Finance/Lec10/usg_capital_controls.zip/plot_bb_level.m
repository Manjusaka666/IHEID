%plot_bb_level.m
%Produce a plot of the Boom-Bust Dynamics With and Without Capital Controls
% in Chapter 10 entitled ``Exchange Rate Policy And Capital Controls,'' of the book ``Open Economy Macroeconomics,'' by Mart�n 
%Uribe and Stephanie Schmitt-Groh�, Princeton University Press.
%� Mart�n Uribe and Stephanie Schmitt-Groh�, 2016.
clf , clear all

load bb_ramsey Yshock nyT nr ntaud ncT nunempl nc Tshock 
%produced by running
%z:\uribe\book\capital_controls\bb_ramsey.m

IR = Yshock; 

TIR = -20:20;

%the order of the variables is: x = [yT wcpi cT wf h cN c p D r TAUD infl 1-h (yT-cT)    D./(4*(yT+p.*cN)) W]

titles = {'Traded Output, $y^T_t$', 'Real (CPI) Wage, $W_t/P_t$',    'Traded Consumption, $c^T_t$', '$w_{f,t}$',    '$h_t$', 'Consumption of Nontradables, $c^N_t$',    'Consumption, $c_t$', 'Relative Price of Nontradables ($P^N_t/E_t$)', 'Net External Debt, $d_t$','Annualized Interest Rate, $r_t$', 'Capital Control Rate, $\tau^d_t$', 'Annual Inflation Rate, $\pi_t$',    'Unemployment Rate, $1-h_t$','Trade Balance, $y^T_t - c^T_t$', 'Debt to GDP Ratio, $d_t/(4 (p_t c^N_t + y^T_t))$', 'Real Wage, $W_t / E_t$'};

ylabels = {'level', '% per year', '%', 'level', '%', 'level'};

nir = [nyT nr ntaud ncT nunempl nc];

IR(:,[nr ntaud nunempl]) = 100* IR(:,[nr ntaud nunempl]);

orient tall
%for slides use: orient portrait 

    for j=1:numel(nir)
subplot(numel(nir)/2,2,j)
%For slides: subplot(3,numel(nir)/2,j)

kkk=plot(TIR+20,IR(TIR+Tshock,nir(j)),'--');
set(kkk, 'linewidth',4)
title(titles{nir(j)},'interpreter','LaTeX')
xlabel('quarter')
ylabel(ylabels{j})
hold on
end

load bb_peg  Yshock
%produced by running
%z:\uribe\book\capital_controls\bb_peg.m

IR = Yshock; 
IR(:,[nr ntaud nunempl]) = 100* IR(:,[nr ntaud nunempl]);

for j=1:numel(nir)
subplot(numel(nir)/2,2,j)
%For slides: subplot(3,numel(nir)/2,j)

kkk=plot(TIR+20,IR(TIR+Tshock,nir(j)));
set(kkk, 'linewidth',4)
end