%vfi_ramsey.m
%Use a value function iteration algorithm to compute the equilibrium  under Optimal  Capital Controls in the
%economy with downward nominal wage rigidity and a currency peg analyzed in the chapter entitled               
%``Exchange Rate Policy And Capital Controls,'' 
% of the book ``Open Economy Macroeconomics,'' 
% by Mart�n Uribe and Stephanie Schmitt-Groh�, Princeton University Press.
%� Mart�n Uribe and Stephanie Schmitt-Groh�, 2016.

clear all
format compact

load tpm.mat ygrid rgrid; 
%produced by running tpm.m
%c:\data\uribe\default\mfiles\one_bond\two_shocks\tpm.m

ny = numel(ygrid); %number of grid points for log of tradable ouput
y = exp(ygrid(:)); %level of tradable output

gama = 0.99; %degree of nominal wage rigidity

nd = 501;% # of grid points for debt, d_t
nw = 500; %number of grid points past real wage
ndptry = 21; 


betta = 0.9635; %discount factor


alfa = 0.75; %hours elasticity of nontraded output (Uribe, JME1997)

hbar = 1;  %full-employment hours

a = 0.26;% Share of traded consu mption (own computation)

xi = 0.5;% Elasticity of substitution between traded and nontraded goods (Sockman and Tesar, AER 1995)

sigg = 1/xi; %sigg = 5; %consujmption elasticity of marginal utility of consumption (Reinhart and Vegh, JDE 1995)


rstar = 0.0316; %0.027;%   0.0316; (<--this is the number estimated as the mean in Argentine data. we apply a haircut to reflect the role of the average debt-elastic premium) %average Argentine quarterly interest rate. Estimated using data from 1983:1 to 2001:4 in the program  c:\data\uribe\default\data\exogenous_process.m (we cut the post 2001 period because of the great default of 2001, since our current model does not feature default).

r = exp(rgrid)*(1+rstar)-1; 

rtry = repmat(r,[nd*nw ndptry]);
save -v7.3 rtry rtry
clear rtry

%Natural borrowing limit
dupper = 8;
dlower = -7;
d = dlower:(dupper-dlower)/(nd-1):dupper;
d = d(:);

wbupper = 6;%5.3; %=  4.5;
wblower = 0.25;%0.5;%0.2;

wb = log(wblower):(log(wbupper)-log(wblower))/(nw-1):log(wbupper);
wb = exp(wb(:));

%wb = wblower:(wbupper-wblower)/(nw-1):wbupper;
%wb = wb(:);

n = ny*nd*nw;

filename = [ 'vfi_ramsey']


sndptry = (ndptry-1)/2;
for i=1:nd
if i>sndptry&i<=nd-sndptry
dptryix(i,:) = (i-sndptry:i+sndptry);
elseif i<=sndptry
dptryix(i,:) = (1:1+2*sndptry);
else
dptryix(i,:) = (nd-2*sndptry:nd);
end %if i<...
end %for i=1:nd
dptryix = kron(dptryix,ones(ny,1));
dptryix = repmat(dptryix,[nw 1]);
%save -v7.3 dptryix.mat  dptryix

%hit_high=1 if the solution for dp does not involve picking the upper bound of dptry or it does but dp is dupper, and zero ottherwise; hit_low=1 if the solution for dp does not involve picking the lower bound of dptry  or it does but  dp is dlower, and zero ottherwise;
hit_high = 0;
hit_low = 0;
iter = 1;
iter_target = 25;
v = zeros(ny,nd,nw);
%load vfi_ramsey v

while (hit_high*hit_low == 0) | (iter==iter_target)

if hit_high*hit_low == 1
iter_target = 1000
end

dptry = d(dptryix);
%save -v7.3 dptryix dptryix
%clear dptryix
cTtry = dptry;
clear dptry

load rtry

cTtry = cTtry./(1+rtry);
clear rtry

dtry = repmat(d',[ny 1 nw ndptry]);
dtry = reshape(dtry,n,ndptry);

cTtry =  cTtry - dtry;% consumption of tradables

clear  dtry 

yTtry = repmat(y(:),[nd*nw ndptry]);

cTtry = yTtry + cTtry;%Only now do we have consumption of tradables

clear yTtry 

if min(max(cTtry,[],2))<0
error('Natural debt limit violated')
end

wftry =  (1-a) / a * (hbar^alfa./abs(cTtry)).^(-1/xi) * alfa * hbar^(alfa-1); %full-employment real wage
 %up to here max 34.0 memory
wbtry = repmat(wb',[ny*nd 1]);
wbtry = repmat(wbtry(:),[1 ndptry]);
 %up to 50.5 G
wtry = max(gama * wbtry,wftry); %real wage

clear wftry wbtry

wtry(wtry<wb(1)) = wb(1);
wtry(wtry>wb(end)) = wb(end);

dlwb  = log(wb(2)) - log(wb(1));
wtryix = round((log(wtry)-log(wb(1))) / dlwb )+1;

wtry = wb(wtryix);
save -v7.3 wtryix wtryix
clear wtryix

htry = (a / (1-a) * wtry / alfa.* abs(cTtry).^(-1/xi) ).^(1/(alfa-1-alfa/xi)); %hours

clear wtry

htry = min(htry,hbar);

cNtry = htry.^alfa;

save -v7.3 htry.mat htry
clear htry

%ctry = (a * abs(cTtry).^(1-1/xi) + (1-a) * cNtry.^(1-1/xi)).^(1/(1-1/xi));%composite consumption 

utry = (a * abs(cTtry).^(1-1/xi) + (1-a) * cNtry.^(1-1/xi) -1) / (1-sigg); %period utility function in the special case sigg=1/xi

clear cNtry

%utry = (ctry.^(1-sigg) - 1) / (1-sigg);

%clear ctry 

utry(cTtry<0) = -inf;

%save -v7.3 utry.mat utry

save -v7.3 cTtry.mat cTtry
clear cTtry

%load dptryix
load wtryix

Itry = sub2ind(size(v),repmat((1:ny)',[nd*nw ndptry]),nd * (wtryix-1)+ dptryix);

clear  wtryix

load rtry rtry
 dpfpixold = 0;
% dpixold = 0;

 %dp stands for debt chosen today and due next period
%fp stands for fewer points (we look only at a window around the current debt level, as opposed to at the entire debt grid)
%ix stands for index
load tpm.mat pai

dist = 1; iter = 1;

while dist> 1e-8 & iter<iter_target
    iter = iter+1

ev = pai *  reshape(v,ny,nd*nw);

Evptry = ev(Itry);

clear ev

[vnew, dpfpix] = max(utry+betta*Evptry,[],2);
dist = max(abs(vnew(:)-v(:))) + max(abs(dpfpix(:)-dpfpixold(:)))

v = vnew;

if (dpfpixold==dpfpix)&(dist>1e-4) 
distv = 1
u = utry(sub2ind(size(utry),(1:n)',dpfpix));

load wtryix
wix = wtryix(sub2ind(size(wtryix),(1:n)',dpfpix));
clear wtryix
I = sub2ind(size(reshape(v,ny,nd,nw)),repmat((1:ny)',[nd*nw 1]),nd * (wix-1)+ dptryix(sub2ind(size(dptryix), (1:n)', dpfpix)));

while distv>1e-8

pai * reshape(v,ny,nd*nw);
v1 = u + betta *ans(I);

distv = max(abs(v-v1))
v = v1;

end %while distv

end %if dpfpixold==dpfpix

dpfpixold = dpfpix;

end %while dist>1e-4&h<10

%8:58pm checked until here

disp('finished the loop, next try to save')

load wtryix
wix = wtryix(sub2ind(size(wtryix),(1:n)',dpfpix));

v = reshape(v,ny,nd,nw);

%load dptryix

sub2ind(size(dptryix),(1:n)',dpfpix);

dp = reshape(d(dptryix(ans)),ny,nd,nw);

w = wb(reshape(wix,ny,nd,nw));

%Check whether subgrid is too small
%Recall: nd is grid size for d
%        ndptry is grid size for dptry
%Step 1: Check whether when dpfpix = ndptry, ie when it  picks the upper limit of the
%smaller grid, there are points in the true grid d that could have been
%chosen

a_up=find(dpfpix==ndptry & dp(:)~=d(end));%find cases when the upper limit of ndptry grid is chosen and it is not equal to dupper
%if a_up is empty (that is you never hit the upper bound or you hit it when dp=dupper)
if  isempty(a_up) 
hit_high = 1 %1==> no probolem; 0==>problem
else %update dptryix
    hit_high = 0
dptryix(a_up,:) = (dptryix(a_up,:)+sndptry) .* repmat(dptryix(a_up,end)<=nd-sndptry,[1 ndptry]) + repmat(nd-ndptry+1:nd,[numel(a_up) 1]) .* (1-repmat(dptryix(a_up,end)<=nd-sndptry,[1 ndptry]));
end %if isempty(a_up)

%now check the case that dpfpix =1; Is dptry=dlower?
a_lo=find(dpfpix==1 & dp(:)~=d(1));%find index of dptry grid at lower bound and not equal to dlower
if isempty(a_lo) 
hit_low = 1 %1==> no probolem; 0==>problem
else %update dptryix
    hit_low = 0
    dptryix(a_lo,:) = (dptryix(a_lo,:)-sndptry) .* repmat(dptryix(a_lo,1)>sndptry,[1 ndptry]) + repmat(1:ndptry,[numel(a_lo) 1]) .* (1-repmat(dptryix(a_lo,1)>sndptry,[1 ndptry]));
end %if isempty(a_lo)

end %while hit_high*hit_low == 0 | h==25

load wtryix
wix = wtryix(sub2ind(size(wtryix),(1:n)',dpfpix));
clear wtryix
I = sub2ind(size(reshape(v,ny,nd,nw)),repmat((1:ny)',[nd*nw 1]),nd * (wix-1)+ dptryix(sub2ind(size(dptryix), (1:n)', dpfpix)));

%These variables are needed to compute z
load htry htry
hours = htry(sub2ind(size(htry),(1:n)',dpfpix));
clear htry
load cTtry cTtry
cT = cTtry(sub2ind(size(cTtry),(1:n)',dpfpix));
clear cTtry;
cN = hours.^alfa;
c = (a * cT.^(1-1/xi) + (1-a) * cN.^(1-1/xi)).^(1/(1-1/xi));

%la = c.^(-sigg) * a .* (c./cT).^(1/xi);
la = a .* cT.^(-1/xi); %marginal utility of wealth, special case sigg=1/xi;

rr = repmat(r,nd*nw,1) + 1;

%The optimal tax on debt, taud
pai * reshape(la,ny,nd*nw); %Expected t+1 marginal utility of wealth given information available in t
taud = 1 - ( betta *rr   .*ans(I)) ./ la;
taud = reshape(taud,ny,nd,nw);

eval(['save ' filename '.mat ygrid rgrid gama filename nd ny nw  rstar betta sigg alfa hbar a xi pai y r  d wb v dpfpix dp wix w  hit_low hit_high ndptry hours cT cN c taud ' ])

!del cTtry.mat
!del htry.mat
!del rtry.mat
!del wtryix.mat