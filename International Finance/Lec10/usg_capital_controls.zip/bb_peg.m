%bb_peg.m
%Compute the Boom-Bust Dynamics under Free Capital Mobility  in the
%peg economy analyzed in  the chapter entitled               
%``Exchange Rate Policy And Capital Controls,'' 
% of the book ``Open Economy Macroeconomics,'' 
% by Mart�n Uribe and Stephanie Schmitt-Groh�, Princeton University Press.
%� Mart�n Uribe and Stephanie Schmitt-Groh�, 2016.

clear all

filename = 'pfi_peg.mat' 
%created by running 
%pfi_peg.m
%and setting
% [wb(1) wb(end)  nw] = 
%      0.25    6   500


N = 20e+6; %number of simulation periods (quarters)
Nburn = 10000; %burn-in period
Tshock = 101; %period in which shock occurs
TIR = -20:20; %window of time around Tshock 
T = Tshock*2-1; %length of each episode
nvar = 17; %number of variables for which IR are computed

output_shock_boom = 0.12;
output_shock_bust = -0.12; %traugh of tradable ouput

%load parameter values
eval(['load ' filename  ' y r d wb pai  w dp  hbar a alfa xi ny nw nd rstar gama' ])

uy = unique(y);
[yTshock_boom,iyTshock_boom] = min(abs(log(uy)-output_shock_boom));
yTshock_boom = uy(iyTshock_boom);

[yTshock_bust,iyTshock_bust] = min(abs(log(uy)-output_shock_bust));
yTshock_bust = uy(iyTshock_bust);

%Set initial conditions of tradable output, debt, and past wage equal to their respective unconditional means
y0 = y(round(ny/2));
r0 = r(round(ny/2));
d0 = d(round(nd/2));
wb0 = wb(round(nw/2));

%pai is the transition probability matrix of tradable output. Cpai is the cumulative probability matrix (useful for drawing tradable output realizations)
Cpai = cumsum(pai,2); 

%Initialize vector of impulse responses

X = zeros(T,nvar);
EY = zeros(1,nvar);
Yshock = zeros(T,nvar);

pb = 1;
n = 0;
nshock = 0;
nnshock = 0;
nrepeat = 0;

while n<=N
n = n+1;

yT = y0;
R = r0;
D = d0;
i = find(y==y0&r==r0);
j = find(d==d0);
k = find(wb==wb0);
W =w(i,j,k); %real wage rate
wage_inflation = W/wb0; 
wb0 = W;
d0 = dp(i,j,k); 
L = sum(Cpai(i,:)<rand)+1;
y0 = y(L);
r0 = r(L);
cT = yT + d0 ./ (1+R) - D;
wf = (1-a) / a * (hbar^alfa./cT).^(-1/xi) * alfa * hbar^(alfa-1);%full-employment real wage rate in terms of tradables
h = (a / (1-a) * W  / alfa.* cT .^(-1/xi) ).^(1/(alfa-1-alfa/xi)); 
h = min(hbar,h);
cN = h.^alfa; %nontradable consumption
c = (a*cT.^(1-1/xi) + (1-a) * cN.^(1-1/xi)).^(1/(1-1/xi)); 
p = (1-a) / a * (cN./cT).^(-1/xi);
%pc = (a^xi + (1-a)^xi * p.^(1-xi)).^(1/(1-xi));
pc = 1/a * (cT./c).^(1/xi); 
wcpi = W ./ pc;
epsi =0*W+1;
TAUD = epsi*0; %tax rate on debt
infl = epsi .* ((a^xi + (1-a)^xi * p.^(1-xi)) ./ (a^xi + (1-a)^xi * pb.^(1-xi))).^(1/(1-xi));


pb = p;

x = [yT wcpi cT wf h cN c p D R TAUD infl 1-h (yT-cT) D./(4*(yT+p.*cN)) W wage_inflation];
X = [X(2:end,:); x];

if n > Nburn
m = n-Nburn;

%Annualize inflation and interest rates
Y = [X(:,1:8) X(:,9) X(:,10)*4 X(:,11) (X(:,12)-1)*4 X(:,13:16) (X(:, 17)-1)*4];
%Computing the unconditional mean
EY = EY *(m-1)/m + Y(end,:)/m;


%find crisis episodes, yT>=1+std at t=0 and yT< 1-std at t=10
if X(Tshock,1)<= yTshock_bust & X(Tshock-10,1)>=  yTshock_boom & X(Tshock-20,1)<=  1

nshock = nshock+1;

if n-nnshock<10
nrepeat = nrepeat +1;
end

nnshock = n;

Yshock = Yshock *(nshock-1)/nshock + Y/nshock;
end %if X(1,1==yTshock


end %if n>Nburn

end %while n<=N

%Express as deviations from unconditional mena
IR = Yshock - repmat(EY,T,1); 

%Express the first 8 variables as proportional deviations from mean
IR(:,[1:8 16])  = IR(:,[1:8 16])./ repmat(EY([1:8 16]),T,1);


%make a plot
nyT=1; nwcpi=2; ncT=3; nwf=4; nh=5; ncN=6; nc=7; np=8; nD=9; nr=10; ntaud=11; ninfl=12; nunempl=13;ntb=14;
ndy = 15; nw = 16; nwage_inflation = 17;
var_name = {'$\ln (y^T)$','$\ln(w^{cpi})$','$\ln(c^T)$','$\ln(w_f)$','$\ln (h)$','$\ln (c^N)$','$\ln (c)$','$\ln (p)$','d','$4\times r$','$\tau^d$','$4\times (\pi-1)$','$1-h$','$y^T-c^T$', '$d/4/(y^T+pc^N)$', 'W/E', 'Wage Inflation'};
nir = [nyT ntb  nunempl nc nD nr np nwcpi ntaud ninfl ndy nw nwage_inflation];

save bb_peg.mat 
 