%table_mean_std.m
% Produces the table  with the caption ``Optimal Capital Controls and Currency Pegs: Level Vs. Volatility Effects,'' 
% of the chapter: 
%``Exchange Rate Policy And Capital Controls,'' 
% of the book ``Open Economy Macroeconomics,'' 
% by Mart�n Uribe and Stephanie Schmitt-Groh�, Princeton University Press.
%� Mart�n Uribe and Stephanie Schmitt-Groh�, 2016.

clear all
load simu_vfi_ramsey.mat  table_vfi_ramsey
%produced by running
%simu.m with the syntax simu('vfi_ramsey') 
%c:\data\uribe\book\capital_controls\

load simu_pfi_peg.mat  table_pfi_peg
%produced by running 
%simu.m with the syntax simu('pfi_peg') 
%c:\data\uribe\book\capital_controls\

[z1,z2] = size(table_vfi_ramsey);

table(1:2:2*z1-1,1:z2) =  table_pfi_peg;  
table(2:2:2*z1,1:z2) = table_vfi_ramsey;

tabletex(table,1)