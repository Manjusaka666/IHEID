%usg_plot_density.m
%produces a figure with ergodic debt distributions  for the soe rbc model with impatience solved with global methods.  The model solution is computed by value function iteration the  equilibrium of the SOE RBC model studied in the chapter entitled ``The Open Economy Real Business Cycle Model'' section ``Inducing Stationarity Through Impaticence and Global Solutions,''  of 
%Uribe's and Schmitt-Grohe's ``Open Economy Macroeconomics.'' The model is identical to  the one called EDEIR 
%in USG, except that the discount factor is constant and satisfies betta*(1+r)<1.
%(c) Mart�n Uribe, June 2016.

load usg_vfi2 %baseline  calibration
%produced by running
%usg_vfi.m and setting ncal=2
dgrid2 = dgrid;
paid2 = paid;
subplot(2,2,[3 4])
plot(dgrid,paid,'-','linewidth',2)
h=title(['$\bar{d}=$ ' num2str(dupper,1) ' and $\beta(1+r^*)=$ ' num2str(betta*(1+r),4)] ,'interpreter','LaTeX')
xlabel('d')
xlim([dlower dupper])


load usg_vfi1 %Natural-Debt-Limit calibraiton
%produced by running
%usg_vfi.m and setting ncal=1
dgrid1 = dgrid;
paid1 = paid;
subplot(2,2,1)
plot(dgrid,paid,'-','linewidth',2)
h=title(['$\bar{d}=$ '  num2str(dupper,  '%0.3g')  ' and $\beta(1+r^*)=$ ' num2str(betta*(1+r),4)] ,'interpreter','LaTeX')
xlabel('d')
xlim([dlower dupper])


load usg_vfi3 %High Patience calibration
%produced by running
%usg_vfi.m and setting ncal=2
dgrid3 = dgrid;
paid3 = paid;
subplot(2,2,2)
plot(dgrid,paid,'-','linewidth',2)
h=title(['$\bar{d}=$ ' num2str(dupper,1) ' and $\beta(1+r^*)=$ ' num2str(betta*(1+r),4)] ,'interpreter','LaTeX')
xlabel('d')
xlim([dlower dupper])

shg

