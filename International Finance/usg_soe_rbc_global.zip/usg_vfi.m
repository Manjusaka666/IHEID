%usg_vfi.m computes by value function iteration the  equilibrium of the SOE RBC model studied in  the chapter entitled ``The Open Economy Real Business Cycle Model'' section ``Inducing Stationarity Through Impaticence and Global Solutions,''  of  
%Uribe's and Schmitt-Grohe's ``Open Economy Macroeconomics.'' The model is identical to  the one called EDEIR 
%in USG, except that the discount factor is constant and satisfies betta*(1+r)<1.
%(c) Mart�n Uribe, February 2015.

clear all

%the columns of matris calibration are: betta dlower dupper klower kupper
calibration =[
    0.9540    7.45   9.95  2.85     3.7461
    0.9540         0.6667    1.0000    2.24    3.6300
    0.9600         0    1.0000    2.5000    4.0000
]

ncal = 2; %pick a row of calibration (baseline 2)
betta = calibration(ncal,1);
dlower = calibration(ncal,2);
dupper = calibration(ncal,3);
klower = calibration(ncal,4);
kupper = calibration(ncal,5);


format compact

load usg_tpm.mat zgrid  pai

nz = numel(zgrid); %number of grid points for log of technology shock

for i=1:nz
a = pai(i,:);
[~,k] = max(a);
a(k) = 0;
pai(i,k) = 1-sum(a);
end

omega = 1.455; %degree of nominal wage rigidity

%dbar = 0.7442; %ss debt

phi = 0.028; %capital adjustment cost parameter

nd = 70;% # of grid points for debt, d_t
nk = 30; %number of grid points of capital

alfa = 0.32; %capital semielasticity of output

delta = 0.1; %depreciation rate

sigg = 2; %Elasticity of intertemporal substitutiion

r = 0.04;  %world interest rate

%betta = 0.96; %subjective discount factor

g =  0;%     %constant gov't spending

%Natural borrowing limit
%dupper = 2;
%dlower = 1;
dgrid =  linspace(dlower,dupper,nd)';

kss =    3.397685279738449; %steady-state capital stock, obtained by running edeir_ss.m in 
%c:\data\uribe\book\soe_rbc\edeir
%kupper =     4;
%klower = 2.5
kgrid = linspace(klower,kupper,nk)';

%create d and k grids for trials
kkgrid = repmat(kgrid',nd,1);
kkgrid = kkgrid(:);
ddgrid = repmat(dgrid,nk,1);

n = nz*nd*nk;

z = repmat(zgrid,nd*nk,1); 

d = repmat(dgrid',nz,nk);
d = d(:);

k = repmat(kgrid',nz*nd,1);
k = k(:);

h  = ((1-alfa) * exp(z) .* k.^alfa).^(1/(alfa+omega-1));

y = exp(z) .* k.^alfa .* h.^(1-alfa); 

ctry = bsxfun(@(x,y) x+y,y-(1+r)*d-g,ddgrid');% consumption 

ctry = ctry-bsxfun(@(x,y) y-(1-delta)*x+phi/2*(y-x).^2,k,kkgrid');

ctry = bsxfun(@(x,y) x-y.^omega/omega,ctry,h);

utry = -inf(n,nd*nk);
utry(ctry>0) = (ctry(ctry>0).^(1-sigg)-1)/(1-sigg);

clear ctry

v = zeros(nz,nd,nk);
vnew = v; 

dist = 1;
while dist>1e-8

Ev = pai*v(:,:);
Ev = repmat(Ev,nd*nk,1);

[vnew(:),b] = max(utry+betta*Ev,[],2);

dist = max(abs(v(:)-vnew(:)))

v = vnew;

end

kp = kkgrid(b);
dp = ddgrid(b);

iv = kp - (1-delta)*k + phi/2 * (kp-k).^2;

c = y -iv -g -d*(1+r) + dp;
tb = y-c-iv - g;
ca = -(dp-d);
tby = tb./y;
cay = ca./y;

zix = repmat((1:nz)',nd*nk,1);
[dpix,kpix] = ind2sub([nd nk],b);

PAI = sparse(n,n);
for i=1:n
m1 = sub2ind([nz nd nk],1,dpix(i),kpix(i));
PAI(i,m1:m1+nz-1) = pai(zix(i),:);
end
PAI = sparse(PAI);

uPAI = usg_uncond_distrib(PAI,1e-5);

x = zeros(nz,nd,nk);
x(:) = uPAI;
paiz = sum(x(:,:),2);
paid = sum(x,3);
paid = sum(paid)';
paik = sum(x,1);
paik = sum(paik,2);
paik=paik(:);

clear *try
eval(['save -v7.3  usg_vfi' num2str(ncal)  '.mat'])