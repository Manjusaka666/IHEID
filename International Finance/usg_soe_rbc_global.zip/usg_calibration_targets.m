%usg_calibration_targets.m produces a table useful for understanding the calibration chosen for the computariion of the soe rbc model solved with global methods.  The model solution is computed by value function iteration.  The SOE RBC model  is the one studied in the chapter entitled ``The Open Economy Real Business Cycle Model'' section ``Inducing Stationarity Through Impaticence and Global Solutions,''  of 
%Uribe's and Schmitt-Grohe's ``Open Economy Macroeconomics,'' Princeton University Press.  The model is identical to  the one called EDEIR 
%in USG, except that here the discount factor is constant and satisfies betta*(1+r)<1.
%(c) Mart�n Uribe, June 2016.

clear all
%Baseline calibration
load predictions_usg_vfi2.mat  
%produced by running 
%usg_predictions.m in
%and setting 
%filename = 'usg_vfi2'
usg_table_targets(1,1:5) = [betta betta*(1+r) dupper 100*Ex(5) SDx1(3)*100];

%Natural Debt Limit calibration
load predictions_usg_vfi1.mat  
%produced by running 
%usg_predictions.m 
% and setting 
%filename = 'usg_vfi1'
usg_table_targets(2,1:5) = [betta betta*(1+r) dupper 100*Ex(5) SDx1(3)*100];

%High-Patience calibration
load predictions_usg_vfi3.mat  
%produced by running 
%usg_predictions.m 
%and setting 
%filename = 'usg_vfi3'
usg_table_targets(3,1:5) = [betta betta*(1+r) dupper 100*Ex(5) SDx1(3)*100];

usg_table_targets