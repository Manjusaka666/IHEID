 %predictions.m  produces a table with unconditional second moments for the soe rbc model with impatience solved with global methods.  The model solution is computed by value function iteration the  equilibrium of the SOE RBC model studied in the chapter entitled ``The Open Economy Real Business Cycle Model'' section ``Inducing Stationarity Through Impaticence and Global Solutions,''  of 
%Uribe's and Schmitt-Grohe's ``Open Economy Macroeconomics.'' The model is identical to  the one called EDEIR 
%in USG, except that the discount factor is constant and satisfies betta*(1+r)<1.
%(c) Mart�n Uribe, June 2016.

clear all
format compact

filename = 'usg_vfi2'
eval(['load ' filename])
%Note:
%The files usg_vfi1.mat, usg_vfi2.mat, and usg_vfi3.mat used in this program must be  produced by running usg_vfi.m in
%and setting mcal to the values specified as follows:
%usg_vfi1.mat contains policy functions for the Natural-Debt-Limit Calibration (set ncal = 1 in usg_vfi.m). 
%usg_vfi2.mat contains policy functions for the Baseline calibration (set ncal = 2 in usg_vfi.m). And
%usg_vfi3.mat contains policy functions for the  High-Paticence calibration (set ncal = 3 in usg_vfi.m). 

%unconditional means of y c iv h
x = [y c iv h tby cay];

%unconditional expectations
Ex = uPAI'*x;

%divide y c iv h by their respective uncond. means (as opposed to taking logs, because iv is negative in some states)
x1 = [[y/Ex(1) c/Ex(2) iv/Ex(3) h/Ex(4)-1] tby-Ex(5) cay-Ex(6)];

%unconditional  first and second moments
 [Ex1,Vx1,SDx1,Corrx1,Scorrx1] = usg_moments_tpm(PAI,x1,1,uPAI);

%extract sedond moments for table (std dev, autocorr, and corr with output)

disp('Columns are: std, serial correlation, corr. w. output.  Rows are: y, c, i, h, tb/y, ca/y')
usg_table = [SDx1'*100 Scorrx1' Corrx1(:,1)]

eval(['save predictions_' filename ' betta r  dupper Ex SDx1 '])