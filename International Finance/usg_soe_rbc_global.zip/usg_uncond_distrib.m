function P = uncond_distrib(TPM,tol);
% P = uncond_distrib(TPM) computes the unconditions distribution P associated with the transition probability matrix TPM.
%P = uncond_distrib(TPM,tol) accepts a tolerance for the precision of P (default 1e-8). 
%
%(c) Martin Uribe, May 31, 2013.

if nargin<2
tol = 1e-8;
end

K = size(TPM,1);
dist_tpm = 1;
P = ones(1,K)/K;
while dist_tpm>tol
Pnew = P*TPM;
dist_tpm = max(abs(P(:)-Pnew(:)));
P = Pnew;
end
P = P(:);