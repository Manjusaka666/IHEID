%usg_ir_rbc_global.m
% produces impulse responses  to a technology shock  implied by the soe rbc model with impatience solved with global methods.  The model solution is computed by value function iteration the  equilibrium of the SOE RBC model studied in the chapter entitled ``The Open Economy Real Business Cycle Model'' section ``Inducing Stationarity Through Impaticence and Global Solutions,''  of 
%Uribe's and Schmitt-Grohe's ``Open Economy Macroeconomics.'' The model is identical to  the one called EDEIR 
%in USG, except that the discount factor is constant and satisfies betta*(1+r)<1.
%(c) Mart�n Uribe, June 2016.
clear all
clf 

load usg_vfi2 PAI uPAI y c iv tby cay h z zix
%produced by running vfi.m 
%and setting ncal = 2
%this file contains the policy functions associated with the baseline calibration

s = find(zix==6);  %initial state of the economy (zxi(6) is about one standard deviation of the innovation of z).
%Note, s is a vector, since all that is in the information set is the knowledge that zxi=6 in the initial period

X1 = [y c iv h];
EX1 = uPAI'*X1;
x1 = bsxfun(@(x,y) (x./y-1)*100,X1,EX1);
X2 = [tby z cay];
EX2 = uPAI'*X2;
x2 = bsxfun(@(x,y) (x-y)*100,X2,EX2);
x = [x1 x2];

T = 11;
IR = usg_ir_tpm(PAI,uPAI,x,s,T);

IR = IR/IR(1,6);
t = (0:10)';

subplot(3,2,1)
plot(t,IR(:,1),'linewidth',3)
title('Output')
ylabel('% dev from mean')
subplot(3,2,1)

subplot(3,2,2)
plot(t,IR(:,2),'linewidth',3)
title('Consumption')
ylabel('% dev from mean')


subplot(3,2,3)
plot(t,IR(:,3),'linewidth',3)
title('Investment')
ylabel('% dev from mean')

subplot(3,2,4)
plot(t,IR(:,4),'linewidth',3)
title('Hours')
ylabel('% dev from mean')

subplot(3,2,5)
plot(t,IR(:,5),'linewidth',3)
title('Trade Balance / Output')
ylabel('dev from mean in %')


subplot(3,2,6)
plot(t,IR(:,6),'linewidth',3)
title('TFP Shock')
ylabel('% dev from mean')


%print -deps ../../figures/soe_rbc_vfi_ir.eps