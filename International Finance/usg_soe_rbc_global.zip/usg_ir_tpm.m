function IR = usg_ir_tpm(PAI,uPAI,x,s,T)
%IR = ir_tpm(PAI,uPAI,x,s,T) is the impulse response of the variables in x to a shock specified by s
%PAI is the transition probability matrix associted with x
%uPAI is the unconditional probability  distribution of x
%x is a matrix with as many rows as the order of PAI and as many columns as the number of variables
%s is a vector of indices defining the information set in the first period. For example, if all that is known is that in the initial period the economy  is in states 2, 7, or 13, then s=[2 7 13];
%
%(c) Mart�n Uribe, 05-Apr-2015.
 
if nargin<5
T=21 %number of periods
end;

v = size(x,2); %number of variables

PAI0 = zeros(size(x(:,1)));
PAI0(s) = uPAI(s);
PAI0 = PAI0./sum(PAI0);

for t=1:T
bsxfun(@(x,y) x.*y,x,PAI0);
IR(t,1:v) = sum(ans);
x = PAI*x;
end