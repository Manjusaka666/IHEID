Replication files for regressions in  ``Country Spreads and Emerging Countries: Who Drives Whom?,' by Mart�n Uribe and  Vivian Z. Yue, Journal of International Economics, 69, June 2006, 6-36. 

finaldata.xls raw data

statadata.xls detrended data used in the estimation

finalstata.dta data in stata format

statacommands.do stata commands for estimation

stataresult_inpaper.txt  log file for the estimation using Stata