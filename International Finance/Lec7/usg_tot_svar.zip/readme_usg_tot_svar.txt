Data Set and Replication files for the Empirical Analysis in  the chapter entitled ``Importable Goods, Exportable Goods  and the Terms of Trade'' of the book `Open Economy Macroeconomics,' by Mart�n Uribe and Stephanie Schmitt-Groh�, Princeton University Press 2017. 
%� Mart�n Uribe and Stephanie Schmitt-Groh�, 2016. 

Data Set
 usg_tot_data.mat   
 This file contains the detrended data used in the SVAR analysis of the chapter  entitled ``Importable Goods, Exportable Goods  and the Terms of Trade"  in the book ``Open Economy Macroeconomics," by Mart�n Uribe and Stephanie Schmitt-Groh�, Princeton University Press 2017.  The data is contained in the cell tot_data. Each element of tot_data is a 6-column matrix for a particular  country. Rows are years and columns are variables (date,  tot, tb, gdp, c, i, in this order). The order of countries is given in the cell country. For example tot_data{23} is a 32x6 matrix containing the data for India.

Replication Files
Table 7.1  table_ar1_cbc
Figure 7.1 tot_ir_cbc.m (set sizevar=2)
Figure 7.2 ors_test.m
Figure 7.3 edeir_ir.m
Figure 7.4 tot_corr_tb_tot_rho.m
Figure 7.5 tot_ir_cbc.m (set sizevar=5)
Table 7.2 table_v_share_cbc.m

replication file for tot_svar_2eqn.mat: tot_cbcs.m  (set sizevar = 2)

replication file for tot_svar_5eqn.mat: tot_cbcs.m  (set sizevar = 5)
)

Note. Some scripts require downloading the toolkkit for  solving DSGE models up to first order, available at http://www.columbia.edu/~mu2166/1st_order/1st_order.htm 