%EDEIR_RUN.M
%Compute a first-order approximation, second moments, and impulse responses  implied by  the Small Open Economy Model With An External Debt-Elastic Interest Rate driven by terms-of-trade shocks  as presented  in the chapter entitled ``Importable Goods, Exportable Goods  and the Terms of Trade'' of the book `Open Economy Macroeconomics,' by Mart�n Uribe and Stephanie Schmitt-Groh�, Princeton University Press 2017.  
%� Mart�n Uribe and Stephanie Schmitt-Groh�, 2016. 

clear all

edeir_ss
i = 1;
for RHO=(-0.5:0.01:0.99)
rho(i,1) = RHO;
edeir_num_eval %this .m script was created by running edeir_model.m 

%The linearized equilibrium system is of the form
%y_t=gx x_t
%x_t+1 = hx x_t + ETASHOCK epsilon_t+1
[gx, hx, exitflag] = gx_hx(nfy, nfx, nfyp, nfxp);

nx = size(hx,1); %number of states

%Variance/Covariance matrix of innovation to state vector x_t
varshock = nETASHOCK*nETASHOCK';

%Position of variables in the control vector
noutput = 3; %output
nc = 1; %consumption
nivv = 2; %investment
nh = 4; %hours
ntb = 7; %trade balance
ntby = 8; %trade-balance-to-output ratio
nca = 9; %current account
ncay = 10; %current-account-to-output ratio
ntb_o_tot = 11;

%Position of variables in the state vector
nd = 1; %debt
nrb = 2; %Past interest rate (back one period)
nk = 3; %capital
na = 4; %TFP

%add TFP as the last row of gx
gx(end+1,end) = 1;
nac = size(gx,1); %position of tfp in control vector

%standard deviations
 [sigy0,sigx0]=mom(gx,hx,varshock);
stds = sqrt(diag(sigy0));

%correlations with tfp
sigy0(:,nac)./stds(nac)./stds;

corr_tba(i,1) = ans(ntb);
corr_tba1(i,1) = ans(ntb_o_tot);

x0 = zeros(size(gx,2),1);
x0(na) = 10;
IR = ir(gx,hx,x0,1);
ir_tb(i,1) = IR(1,ntb);

i = i+1;
end
%plot(rho,ir_tb,'linewidth',3),shg