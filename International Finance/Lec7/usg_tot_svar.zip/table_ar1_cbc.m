%table_ar1_cbc
%country-by-country estimation of AR(1)   ot terms-of-trade process in the chapter entitled ``Importable Goods, Exportable Goods  and the Terms of Trade'' of the book `Open Economy Macroeconomics,' by Mart�n Uribe and Stephanie Schmitt-Groh�, Princeton University Press 2017. 
%� Mart�n Uribe and Stephanie Schmitt-Groh�, 2016. 
clear all, clc
load tot_cbcs2
%produced by running 
%tot_cbcs.m  (set sizevar = 2)

for k=1:ncou
a = [country{k} ' ' num2str([hx(1,1,k) PI(1,1,k) R2(1,k)])];
disp(a)
end



hx11 = mean(hx(1,1,:));
median_hx11 = median(hx(1,1,:));
mad_hx11 = mad(hx(1,1,:));
[~, hx11_ix]=sort(hx(1,1,:));
hx11_q25 = hx11_ix(round(ncou*0.25));
hx11_q75 = hx11_ix(round(ncou*0.75));
iqr_hx11 = squeeze(hx(1,1,[hx11_q25 hx11_q75]));

PI11 = mean(PI(1,1,:));
median_PI11 = median(PI(1,1,:));
[~, PI11_ix]=sort(PI(1,1,:));
PI11_q25 = PI11_ix(round(ncou*0.25));
PI11_q75 = PI11_ix(round(ncou*0.75));
iqr_PI11 = squeeze(PI(1,1,[PI11_q25 PI11_q75]));


R21 = mean(R2(1,:));
median_R21 = median(R2(1,:));
[~, R21_ix]=sort(R2(1,:));
R21_q25 = R21_ix(round(ncou*0.25));
R21_q75 = R21_ix(round(ncou*0.75));
iqr_R21 = squeeze(R2(1,[R21_q25 R21_q75]));




x = [hx11 PI11 R21];
b = ['Mean ' num2str(x)];
disp(b)

x = [median_hx11 median_PI11 median_R21];
b = ['Median ' num2str(x)];
disp(b)

x=[iqr_hx11 iqr_PI11 iqr_R21(:)];
b = ['Interquartile Range ' num2str(x(1,:))];
disp(b)
b = [ num2str(x(2,:))];
disp(b)