%tot_ir_cbc
%Impulse responses to a 10 percent positive  innovation in the terms of trade  implied by the empirical SVAR systems  studied in the chapter entitled ``Importable Goods, Exportable Goods  and the Terms of Trade'' of the book `Open Economy Macroeconomics,' by Mart�n Uribe and Stephanie Schmitt-Groh�, Princeton University Press 2017.  
%� Mart�n Uribe and Stephanie Schmitt-Groh�, 2016. 

clear all
clf

%set the size of the SVAR
sizevar=2; %two-variable SVAR (tot,tb).
%sizevar=5; %five-variable SVAR (tot,tb,y,c,i). 

if sizevar==2
load tot_cbcs2.mat
%produced by running tot_cbcs.m in 
%z:\uribe\book\tot\data
%(set sizevar=2).
end

if sizevar==5
load tot_cbcs5.mat nv ncou hx PI
%produced by running tot_cbcs.m in 
%z:\uribe\book\tot\data
%(set sizevar=5).
end

T = 11;
IR = zeros(T,2*nv,ncou);
for k=1:ncou
P = PI(:,:,k);
HX = hx(:,:,k);
x0 = P(:,1)/P(1,1)*10;;
IR(:,:,k) = ir(eye(nv),HX,x0,T);
end


pIR = mean(IR,3);

SIR = sort(IR,3);
MIR = SIR(:,:,ncou-1);
mIR = SIR(:,:,2);

t=(0:T-1)';

if sizevar==5
orient tall

subplot(3,2,1)
plot(t,pIR(:,1),'linewidth',3)
hold on
%plot(t,mIR(:,1),'--','linewidth',3)
%plot(t,MIR(:,1),'--','linewidth',3)
plot(t,pIR(:,1)*0);
hold off
title('Terms of Trade')
%xlabel('years after the shock')
ylabel('% dev. from trend')

subplot(3,2,2)
plot(t,pIR(:,2),'linewidth',3)
hold on
%plot(t,mIR(:,2),'--','linewidth',3)
%plot(t,MIR(:,2),'--','linewidth',3)
plot(t,pIR(:,2)*0);
hold off
title('Trade Balance')
%xlabel('years after the shock')
ylabel('% dev. from GDP trend')

subplot(3,2,3)
plot(t,pIR(:,3),'linewidth',3)
hold on
%plot(t,mIR(:,3),'--','linewidth',3)
%plot(t,MIR(:,3),'--','linewidth',3)
plot(t,pIR(:,3)*0);
hold off
title('Output')
%xlabel('years after the shock')
ylabel('% dev. from trend')

subplot(3,2,4)
plot(t,pIR(:,4),'linewidth',3)
hold on
%plot(t,mIR(:,4),'--','linewidth',3)
%plot(t,MIR(:,4),'--','linewidth',3)
plot(t,pIR(:,4)*0);
hold off
title('Consumption')
%xlabel('years after the shock')
ylabel('% dev. from trend')

subplot(3,2,5)
plot(t,pIR(:,5),'linewidth',3)
hold on
%plot(t,mIR(:,5),'--','linewidth',3)
%plot(t,MIR(:,5),'--','linewidth',3)
plot(t,pIR(:,5)*0);
hold off
title('Investment')
%xlabel('years after the shock')
ylabel('% dev. from trend')


end



if sizevar==2
subplot(2,2,1)
plot(t,pIR(:,1),'linewidth',3)
hold on
%plot(t,mIR(:,1),'--','linewidth',3)
%plot(t,MIR(:,1),'--','linewidth',3)
plot(t,pIR(:,1)*0);
hold off
title('Terms of Trade')
xlabel('years after the shock')
ylabel('% dev. from trend')

subplot(2,2,2)
plot(t,pIR(:,2),'linewidth',3)
hold on
%plot(t,mIR(:,2),'--','linewidth',3)
%plot(t,MIR(:,2),'--','linewidth',3)
plot(t,pIR(:,2)*0);
hold off
title('Trade Balance')
xlabel('years after the shock')
ylabel('% dev. from GDP trend')
end

shg