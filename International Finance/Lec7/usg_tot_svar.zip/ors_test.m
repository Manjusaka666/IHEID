%ors_test.m
%Test of the ORS effect studied in the chapter entitled ``Importable Goods, Exportable Goods  and the Terms of Trade'' of the book `Open Economy Macroeconomics,' by Mart�n Uribe and Stephanie Schmitt-Groh�, Princeton University Press 2017.  
%� Mart�n Uribe and Stephanie Schmitt-Groh�, 2016. 

clf
load tot_cbcs2 hx PI

plot(squeeze(hx(1,1,:)),10*squeeze(PI(2,1,:))./squeeze(PI(1,1,:)),'o')
xlabel('\rho')
ylabel('% dev. from GDP trend')