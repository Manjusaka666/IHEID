%edeir_ir.m
%Impulse response of the trade balance to a 1-percent improvement in the terms of trade  implied by  the SOE-RBC Model with capital and labor driven by terms-of-trade shocks  as presented in the chapter entitled ``Importable Goods, Exportable Goods  and the Terms of Trade'' of the book `Open Economy Macroeconomics,' by Mart�n Uribe and Stephanie Schmitt-Groh�, Princeton University Press 2017.  
%� Mart�n Uribe and Stephanie Schmitt-Groh�, 2016. 

clear all

edeir_ss
i = 1;
L = {'-','--','-x'}
for RHO=(0:0.25:0.5)
rho(i,1) = RHO;
edeir_num_eval %this .m script was created by running edeir_model.m 

%The linearized equilibrium system is of the form
%y_t=gx x_t
%x_t+1 = hx x_t + ETASHOCK epsilon_t+1
[gx, hx, exitflag] = gx_hx(nfy, nfx, nfyp, nfxp);

nx = size(hx,1); %number of states

%Variance/Covariance matrix of innovation to state vector x_t
varshock = nETASHOCK*nETASHOCK';

%Position of variables in the control vector
noutput = 3; %output
nc = 1; %consumption
nivv = 2; %investment
nh = 4; %hours
ntb = 7; %trade balance
ntby = 8; %trade-balance-to-output ratio
nca = 9; %current account
ncay = 10; %current-account-to-output ratio
ntb_o_tot = 11;

%Position of variables in the state vector
nd = 1; %debt
nrb = 2; %Past interest rate (back one period)
nk = 3; %capital
na = 4; %TFP

%add TFP as the last row of gx
gx(end+1,end) = 1;
nac = size(gx,1); %position of tfp in control vector

T = 11;
x0 = zeros(size(gx,2),1);
x0(na) = 1;
IR = ir(gx,hx,x0,T);
t = (0:T-1)';
plot(t,IR(:,ntb),L{i},'linewidth',2)
xlabel('periods after the shock')
ylabel('% dev. from GDP trend')
hold on
i = i+1;
end
legend('\rho=0','\rho=0.25','\rho=0.5')
shg
hold off