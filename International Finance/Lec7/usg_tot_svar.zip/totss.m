%totss.m 
%Panel estimation of  an SVAR for the vector [tot gdp c i tb]. This estimate is used as a robustness check in table 7.2 of the 
%chapter entitled ``Importable Goods, Exportable Goods  and the Terms of Trade'' of the book `Open Economy Macroeconomics,' by Mart�n Uribe and Stephanie Schmitt-Groh�, Princeton University Press 2017. 
%� Mart�n Uribe and Stephanie Schmitt-Groh�, 2016.  

clear all

clear all
load usg_tot_data.mat columns   country   readme    tot_data  
%produced by running usg_tot_data.m 
%in  z:\uribe\book\tot\data

ncou = length(tot_data);
nv = size(tot_data{1},2)-1;

Y = [];
X = [];
for k=1:ncou
%construct current and lagged data for country k
d = tot_data{k}; %see readme
d = d(:,2:end); %remove date
d = lagg(d);
y = d(:,1:end/2);
x = d(:,end/2+1:end);
Y = [Y;y];
X = [X;x];
end

X = [X X(:,1)*0+1];

T = size(X,1); %total number of observations

%the system is x_t = Ax_{t-1} + u_t
u = zeros(T,nv); %regression errors
A = zeros(nv);
A0 = eye(nv);

%perform regressions
%TOT regression
y = Y(:,1);
x = X(:,[1 end]); 
aa = x\y;
A(1,1) = aa(1);
u(:,1) =  y - x*aa;
R2 = 1-var(u(:,1))/var(y);

%Estimate remaining equations
for i=2:nv
y = Y(:,i);
X1 = [Y(:,1) X];
aa = X1\y;
A(i,:) = aa(2:nv+1)';
A0(i,1) = -aa(1);
u(:,i) = y-X1*aa;
R2(i,1) = 1-var(u(:,i))/var(y);
end

SIGMA  = cov(u);
PI0 =chol(SIGMA,'lower');
hx = A0\A;
PI = A0\PI0;

[~,sigx]=mom(eye(nv),hx,PI*PI');

%shut off all shocks but the first
SPI = PI;
SPI(:,2:end) = 0;
[~,ssigx]=mom(eye(nv),hx,SPI*SPI');

v_share = variance_decomposition(eye(nv),hx,PI);
v_share = v_share(1,:)'*100;

x0 = PI(:,1)*100;
T = 11;
 ir=ir(eye(nv),hx,x0,T) ;
t=(0:T-1)';

orient tall
subplot(3,2,1)
plot(t,ir(:,1),'linewidth',3)
hold on
plot(t,ir(:,2)*0);
title('Terms of Trade')
%xlabel('years after the shock')
ylabel('% dev. from trend')


subplot(3,2,3)
plot(t,ir(:,2),'linewidth',3)
hold on
plot(t,ir(:,2)*0);
title('Output')
%xlabel('years after the shock')
ylabel('% dev. from trend')


subplot(3,2,4)
plot(t,ir(:,3),'linewidth',3)
hold on, plot(t,ir(:,2)*0);
title('Consumption')
%xlabel('years after the shock')
ylabel('% dev. from trend')

subplot(3,2,5)
plot(t,ir(:,4),'linewidth',3)
hold on, plot(t,ir(:,2)*0);
title('Investment')
%xlabel('years after the shock')
ylabel('% dev. from trend')

subplot(3,2,2)
plot(t,ir(:,5),'linewidth',3)
hold on, plot(t,ir(:,2)*0);
title('Trade Balance')
%xlabel('years after the shock')
ylabel('% dev. from GDP trend')