%tot_cbcs.m
%country-by-country SVAR estimates and variance decompositions  in the chapter entitled ``Importable Goods, Exportable Goods  and the Terms of Trade'' of the book `Open Economy Macroeconomics,' by Mart�n Uribe and Stephanie Schmitt-Groh�, Princeton University Press 2017. 
%� Mart�n Uribe and Stephanie Schmitt-Groh�, 2016. 

clear all

%Set the size of the SVAR system 
sizevar = 5; %SVAR of the section entitled  `How Important Are Terms-of-Trade Shocks?'
%sizevar = 2; %SVAR of the section `Terms-Of-Trade And  The Trade Balance: Empirics' 


filename = ['tot_cbcs' num2str(sizevar)]; %this string variable is used to save the output of this program (see the last line of code).

%load the detrended data (ready for regression analysis)
load usg_tot_data columns   country   readme    tot_data
%produced by running usg_tot_data.m in 
%z:\uribe\book\tot\data

if sizevar==5;
nvar = 2:6; %tot, tb, gdp, c, i, in this order
end
if sizevar==2
nvar = 2:3 %tot tb, in this order
end

nv = length(nvar);
ncou = length(tot_data);
A = zeros(nv,nv,ncou);
A0 = eye(nv,nv);
A0 = repmat(A0,[1 1 ncou]);
PI = zeros(nv,nv,ncou);
PI1 = zeros(nv,nv,ncou);
hx = zeros(nv,nv,ncou);
sigx = zeros(nv,nv,ncou);
ssigx = zeros(nv,nv,ncou);
v_share = zeros(nv,ncou);
R2 = zeros(nv,ncou);

for k=1:ncou
d = tot_data{k}(:,nvar);
d = lagg(d);
Y = d(:,1:end/2);
w = d(:,end/2+1:end);
X = [w w(:,1)*0+1];
T = size(X,1); %total number of observations

%the system is x_t = Ax_{t-1} + u_t
u = zeros(T,nv); %regression errors
%perform regressions
%TOT regression
y = Y(:,1);
w = [X(:,1) X(:,end)];
aa = w\y;
A(1,1,k) = aa(1);
u(:,1) =  y - w*aa;

%Estimate remaining euations
aa = [y X]\Y(:,2:end);
A(2:end,:,k) = aa(2:nv+1,:)';
A0(2:end,1,k) = -aa(1,:)';
u(:,2:end) = Y(:,2:end)-[y X]*aa;
R2(1:nv,k) = (1-var(u)./var(Y))';
SIGMA  = cov(u);
PI1(:,:,k) =chol(SIGMA,'lower');
PI(:,:,k) = A0(:,:,k)\PI1(:,:,k);
hx(:,:,k) = A0(:,:,k)\A(:,:,k);

[~,sigx(:,:,k)]=mom(eye(nv),hx(:,:,k),PI(:,:,k)*PI(:,:,k)');

PI1 = PI(:,:,k);
PI1(:,2:end) = 0;
[~,ssigx(:,:,k)]=mom(eye(nv),hx(:,:,k),PI1*PI1');

[~,vdx]=variance_decomposition(eye(nv),hx(:,:,k),PI(:,:,k));

v_share(:,k) = vdx(1,:)*100;

var_svar_tot(:,k) = diag(ssigx(:,:,k)); %variances conditional on ttot shocks implied by empirical SVAR model
var_svar(:,k) = diag(sigx(:,:,k)); %total variances  implied by empirical SVAR model

%var_share(k, 1:nv) =  (diag(ssigx(:,:,k))./ diag(sigx(:,:,k)));
end

eval(['save ' filename '.mat filename hx PI R2 ncou country nv ssigx v_share'])