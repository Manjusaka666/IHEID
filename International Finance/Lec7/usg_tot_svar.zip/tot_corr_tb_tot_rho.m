%tot_corr_tb_tot_rho.m
%correlation-based test of the ORS effect in the context of a SOE-RBC model driven by terms-of-trade shocks. Compates the conditional correlation between tb and tot as a function of rho in the data and in the SOE-RBC model as presented in the chapter entitled ``Importable Goods, Exportable Goods  and the Terms of Trade'' of the book `Open Economy Macroeconomics,' by Mart�n Uribe and Stephanie Schmitt-Groh�, Princeton University Press 2017. 
%� Mart�n Uribe and Stephanie Schmitt-Groh�, 2016. 

clear all
clf

%Data
load tot_cbcs2  hx ssigx
%produced by running 
%tot_cbcs.m 
%(set sizevar=2)
sizevar=2
RHO = squeeze(hx(1,1,:));
corrdata = ssigx(1,2,:) ./ ssigx(1,1,:).^0.5 ./ ssigx(2,2,:).^0.5;
corrdata = squeeze(corrdata);
plot(RHO,corrdata,'o'),shg

hold on

%SOE-RBC Model
edeir_run


plot(rho,corr_tba,'-','linewidth',2)

xlabel('$\rho$','interpreter','LaTeX')
ylabel('corr$(tot,tb)$','interpreter','LaTeX')
legend('SVAR','SOE-RBC model','location','southwest')
hold off
shg