%table_v_share_cbc.m 
%country-by-country SVAR estimates and variance  shares attributable to terms-of-trade shocks   in the chapter entitled ``Importable Goods, Exportable Goods  and the Terms of Trade'' of the book `Open Economy Macroeconomics,' by Mart�n Uribe and Stephanie Schmitt-Groh�, Princeton University Press 2017. 
%� Mart�n Uribe and Stephanie Schmitt-Groh�, 2016. 

clear all, clc

load tot_cbcs5.mat ncou v_share country hx  PI nv
%produced by running tot_cbcs.m 
%(set sizevar=5)

for k=1:ncou
a = [country{k} ' ' num2str(v_share(:,k)')];
disp(a)
end

bb = ['Mean ' num2str(mean(v_share'))];
disp(bb)

b = ['Median ' num2str(median(v_share'))];
disp(b)
c = ['Std. Dev. ' num2str(std(v_share'))];
disp(c)
disp('\hline')

%Estimates usings  Cross-Country  Means of h_x and PI
H = mean(hx,3);
P = mean(PI,3);
 [~,vdx]=variance_decomposition(eye(nv),H,P);
d = ['Using Cross-Country \\ Mean of $h_x$ and $\Pi$ ' num2str(vdx(1,:)*100)];
disp(d)
disp('\hline')

totss
e = v_share';
e = ['Panel Estimation ' num2str(e)];
disp(e)