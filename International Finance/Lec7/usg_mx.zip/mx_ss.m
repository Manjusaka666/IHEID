%mx_ss.m
%Steady state of the MX model  as presented in  chapter 7 of ``Open Economy Macroeconomics,''
%by Martin Uribe and Stephanie Schmitt-Grohe.
%� Mart�n Uribe and Stephanie Schmitt-Groh�, 2014. 

%Calibration

if externallyset_parameters  == 0; %use country medians
PHIM = 1.82;%capital adjustment cost importable sector  cross-country median

PHIX = 1.56;%capital adjustment cost exportable sector cross-country median
PSSI = 0.18; %debt elasticity of interest rate cross-country median
RHO_TOT = 0.5; %AR(1) coeff of tot
STD_TOT = 0.1; % std of innovation to tot
end


%The calibration is described in tot_ss.tex in directory z:\uribe\book\tot\mx
%Time unit is a year
SIGG = 2; %
OMEGA = 1.455; %Frisch ela st. 
ALFA =0.32;% capital share 
MU = 1;%1.5;%Elasticity of Substitution between importables and exportables; 
RSTAR = 0.11;%0.04; %long-run interest rate
TFP_M = 1; %Level of technology in M sector; 
TOTBAR = 1;% terms of trade in AR(1) 
DELTA = 0.1; %depreciation rate
SX = 0.26*0.81; %Export share in GDP. see program ... [this is the mean of valued added exports to GDP, see read_oecd_tiva.m in directory U:\uribe\book\tot\tradeshares]
STB= 0.01; %Steady state trade balance to output ratio. 
GAMA = 0.88; %GDP in X sector over GDP in M sector. see: [Gama,country] = read_unctad; in directory U:\uribe\book\tot\tradeshares
BETTA = 1/(1+RSTAR); %subjective discount factor

%Start using the equilibrium conditions;
tot = TOTBAR; 
um = 1/BETTA - 1 + DELTA;
ux = 1/BETTA -1 + DELTA; 

%intermediate variables, all are ratios of x over m
A = GAMA^((1-ALFA)*(OMEGA-1)/OMEGA)/TOTBAR; 

tfp_m = TFP_M;
tfp_x = A*tfp_m; 
TFP_X = tfp_x; 

UPSILON = (GAMA/(1+GAMA) -SX) / (1/(1+GAMA) +SX-STB);
UPSILON_tot = (UPSILON*tot^(MU-1))^(-1/MU);
CHI = UPSILON_tot/(1+UPSILON_tot);

OMEGAM = OMEGA; 
OMEGAX = OMEGA; 
ALFAX = ALFA; 
ALFAM = ALFA; 

ax_o_am = (CHI/(1-CHI) * tot)^(-MU); 
if MU==1
pm = CHI*ax_o_am^(1-CHI);
else
pm = ( CHI  + (1-CHI)*ax_o_am^(1-1/MU))^(1/(1-1/MU) -1) * CHI ;
end
px = tot* pm; 


km_o_hm  = (um/pm/ ALFA/tfp_m)^(1/(ALFA-1)); 

wm =  pm*(1-ALFA)*tfp_m *km_o_hm^(ALFA); 
 
kx_o_hx  = (ux/px/ ALFA/tfp_x)^(1/(ALFA-1)); 

wx = tfp_x*px* (1-ALFA)*kx_o_hx^(ALFA); 

hm = wm^(1/(OMEGA-1)); 

hx = wx^(1/(OMEGA-1)); 

kx = hx *kx_o_hx; 

km = hm * km_o_hm; 

ym = tfp_m * km^ALFA * hm^(1-ALFA); 

yx = tfp_x * kx^ALFA * hx^(1-ALFA); 

im = DELTA * km; 

ix = DELTA * kx; 

ivv = im + ix; 

y = px*yx+pm*ym; 

r = RSTAR; %interest rate

d = STB * y * (1+r) /r; 

DBAR=d; %debt

m = y*(SX-STB); 

am = ym + m / pm; 

x =  SX*y;

ax = yx - x/px; 

if MU==1
c = am^CHI*ax^(1-CHI) - im - ix;
else
c =  ( CHI * am^(1-1/MU)  + (1-CHI)*ax^(1-1/MU) )^(1/(1-1/MU)) -   im - ix; 
end

la = [c - hm^OMEGA/OMEGA - hx^OMEGA/OMEGA]^(-SIGG);

output = y;

tby = (x-m)/output; 

OUTPUT = output; 

TOT = tot;

h_x = hx;  clear hx 

output_constant_prices = output; 

c_constant_prices = c; 

ivv_constant_prices = ivv;

tby_constant_prices = tby;

PX = px; 

PM = pm; 

save mx_ss.mat SIGG OMEGA ALFA RSTAR TFP_M TOTBAR DELTA CHI TFP_X DBAR MU externallyset_parameters 