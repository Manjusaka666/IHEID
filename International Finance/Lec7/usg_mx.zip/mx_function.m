function [sigy0,sigx0,nivv,noutput,ntot,ntby,nc] = mx_function(PHIM,PHIX,PSSI,RHO_TOT,STD_TOT);
%[sigy0,sigx0,nivv,noutput,ntot,ntby,nc] = mx_function(PHIM,PHIX,PSSI,RHO_TOT,STD_TOT);
%Compute numerically a first-order approximation and  second moments implied by  the 
%MX  Model as presented in chapter 7 of ``Open Economy Macroeconomics,'' by Martin Uribe and Stephanie Schmitt Grohe, 2014.
%
%� Mart�n Uribe and Stephanie Schmitt-Groh�, 2014. 

 externallyset_parameters =1;

mx_ss
mx_num_eval %this .m script was created by running mx_model.m  in
%z:\uribe\book\tot\mx\paasche

%The linearized equilibrium system is of the form
%y_t=gx x_t
%x_t+1 = hx x_t + ETASHOCK epsilon_t+1
[gx, hx, exitflag] = gx_hx(nfy, nfx, nfyp, nfxp); %this program is available at http://www.columbia.edu/~mu2166/1st_order/1st_order.htm

nx = size(hx,1); %number of states

%Variance/Covariance matrix of innovation to state vector x_t
varshock = nETASHOCK*nETASHOCK';

%variance-covariance matrices conditional on tot shocks
[sigy0,sigx0]=mom(gx,hx,varshock); %this program is available at http://www.columbia.edu/~mu2166/1st_order/1st_order.htm

%Position of variables in the control vector 
noutput = 23; % %output at constant GDP prices
nc = 24;% consumption at constant GDP prices
nivv = 25 ; % investment at constant GDP prices
ntby = 28; %tby at constant GDP prices 

noutput_final  = 18; %output (in units of final goods.) 
nc_final = 1; %consumption (in units of final goods)
nivv_final  = 22; %Aggregate investment (units of final goods)
ntby_final  = 26;%ratio of trade balance to trend output

%Position of variables in state vector 
ntot = 6; % TOT