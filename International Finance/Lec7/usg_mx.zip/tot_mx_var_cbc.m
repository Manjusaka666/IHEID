%tot_mx_var_cbc.m
%produces country-specific and country medians of the theoretical (MX model)  and empirical (SVAR model)  shares of variances explained by terms of trade shocks of TB, Y, C, and I. Tables 7.6 and 7.7  in  the chapter entitled ``Importable Goods, Exportable Goods, and the Terms of Trade,'' (chapter 7) 
%of the book  ``Open Economy Macroeconomics,'' by Mart�n Uribe and Stephanie Schmitt Grohe, 2014.
%� Mart�n Uribe and Stephanie Schmitt-Groh�, 2014. 

clear all,clc

%read empirical  share of variacnes explained by tot shocks
load tot_svar_var_cbc ncou nv var_svar var_svar_tot_ratio_cbc country i_c
%produced by running
%tot_svar_var_cbc.m in
%c:\data\uribe\book\tot\data

%theoretical predictions from MX  model
var_model_tot = zeros(nv,ncou);

load phi_pssi_cbc PHIM_cbc PHIX_cbc PSSI_cbc RHO_TOT_cbc STD_TOT_cbc
%produced by running 
%phi_pssi_cbc.m in
%c:\data\uribe\book\tot\mx\paasche

for k=1:ncou

PHIM = PHIM_cbc(k);
PHIX = PHIX_cbc(k);
PSSI = PSSI_cbc(k);
RHO_TOT = RHO_TOT_cbc(k);
STD_TOT = STD_TOT_cbc(k);

[sigy0,sigx0,nivv,noutput,ntot,ntby,nc] = mx_function(PHIM,PHIX,PSSI,RHO_TOT,STD_TOT);

diag(sigy0);  %unconditional variances conditional on tot shocks
var_model_tot(2:end,k) = ans([ntby;noutput;nc;nivv]); %pick variables of interest (output, consumption, investment, trade balance divided by trend output)

var_model_tot(1,k) = sigx0(ntot,ntot);

end

var_model_tot_ratio_cbc = var_model_tot./ var_svar;

var_svar_tot_ratio = median(var_svar_tot_ratio_cbc,2);

var_model_tot_ratio = median(var_model_tot_ratio_cbc,2);

var_table = [var_model_tot_ratio var_svar_tot_ratio]*100;

disp('Table 7.6 ')
disp(var_table)

disp('Table 7.7')
xxx = zeros(2*nv,ncou);
xxx(1:2:2*nv,:) =var_model_tot_ratio_cbc*100;
xxx(2:2:2*nv,:)  = var_svar_tot_ratio_cbc*100;

for k=1:ncou


a = [country{i_c(k)}  num2str(xxx(:,k)')];
disp(a)
end