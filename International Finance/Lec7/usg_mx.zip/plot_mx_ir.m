%plot_mx_ir.m plots cross-country median  impulse respondes implied by the 
%MX Model  developed  in  the chapter entitled ``Importable Goods, Exportable Goods, and the Terms of Trade,'' 
%of the book  ``Open Economy Macroeconomics,'' by Mart�n Uribe and Stephanie Schmitt Grohe, 2014.
%� Mart�n Uribe and Stephanie Schmitt-Groh�, 2014. 

clear all
clf
mx_ir
IR = median(IR_cbc,3); 

orient tall
t=0:Tir-1;
rows=6;
cols =3; 
thick = 3;
i=1;

subplot(rows,cols,i)
plot(t, IR(:,ny+ntot),'linewidth',thick) 
title('Terms of Trade')
i=i+1; 

subplot(rows,cols,i)
plot(t, IR(:,nm),'linewidth',thick) 
title('Imports')
i=i+1;  

subplot(rows,cols,i)
plot(t, IR(:,nx),'linewidth',thick) 
title('Exports')
i=i+1;  

subplot(rows,cols,i)
plot(t,  (IR(:,ntby)) ,'linewidth',thick)
hold on 
title('Trade Balance')
i=i+1;

subplot(rows,cols,i)
plot(t, IR(:,nym),'linewidth',thick) 
title('Output in Import Sector')
i=i+1;  

subplot(rows,cols,i)
plot(t, IR(:,nyx),'linewidth',thick) 
title('Output in Export Sector')
i=i+1;  

subplot(rows,cols,i)
plot(t, IR(:,nivv),'linewidth',thick) 
title('Investment')
i=i+1;  

subplot(rows,cols,i)
plot(t, IR(:,nim),'linewidth',thick) 
hold on
title('Investment in Import Sector')
i=i+1;  

subplot(rows,cols,i)
plot(t, IR(:,nix),'linewidth',thick) 
title('Investment in Export Sector')
i=i+1;  

subplot(rows,cols,i)
plot(t, IR(:,noutput),'linewidth',thick) 
title('GDP')
i=i+1;  

subplot(rows,cols,i)
plot(t, IR(:,nhm),'linewidth',thick) 
title('Employment in Import Sector')
i=i+1;  

subplot(rows,cols,i)
plot(t, IR(:,nh_x),'linewidth',thick) 
title('Employment in Export Sector')
i=i+1;  

subplot(rows,cols,i)
plot(t, IR(:,nc),'linewidth',thick) 
title('Consumption')
i=i+1;  

subplot(rows,cols,i)
plot(t, IR(:,nam),'linewidth',thick) 
title('Absorption of Importables ')
i=i+1;  

subplot(rows,cols,i)
plot(t, IR(:,nax),'linewidth',thick) 
title('Absorption of Exportables')
i=i+1;  

subplot(rows,cols,i)
plot(t, IR(:,ny+nd)/OUTPUT,'linewidth',thick) %we plot d_t/OUTPUT*100; IR = d_t - DBAR to a shock=10. 
title('External Debt')
i=i+1; 

subplot(rows,cols,i)
plot(t, IR(:,nwm),'linewidth',thick) 
title('Wage in Import Sector')
i=i+1;  

subplot(rows,cols,i)
plot(t, IR(:,nwx),'linewidth',thick) 
title('Wage in Export Sector')

shg