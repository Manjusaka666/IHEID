function mx_model(ces);
%MX model with TOT shocks developed in chapter on ``Importable Goods, Exportable Goods, and the Terms of Trade''
%of ``Open Economy Macroeconomics,'' by Mart�n Uribe and Stephanie Schmitt-Groh�, 2014.
%Run this program only once or every time the structure of the model changes. No need to re-run it 
%when parameter values change. 
%mx_model.m computes a symbolic  log-linear approximation to the  function f, which defines  the DSGE model: 
%  E_t f(yp,y,xp,x) =0. 
%here, a p denotes next-period variables.  
%Input: ces=1 if Armington aggregator is CES or 0 if it is Cobb-Douglas (default)
%
%Output: Analytical expressions for f and its first derivatives as well as x and y. 
%The output is written to mx_num_eval.m which can then be run for numerical evaluations
%
%Calls: anal_deriv.m and anal_deriv_print2f.m  available at http://www.columbia.edu/~mu2166/1st_order/1st_order.htm
%
%� Mart�n Uribe and Stephanie Schmitt-Groh�, 2014. 

if nargin<1
ces=0
end

filename = 'mx'; %a file with this name and suffix _num_eval.m is created at the end of this program and contains symbolic expression for the function f and its derivatives fx fy fxp fyp 

syms OMEGAM OMEGAX SIGG PHIM PHIX BETTA DELTA CHI MU ALFAM ALFAX  RSTAR DBAR   RHO  STD_EPS_A ETASHOCK  PSSI RHO_TOT TOT STD_TOT OUTPUT TFP_X TFP_M

syms c cp hm hmp h_x h_xp d dp im imp ix ixp  km kmp kmfu kmfup kx kxp kxfu kxfup am amp ax axp px pxp pm pmp ym ymp yx yxp r rp wm wmp wx wxp ux uxp um ump  m mp x xp  la lap 
syms tot totp tfp_x tfp_xp tfp_m tfp_mp  output outputp  tby tbyp ivv ivvp

syms output_constant_prices output_constant_pricesp c_constant_prices c_constant_pricesp ivv_constant_prices ivv_constant_pricesp tby_constant_prices tby_constant_pricesp
syms PX PM

%Utitlity function: 
U = ((c - hm^OMEGAM/OMEGAM -  h_x^OMEGAX/OMEGAX)^(1-SIGG) - 1)/(1-SIGG); 

if ces==1
A = (CHI * am^(1-1/MU ) + (1-CHI) * ax^(1-1/MU))^(1/(1-1/MU));
elseif ces==0
A = am^CHI*ax^(1-CHI);
else
error('The variable ces must take the value 0 or 1')
end
%Equilibrium conditions. The symbols e1, e2, ... denote equation 1, equation2, ...

%U_1 = la
e1 = -la + diff(U, 'c'); 

%U_2/U_1 = wm
e2 = wm + diff(U, 'hm')/diff(U,'c'); 

%U_3/U1 = wx
e3 =  wx +  diff(U, 'h_x')/diff(U,'c');

%Euler d
e4 = -la + BETTA * (1+r) * lap ; 

%Euler km
e5 = -la *(1+ PHIM*(kmp-km)) + BETTA*lap*  (ump + 1-DELTA +  PHIM * (kmfup-kmp));

%Euler km
e6 = -la *(1+ PHIX*(kxp-kx)) + BETTA*lap * (uxp + 1-DELTA +  PHIX * (kxfup-kxp));

%Evolution kmp
e7 =  -kmp + (1-DELTA)*km + im; 

%Evolution kxp
e8 =  -kxp + (1-DELTA) *kx +  ix; 

%Final good aggregation
e9 = -pm + diff(A, 'am'); 

%Final good aggregation
e10 = -px + diff(A, 'ax'); 

%Production of Importables
e11 = - tfp_m* km^ALFAM*hm^(1-ALFAM)+ ym ; 

%Production of Importables
e12 = - tfp_x* kx^ALFAX*h_x^(1-ALFAX)+ yx ; 

%Foc Firms capital
e13 = -um + pm *tfp_m *ALFAM*km^(ALFAM-1)*hm^(1-ALFAM); 

%Foc Firms labor
e14 = -ux + px *tfp_x *ALFAX*kx^(ALFAX-1)*h_x^(1-ALFAX); 

%Foc Firms capital
e15 = -wm + pm *tfp_m *(1-ALFAM)*km^ALFAM*hm^(-ALFAM); 

%Foc Firms labor
e16 = -wx  +  px *tfp_x *(1-ALFAX)*kx^ALFAX*h_x^(-ALFAX); 

% Market clearing for final goods: 
e17 = - A + c + im +ix + PHIX/2*(kxp-kx)^2 + PHIM/2*(kmp-km)^2; 

%Imports at final goods prices 
e18 = pm*(-am+ym) + m;

%Exports at final good prices
e19 = px*(-ax+yx) -x;

%Evolution of foreign debt
e20 = -d - m + dp /(1+r) + x; 

%Country premium
e21 = -r + RSTAR + PSSI * (exp(dp-DBAR) -1);

%Definition of Tot
e22 = -tot + px / pm; 

%Evolution of TFP
e23 = [-log(totp/TOT) + RHO_TOT * log(tot/TOT);
    -log(tfp_xp/TFP_X) + RHO_TOT * log(tfp_x/TFP_X);
    -log(tfp_mp/TFP_M) + RHO_TOT*log(tfp_m/TFP_M)
    ];

%make kfu=kp
e24 = [-kxfu+kxp; -kmfu + kmp];

%definition of output in terms of final goods
e25 = [-output+px*yx+pm*ym; -ivv+im+ix];

%trade balance in final goods relative to steady state output
e26 = -tby + (x-m)/OUTPUT; 


%definition of output, consumption, and investment at constant prices
e27 = [-output_constant_prices+PX*yx+PM*ym;
            -c_constant_prices+c/output*output_constant_prices; 
            -ivv_constant_prices+ivv/output*output_constant_prices;
            -tby_constant_prices + (x-m)/output*output_constant_prices/OUTPUT];


%Create function f
f = eval(eval([e1;e2;e3;e4;e5;e6;e7;e8;e9;e10;e11;e12;e13;e14;e15;e16;e17;e18;e19;e20;e21;e22;e23;e24; e25; e26;e27]));

% Define the vector of controls in periods t and t+1, controlvar and controlvarp, and the vector of states in periods t and t+1, statevar and statevarp
%States to substitute from levels to logs
states_in_logs = [ km kx tfp_m tfp_x tot];
states_in_logsp = [ kmp kxp tfp_mp tfp_xp totp];
statevar = [d states_in_logs];
statevarp = [dp  states_in_logsp];
 
controls_in_logs = [c  hm h_x im ix am ax px pm ym yx wm wx ux um m x output la kmfu kxfu  ivv output_constant_prices c_constant_prices ivv_constant_prices];
controls_in_logsp = [cp  hmp h_xp imp ixp amp axp pxp pmp ymp yxp wmp wxp uxp ump mp xp outputp lap kmfup kxfup  ivvp output_constant_pricesp c_constant_pricesp ivv_constant_pricesp];
controlvar = [controls_in_logs tby r tby_constant_prices]; 
controlvarp = [controls_in_logsp tbyp rp tby_constant_pricesp]; 

%Number of states
ns = length(statevar);

%Make f a function of the logarithm of the state and control vector

%variables to substitute from levels to logs
variables_in_logs = transpose([states_in_logs, controls_in_logs, states_in_logsp, controls_in_logsp]);

f = subs(f, variables_in_logs, exp(variables_in_logs));

approx = 1;

%Compute analytical derivatives of f
[fx,fxp,fy,fyp]=anal_deriv(f,statevar,controlvar,statevarp,controlvarp,approx);

%Make f and its derivatives a function of the level of its arguments rather than the log
f = subs(f, variables_in_logs, log(variables_in_logs));
fx = subs(fx, variables_in_logs, log(variables_in_logs));
fy = subs(fy, variables_in_logs, log(variables_in_logs));
fxp = subs(fxp, variables_in_logs, log(variables_in_logs));
fyp = subs(fyp, variables_in_logs, log(variables_in_logs));

%Symbolically evaluate f and its derivatives at the nonstochastic steady state (c=cp, etc.)
cu = transpose([statevar controlvar km kx ]);
cup = transpose([statevarp controlvarp kmfu kxfu ]);

for subcb=1:2 %substitution must be run twice  in case the original system is a stochastic difference equation of order higher than one. For example, the current model features k_t, k_t+1, and k_t+2 and thus is a 2nd order difference equation

f = subs(f, cup,cu,0);
fx = subs(fx, cup,cu,0);
fy = subs(fy, cup,cu,0);
fxp = subs(fxp, cup,cu,0);
fyp = subs(fyp, cup,cu,0);
end

%Construct ETASHOCK matrix, which determines the var/cov of the forcing term of the system. Specifically, the state vector evolves over time according to 
%x_t+1 = hx x_t + ETASHOCK epsilon_t+1
ETASHOCK(ns,1) = STD_TOT;
ETASHOCK(1:ns-1) = 0;

varshock = ETASHOCK*ETASHOCK';

%Print derivatives to file <filename>_num_eval.m'  for model evaluation
anal_deriv_print2f(filename,fx,fxp,fy,fyp,f,ETASHOCK);

eval(['save ' filename '_model.mat'])