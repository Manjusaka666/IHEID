%mx_ir.m produces country-specific  impulse respondes implied by the 
%MX Model  developed  in   chapter  7 (entitled ``Importable Goods, Exportable Goods, and the Terms of Trade'')
%of the book  ``Open Economy Macroeconomics,'' by Mart�n Uribe and Stephanie Schmitt Grohe, 2014.
%� Mart�n Uribe and Stephanie Schmitt-Groh�, 2014. 

 externallyset_parameters = 1;

load phi_pssi_cbc.mat  PHIM_cbc PHIX_cbc  PSSI_cbc RHO_TOT_cbc STD_TOT_cbc
%produced by running phi_pssi_cbc.m  in directory
%z:\uribe\book\tot\mx\paasche

ncou = length(PHIX_cbc);

%Position of variables in the control vector
nc_cpi = 1; %consumption at final good prices 
nhm =2;%hours in import sector
nh_x=3;%hours in export sector
nim = 4;%investment in import sector
nix = 5 ; %investment in export sector
nam = 6; %domestic absorption of import goods
nax = 7; %domestic absorption of export goods
npx = 8; %price of exports in terms of C.
npm = 9; %price of imports in terms of C. 
nym = 10; %production of importables
nyx = 11; %production of exportables
nwm = 12; % consumption wage in the import sector
nwx = 13; %consumption wage in the export sector
nux = 14; %consumption rental rate in the export sector
num=15; %consumption rental rate in the import sector
nm = 16; %quantity of imports in units of final goods
nx = 17; %quantity of exports in units of final goods
noutput_cpi = 18; %output (in units of final goods.) 
nla = 19; %lambda
nivv_cpi = 22; %Aggregate investment (units of final goods)
noutput = 23; 
nc = 24; 
nivv = 25; 
ntby = 28;%ratio of trade balance to trend output (at constant prices) 
nr = 27; %net interest rate (on import goods)

%Position of variables in the state vector
nd = 1; %debt
nkm = 2; %capital in import sector
nkx = 3; %capital in export sector
ntfp_m = 4; %TFP in import sector
ntfp_x = 5; %TFP in export sector
ntot = 6; % TOT

for k = 1:ncou

PHIM = PHIM_cbc(k);
PHIX = PHIX_cbc(k);
PSSI = PSSI_cbc(k);
RHO_TOT = RHO_TOT_cbc(k);
STD_TOT = STD_TOT_cbc(k);

mx_ss %read steady state   and parmeter values

mx_num_eval %this .m script was created by running mx_model.m in
%z:\uribe\book\tot\mx\paasche

%The linearized equilibrium system is of the form
%y_t=gx x_t
%x_t+1 = hx x_t + ETASHOCK epsilon_t+1
[gx, hx, exitflag] = gx_hx(nfy, nfx, nfyp, nfxp); %this program is available at http://www.columbia.edu/~mu2166/1st_order/1st_order.htm

nx = size(hx,1); %number of states

%Variance/Covariance matrix of innovation to state vector x_t
varshock = nETASHOCK*nETASHOCK';

ny = size(gx,1);

Tir =11;
x0(ntot) = 10;%so this is a 10 percent increase in TOT

IR_cbc(:,:,k) = ir(gx,hx,x0,Tir); %this program is available at http://www.columbia.edu/~mu2166/1st_order/1st_order.htm

end