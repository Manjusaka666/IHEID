%statistics_model_no_exclusion.m
%(c) Mart�n Uribe and Stephanie Schmitt-Groh�, June 2014. 
clear all

load simu_eg_no_exclusion
%simu_eg_no_exclusion.mat is produced by running simu_no_exclusion.m in
%c:\data\uribe\book\sovereign_debt\eg\no_exclusion

TBY = 1-C./ Ytilde; %trade balance to GDP ratio

x = find(B==0&F==0);

gdp = Ytilde(x);
tby = TBY(x);
pm = PM(x);
dy = D(x)./Ytilde(x)*100;

corr([pm log(gdp)]);
corr_pm_gdp = ans(2,1);
 corr([pm tby]);
corr_pm_tby = ans(2,1);

default_frequency = mean(F==1&B==0)*4*100;

stat_model = [ default_frequency mean(dy) mean(pm) std(pm) corr_pm_gdp corr_pm_tby]