%egr.m
% Use a value-function-iteration procedure to obtain the policy function of  the
%Eaton-Gersovitz model with Debt Renegotiation developed in ``Open Economy Macroeconomics,'' by Mart�n Uribe and Stephanie Schmitt-Grohe
%output:
%dpc is the policy function for debt under continuation. It is an ny-by-nd matrix, where ny is the number of output grid points and nd is the number of debt grid points
%dpix is the policy function for debt under continuation (dpc) but expressed in terms of the index in the debt grid. That is, dpc=d(dpix). 
%vc is the value function under continuation, an ny-by-nd matrix.
%vb value function under bad standing, an ny-by-nd matrix.
%vg value function under good financial standing, an ny-by-nd matrix.
%q price of debt, an ny-by-nd matrix.  Note, the rows of q indicate y_t and the columns d_{t+1} (not d_t). 
%tauc capital control tax under continuation, an ny-by-nd matrix. This fiscal instrument is the one that decentralizes the Eaton-Gersovitz model.
%lac, lag, marginal utility of consumption under continuation and good standing, respectively, both  ny-by-nd matrices. 
%Elagp  the expected value of  next period's marginal utility of consumption,  la_{t+1}, conditional on  continuation in t. This object is useful to compute the capital control tax rate, tauc, in period $t$. 
%(c) Mart�n Uribe and Stephanie Schmitt-Grohe, October 2014. 

clear all

outputloss = 'quadratic';  %the options are 'flat' or 'quadratic'

%Exogenous Process for Endowment: 

load tpm.mat ygrid pai  %ygrid=endowment grid; associated pai=transition probability matrix
%created by c:\data\uribe\default\eg\data\tpm.m
ny = numel(ygrid); %number of grid points for log of ouput
y = exp(ygrid(:)); %level of output

%Calibrated parameters
rstar = 0.01;  %quarterly risk-free interest rate (Chatterjee and Eyigungor, AER 2012). 

theta=0.0385; %probability of reentyy (USG  and Chatterjee and Eyigungor, AER 2012). 

alfa =0.55;%bargaining power of borrower

sigg = 2; %coefficient of relative risk aversion

%Output loss function 
if strcmp(outputloss,'flat')
betta = 0.875;
a0 =    -0.88;%to get E(d/y | good standing and no default)=  0.5885, which is the value obtained in the baseline case (quadratic loss). Notice that the expectation here is over all states (good and bad standing);
a1 = 1;
a2 = 0;
end
if strcmp(outputloss,'quadratic')
betta = 0.85;%0.95;%discount factor, from Na, Schmitt-Grohe, Uribe, and Yue (2014)
a0 = 0;
a1 = -0.35;%-0.45 
a2 = (1-a1)/2/max(y); %this makes sure that: (1) the autarkic output is always increasing in the endowment. (2) the autarkic output has a slope of zero and reaches a maximum at y(end).  This implies an output loss of about 7 percent per period while in default status. 
end

ya =  y - max(0,a0+ a1*y + a2*y.^2); %output in autarky

%debt grid
dupper = 2;
dlower = 0.0001;
nd =200; % # of grid points for debt 
d = dlower:(dupper-dlower)/(nd-1):dupper;
d = d(:); 

n = ny*nd; %total number of states 

%matrix for  indices of output as a function of the current state (size ny-by-nd
yix = repmat((1:ny)',1,nd);

%value of autarky
va = zeros(ny,1);
dist = 1;
while dist>1e-21
vanew = ( ya.^(1-sigg)-1)  / (1-sigg) + betta * pai * va;
dist = max(abs(vanew(:)-va(:)))
va = vanew;
end
va = repmat(va,1,nd);

%matrix for  indices of debt as a function of the current state (size ny-by-nd)
dix = repmat(1:nd,ny,1);

%Consider a generic n-by-nd matrix Xtry. Each row of Xtry indicates one of the n possible states in the current period  and columns correspond to all (nd) possible values for  debt assumed in the current peirod and due in the next period under continuation. The variable X could be d_t, y_t, d_{t+1}, etc. 

dtry = repmat(d',[ny 1  nd]);
dtry = reshape(dtry,n,nd);

dptryix = repmat(1:nd,n,1);
dptry = d(dptryix);

ytryix = repmat(yix,nd,1);
ytry = y(ytryix);

%AUTARKY
%Consumption under autarky
ca = repmat(ya, [1 nd]);; %consumption of under bad standing
ua = ( ca.^(1-sigg)-1)  / (1-sigg);  %period utility under autarky

%Initialize the Value functions
vc = zeros(ny,nd);  %continue repaying
vcnew = vc;
vg = zeros(ny,nd); %good standing
vb = zeros(ny,nd); %bad standing
vd = zeros(ny,nd); %bad standing
vdnew= zeros(ny,nd); %bad standing (we make it ny-by-nd for convenience, but it is really ny-by-1, since all nd columns of vd are the same).
dpix = zeros(ny,nd); %debt policy function (expressed in indices)  
dpixnew = zeros(ny,nd);
f = zeros(ny,nd); %default indicator 1 if default, 0 otherwise; f maps (yT_t,d_t)--->{1,0}
q = ones(ny,nd)/(1+rstar); %initial price of debt
qb = ones(ny,nd)/(1+rstar); %initial price of debt in bad state
round(mean(1:nd));
dtix = ans*ones(ny,1);
dist = 1;
while dist>1e-8;

qtry = repmat(q,[nd 1]);

ctry =  dptry .* qtry - dtry + ytry;

utry = (ctry.^(1-sigg) -1)  / (1-sigg);

utry(ctry<=0) = -inf;

evgptry = pai *  vg;
Evgptry = repmat(evgptry,nd,1);

[vcnew(:), dpixnew(:)] = max(utry+betta*Evgptry,[],2);

vbnew = ua+betta*pai*(theta*vg + (1-theta) * vb);

f = vcnew<vdnew; %default indicator 1 if default, 0 otherwise; f maps (yT_t,d_t)--->{1,0}

dt = d(dtix);
sub2ind([ny nd],(1:ny)',dtix);
aux1 = repmat(qb(ans),1,nd);
aux2 = repmat(dt,1,nd)./ dptry(1:ny,:);
qbnew = (1-theta) * pai * qb / (1+rstar) + theta * (1-pai*f) / (1+rstar) + theta *  pai * (aux2.*f.*aux1) / (1+rstar);

qnew = (1- pai*f)/(1+rstar) + pai *  (aux2.*f.*aux1) / (1+rstar);

clear aux1 aux2

surplus_debtor =  max(0,vb-va) ./ repmat(ya,1,nd).^(-sigg);
surplus_creditor = qb.*d(dptryix(1:ny,:));
bargain = (surplus_debtor).^alfa .* (surplus_creditor).^(1-alfa);

[~,dtixnew] = max(bargain,[],2);

sub2ind([ny nd],(1:ny)',dtixnew);
vdnew = vb(ans);
vdnew = repmat(vdnew,1,nd);

dist = max(abs(qnew(:)-q(:))) +  max(abs(qbnew(:)-qb(:))) +max(abs(vcnew(:)-vc(:))) + max(abs(vbnew(:)-vb(:))) + max(abs(vdnew(:)-vd(:))) + max(abs(dpixnew(:)-dpix(:))) + max(abs(dtixnew(:)-dtix(:)))

q = qnew;
qb = qbnew;
vc = vcnew;
vb = vbnew;
vd = vdnew;
vg = max(vc,vd);
dpix = dpixnew;
dtix = dtixnew;

end %while dist>...


%Policy functions under continuation;

%debt choice under continuation
dpc = d(dpix);

%consumption of tradables  under continuation
I = sub2ind([ny nd],yix,dpix);
cc = q(I).*dpc+y(yix)-d(dix); 

clear ans *try *new *tryix I

eval(['save egr_' outputloss])