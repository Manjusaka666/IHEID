%typical_default_episode.m
% produces the average path of the economy around a default episode predicted by the Eaton-Gersovitz model.  
%(c) Mart�n Uribe and Stephanie Schmitt-Groh�, June 2014. 


clear all
rows =3;
cols = 2;

tb = 12; %periods before default
ta = 12; %periods after default

load simu_eg_quadratic.mat Y YA Ytilde B D C Q F TAU  PM  T Tburn  ygrid pai rstar betta theta sigg dupper dlower nd 
%produced by simu.m in
%c:\data\uribe\book\sovereign_debt\eg

x1 = find(F==1);
x1 = x1(x1>tb);
x=x1;

find(x>=tb+1);
x = x(ans);
find(x<=T-ta);
x = x(ans);

GDP = Ytilde; %GDP
GNP  = GDP;
GNP(2:end) = GNP(2:end) - (1-Q(1:end-1)).*D(2:end);%GNP ; 
NX = GDP-C; %trade balance
NXY = NX./GDP; %trade-balance-output ratio

for i=1:length(x)
y(i,1:tb+ta+1) =  Y(x(i)-tb:x(i)+ta)';
yaut(i,1:tb+ta+1) =  YA(x(i)-tb:x(i)+ta)';
ytilde(i,1:tb+ta+1) =  Ytilde(x(i)-tb:x(i)+ta)';
b(i,1:tb+ta+1) =  B(x(i)-tb:x(i)+ta)';
d(i,1:tb+ta+1) =  D(x(i)-tb:x(i)+ta)';
c(i,1:tb+ta+1) =  C(x(i)-tb:x(i)+ta)';
q(i,1:tb+ta+1) =  Q(x(i)-tb:x(i)+ta)';
f(i,1:tb+ta+1) =  F(x(i)-tb:x(i)+ta)';
tau(i,1:tb+ta+1) =  TAU(x(i)-tb:x(i)+ta)';
pm(i,1:tb+ta+1) =  PM(x(i)-tb:x(i)+ta)';
dy(i,1:tb+ta+1) = D(x(i)-tb:x(i)+ta)'./ (4*GNP(x(i)-tb:x(i)+ta))';
dy(i,1:tb+ta+1) = D(x(i)-tb:x(i)+ta)'./ (4*Ytilde(x(i)-tb:x(i)+ta))';
nx(i,1:tb+ta+1) =  NX(x(i)-tb:x(i)+ta)';
nxy(i,1:tb+ta+1) =  NXY(x(i)-tb:x(i)+ta)';
end

t = (-tb:ta);

f = @(x) median(x);

clf

subplot(rows,cols,1)
x=(y);plot(t,f(x),'-','linewidth',2)
hold on 
x=(ytilde);plot(t,f(x),'--','linewidth',2) 
set(gca,'xtick', [-12:4:12])
hold off
title('Output')
h= legend('$y_t$','$\tilde{y}_t$')
set(h, 'Interpreter', 'Latex')
xlim([-tb ta])
ylim([0.8 1.02])

subplot(rows,cols,2)
x=(c);plot(t,f(x),'-','linewidth',2)
title('Consumption')
xlim([-tb ta])
set(gca,'xtick', [-12:4:12])

subplot(rows,cols,3)
x=f(d);
x(14:end)=NaN; 
plot(t,x,'-','linewidth',2)
title('Debt')
xlim([-tb ta])
set(gca,'xtick', [-12:4:12])

subplot(rows,cols,4)
x= nx;plot(t,f(x),'-','linewidth',2)
title('Trade Balance ')
xlim([-tb ta])
set(gca,'xtick', [-12:4:12])

subplot(rows,cols,5)
x=nxy;plot(t,f(x),'-','linewidth',2)
title('Trade-Balance-Output Ratio')
ylabel('%/yr')
xlim([-tb ta])
set(gca,'xtick', [-12:4:12])

subplot(rows,cols,6)
x=f(pm);
x(13:end) =NaN;
plot(t,x,'-','linewidth',2)
title('Risk premium')
ylabel('%/yr')
xlim([-tb ta])
set(gca,'xtick', [-12:4:12])

if 1>2
%Plot the capital control tax
    clf
subplot(2,2,1)
x=f(tau);
x(13:end)=NaN; 
plot(t,x,'-','linewidth',2)
hold off
title('Capital Control Tax')
ylabel('%')
xlim([-tb ta])
set(gca,'xtick', [-12:4:12])
end

