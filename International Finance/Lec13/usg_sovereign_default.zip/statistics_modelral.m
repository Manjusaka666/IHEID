%statistics_modelral.m
% produces second moments  implied by an Eaton-Gersovitz  model with risk averse foreign lenders. The model presentation is given
%in Chapter 11.8, `Risk Averse Lenders,' in the chapter `Sovereign Debt' 
%of Uribe and Schmitt-Grohe, `Open Economy Macroeconomics,' Princeton University Press forthcoming.   
%(c) Mart�n Uribe and Stephanie Schmitt-Groh�,  September 2014. 

clear all

load simural2.mat
% produced by running simural.m 

TBY = 1-C./Ytilde; %trade balance to GDP ratio

x = find(B==0&F==0);

gdp = Ytilde(x);
tby = TBY(x);
pm = PM(x);
dy = D(x)./Ytilde(x)*100;

corr([pm log(gdp)]);
corr_pm_gdp = ans(2,1);
 corr([pm tby]);
corr_pm_tby = ans(2,1);

default_frequency = mean(F)*4*100;
default_frequency_good_standing = mean(F(B==0))*4*100;

stat_model = [ default_frequency   default_frequency_good_standing  mean(dy) mean(pm) std(pm) corr_pm_gdp corr_pm_tby]