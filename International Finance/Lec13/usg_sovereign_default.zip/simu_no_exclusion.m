%simu_no_exclusion.m
% produces time series implied by the Eaton-Gersovitz  model with output cost only, no exclusion.  
%(c) Mart�n Uribe and Stephanie Schmitt-Groh�, June 2014. 


clear all, format compact

load eg_no_exclusion.mat 
%produced by eg_no_exclusion.m in
%c:\data\uribe\book\sovereign_debt\eg\no_exclusion

cpai = cumsum(pai,2);

%Initial conditions
[~,i] = min(abs(y-1)); %average endowment 
j = floor(nd/2); %middle of the debt grid
b = 0; %for any t, if b=1==>bad standing at the end of  t-1 and  b=1==>good standing at the end of  t-1

%Length of simulation and burning period
T = 1e6;
Tburn = 1e5;

Y = zeros(Tburn+T,1);
Ytilde = zeros(Tburn+T,1);
B = zeros(Tburn+T,1);%B(t,1)=0 if the financial status  is good at the beginning of t or if it is bad at the beginning of t but the country randomly reenters credit markets in t. B(t,1)=1 if the financial standing at the beginning of t is bad and the country does not randomly reenter credit markets in t. 
D = zeros(Tburn+T,1);
C = zeros(Tburn+T,1);
Q = zeros(Tburn+T,1);
F = zeros(Tburn+T,1);
PM = zeros(Tburn+1,1);
r_world = (1+rstar)^4-1; %world interest rate (annualized)

for t=1:T+Tburn

Y(t,1) = y(i);
D(t,1) = d(j);

if (b==0) & (fg(i,j)==0) ; %choose to continue 
F(t,1) = 0;
B(t,1) = 0; 
Ytilde(t,1) = y(i);
C(t,1) = cgc(i,j);
Q(t,1) = qg(i,dpgcix(i,j));
jp  = dpgcix(i,j); %update debt state
end % if b==0 & fg(i,j) ==0

if (b==0) & (fg(i,j) ==1); %choose to default
F(t,1) = 1;
B(t,1) = 0; 
Ytilde(t,1) = ytilde(i);
C(t,1) = cd(i,j);
Q(t,1) = qb(i,dpdix(i,j));
jp = dpdix(i,j); %update debt state
end % if b==0 & fg(i,j)==1

rr = rand; %random number determining reentry if applicable

if (b==1) & (rr>theta) & (fb(i,j)==0);  %bad standing,  did not get to re-enter, and chooses not to default
B(t,1) = 1; 
F(t,1) = 0;
Ytilde(t,1) = ytilde(i);
C(t,1) = cbc(i,j);
Q(t,1) = qb(i,dpbcix(i,j));
jp = dpbcix(i,j); %update debt state
end % if (b==1) & (rr>theta) & (fb(i,j)==0);  

if (b==1) & (rr>theta) & (fb(i,j)==1);  %bad standing,  did not get to re-enter, and chooses  to default
B(t,1) = 1; 
F(t,1) = 1;
Ytilde(t,1) = ytilde(i);
C(t,1) = cd(i,j);
Q(t,1) = qb(i,dpdix(i,j));
jp = dpdix(i,j); %update debt state
end % if (b==1) & (rr>theta) & (fb(i,j)==1); 

if (b==1) & (rr<=theta) & (fg(i,j)==0); %reentry after having been in bad standing  and choosing not to default
B(t,1) = 0; 
F(t,1) = 0;
Ytilde(t,1) = y(i);
C(t,1) = cgc(i,j);
Q(t,1) = qg(i,dpgcix(i,j));
jp = dpgcix(i,j); %update debt state
end % if (b==1) & (rr<=theta) &(fg(i,j)==0); 

if (b==1) & (rr<=theta) & (fg(i,j)==1); %reentry after having been in bad standing  and choosing to default
B(t,1) = 0; 
F(t,1) = 1;
Ytilde(t,1) = ytilde(i);
C(t,1) = cd(i,j);
Q(t,1) = qb(i,dpdix(i,j));
jp = dpdix(i,j); %update debt state
end % if (b==1) & (rr<=theta) &(fg(i,j)==1); 

r_country = (1/Q(t,1))^4-1; %country interest rate 
PM(t,1) = (r_country-r_world)*100; %country risk premium

find(cpai(i,:)>rand);
i = ans(1);
b = min(1,B(t,1)+F(t,1)); 
j=jp; 
end %for t=1:T+Tburn

Y = Y(Tburn+1:end);
Ytilde = Ytilde(Tburn+1:end);
B = B(Tburn+1:end);
D = D(Tburn+1:end);
C = C(Tburn+1:end);
Q = Q(Tburn+1:end);
F = F(Tburn+1:end);
PM = PM(Tburn+1:end);


for i=1:nd
lad(i,1) = mean(D==d(i));
end

plot(d,lad,'x-' ,'linewidth', 2)
xlabel('d')
ylabel('lad')
shg

eval(['save simu_' filename])