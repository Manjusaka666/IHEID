%egral.m
% Use a value-function-iteration procedure to obtain the policy function of  the
%Eaton and Gersovitz default model augmented with a  risk averse foreign lenders and a time-varying foreign pricing kernel.
%For details of the model see Chapter 11.7, Sovereign Debt, Risk Averse
%Lenders,  in `Open Economy Macroeconomics,' by Mart�n Uribe and Stephanie
%Schmitt-Groh�, Princeton University Press forthcoming. 
%output:
%dpc is the policy function for debt under continuation. It is an ny-by-nk-by-nd matrix, where ny is the number of output grid points, 
%           nk is the number of kernel grid points  and nd is the number of debt grid points.
%dpix is the policy function for debt under continuation (dpc) but expressed in terms of the index in the debt grid. That is, dpc=d(dpix). 
%vc is the value function under continuation, an ny-by-nk-by-nd matrix.
%vb value function under bad standing, an ny-by-nk-by-nd matrix.
%vg value function under good financial standing, an ny-by-nk-by-nd matrix.
%q price of debt, an ny-by-nk-by-nd.  
%Note, the rows and columns  of q indicate respectively y_t and k_t and the pages  d_{t+1} (not d_t). 
%tauc capital control tax under continuation, an ny-by-nk-by-nd  matrix. This fiscal instrument is the one that decentralizes the Eaton-Gersovitz model.
%lac, lag, marginal utility of consumption under continuation and good standing, respectively, both  ny-by-nk-by-nd  matrices. 
%Elagp=is the expected value of  next period's marginal utility of consumption,  la_{t+1}, conditional on  continuation in t. 
%This object is useful to cmpute the capital control tax rate, tauc, in period $t$. 
%(c) Mart�n Uribe and Stephanie Schmitt-Groh�,  September 2014. 

clear all

filename = 'egral'
outputloss = 'quadratic';
%Parameterization of 

%Exogenous Process for Traded Endowment: 

load tpmral.mat ygrid pai upai
%created by running tpmral.m in 
%c:\data\uribe\book\sovereign_debt\eg\global_factors
%ygrid = grid of log of  output with associated transition probability matrix pai

load tpmk.mat kgrid paik upaik
%created by running tpmk.m in 
%c:\data\uribe\book\sovereign_debt\eg\global_factors
%kgrid = grid of log of the log of the gross growth rate of global consumption with associated transition probability matrix paik (k is for kernel)

ny = numel(ygrid); 
nk = numel(kgrid); 

%Calibrated Parameters: 

rstar = 0.01;  %quarterly risk-free interest rate (Chatterjee and Eyigungor, AER 2012). 

theta=0.0385; %probability of reentyy (USG  and Chatterjee and Eyigungor, AER 2012). 

sigg = 2; %intertemporal elasticity of consumption substitution 

siggk = 2;%5;

%debt grid
dupper = 1.5;
dlower = 0;
nd =100; % # of grid points for debt 
d = dlower:(dupper-dlower)/(nd-1):dupper;
d = d(:);
 
%force the element closest to zero to be exactly zero
[~,nd0]=min(abs(d)); 
d(nd0) = 0; 

y = repmat(ygrid,[1 nk nd]);
repmat(kgrid',[ny 1 nd]);
kernel1 = exp(ans).^(-siggk);% this is (g_t/gbar)^(-sigma)
y = exp(y);

%Calibrate betak to make the unconditional expectation of the risk-free interest rate equal to rstar (the constant risk-free interest rate assumed in  the baseline model)
ans = zeros(ny,nk,nd);
ans(:,:) = pai*kernel1(:,:);
permute(ans,[2 1 3]);
ans(:,:) = paik*ans(:,:);
permute(ans,[2 1 3]);
%(c_t+1/c_t/G)^(-sigg) where G is the mean of the gross growth rate
ans(:,:,1).^(-1);
kron(upaik,upai)'*ans(:);
bettak = ans/(1+rstar); %growth adjusted discount factor, that is betta* g^(-sigma)

kernel = bettak*kernel1;
clear kernel1;


%Output loss function 
if strcmp(outputloss,'flat')
betta = 0.875;
a0 =    -0.88;%to get E(d/y | good stadning and no default)=  0.5885, which is the value obtained in the baseline case (quadratic loss). Notice that the expectation here is ovr all states (good and bad standing);%-0.969 is the value in Arellano (2008).
a1 = 1;
a2 = 0;
end
if strcmp(outputloss,'quadratic')
betta = 0.85;%discount factor, from Na, Schmitt-Grohe, Uribe, and Yue (2014)
a0 = 0;
a1 = -0.35; 
a2 = (1-a1)/2/max(y(:)); %this makes sure that: (1) the autarkic output is always increasing. (2) the autarkic output has a slope of zero and reaches a maximum at y(end).  This implies an output loss of about 7 percent per period while in default status. 
end

%Output net of outut loss
ya =  y - max(0,a0+ a1*y + a2*y.^2); %the form of the punishment function is taken from Chatterjee and Eyigungor, AER 2012. 
nes = ny*nk; %number of exogenous sates
n = nes*nd; %total number of states 

%Consider an n-by-nd matrix Xtry. Each row of Xtry indicates one of the n possible states and each column indicates a possible value for the debt policy function under continuation. The variable X could be d_t, y_t, d_{t+1}, etc. 

dd = repmat(d,[1 ny nk]);
dd = permute(dd,[2 3 1]);

dtry = repmat(dd(:),1,nd);

dptryix = repmat(1:nd,n,1);
dptry = d(dptryix);

yix = repmat((1:ny)',[1 nk nd]);
kix = repmat(1:nk,[ny 1 nd]);

ytry = repmat(y(:),1,nd);
ktry = repmat(kernel(:),1,nd);

%AUTARKY
%tradable output under autarky
ca = ya; %consumption of tradables under bad standing
ua = ( ca.^(1-sigg)-1)  / (1-sigg); 
laa =  ca.^(-sigg); 

%Initialize q and value functions
q = zeros(ny,nk,nd); 
vc = zeros(ny,nk,nd);  %continue repaying
vcnew = vc;
vg =  zeros(ny,nk,nd); %good standing
vb =  zeros(ny,nk,nd);; %bad standing
vr =  zeros(ny,nk,nd);; %reentry
dpix =  zeros(ny,nk,nd);; 
dpixnew =  zeros(ny,nk,nd);; 

%q(i,j,k)=q(yd_t=yd(i),(ys_t=ys(j), d_t+1=d(k))
%(watch, it's d_t+1 NOT d_t)

f = vc<vb; %default indicator 1 if default, 0 otherwise; f maps (yT_t,d_t)--->{1,0}

q = ones(ny,nk,nd)*bettak;

dist = 1;
while dist>1e-8;

reshape(q,ny*nk,nd);
qtry = repmat(ans,[nd 1]);

ctry =  dptry .* qtry - dtry + ytry;% consumption of tradables

utry = (ctry.^(1-sigg) -1)  / (1-sigg);

utry(ctry<=0) = -inf;

ans = zeros(ny,nk,nd);
ans(:,:) = pai*vg(:,:);
permute(ans,[2 1 3]);
ans(:,:) = paik*ans(:,:);
 permute(ans,[2 1 3]);
reshape(ans,ny*nk,nd);
Evgptry = repmat(ans,[nd 1]);

[vcnew(:), dpixnew(:)] = max(utry+betta*Evgptry,[],2);

ans = theta*vr + (1-theta) * vb;
ans(:,:) = pai*ans(:,:);
permute(ans,[2 1 3]);
ans(:,:) = paik*ans(:,:);
 permute(ans,[2 1 3]);
vbnew = ua+betta*ans;

fnew = vcnew<vbnew; %default indicator 1 if default, 0 otherwise; f maps (yT_t,d_t)--->{1,0}

ans =  (1-fnew).*kernel;
ans(:,:) = pai*ans(:,:);
permute(ans,[2 1 3]);
ans(:,:) = paik*ans(:,:);
qnew =  permute(ans,[2 1 3]);

dist = max(abs(qnew(:)-q(:))) + max(abs(vcnew(:)-vc(:))) + max(abs(vbnew(:)-vb(:))) + max(abs(dpixnew(:)-dpix(:)))   + max(abs(fnew(:)-f(:)))

dpix = dpixnew;
q = qnew;
vc = vcnew;
vb = vbnew;
vg = max(vc,vb);
vr = repmat(vg(:,:,nd0),[1 1 nd]);
f = fnew;
end %while dist>...



%Policy functions under continuation;

%debt choice under continuation
dpc = d(dpix);

%consumption of tradables  under continuation
I = sub2ind([ny nk nd],yix,kix,dpix);
cc = q(I).*dpc+y-dd;
cg = ca.*f + cc.*(1-f); %consumption   under good standing

ans = kernel;
ans(:,:) = pai*ans(:,:);
permute(ans,[2 1 3]);
ans(:,:) = paik*ans(:,:);
 permute(ans,[2 1 3]);
Ekernel = ans(I);
rs = Ekernel.^(-1)-1; %risk free interest rate

%marginal utility of consumption of tradabels under continuation
lac = cc.^(-sigg);

%marginal utility of consumption of tradabels in good standing
lag = f.*laa + (1-f).*lac;

%Elagp=E_tla_{t+1} if continuation in t

ans =  lag;
ans(:,:) = pai*ans(:,:);
permute(ans,[2 1 3]);
ans(:,:) = paik*ans(:,:);
 permute(ans,[2 1 3]);
Elagp =  ans(I);

%capital controls under continuation
betta* Elagp ./ lac ./q(I);
tauc = 1-ans;

%E{I_{t+1}|I_t=1}
II = 1-f;
ans = II;
ans(:,:) = pai*II(:,:);
permute(ans,[2 1 3]);
ans(:,:) = paik*ans(:,:);
 permute(ans,[2 1 3]);
EII = ans(I);

%cov_mI=cov(kernel_t+1,I_t+1|I_t=1)
ans = ((kernel-Ekernel).*(II-EII));
ans(:,:) = pai*ans(:,:);
permute(ans,[2 1 3]);
ans(:,:) = paik*ans(:,:);
 permute(ans,[2 1 3]);
cov_mI = ans(I);

clear ans *try *new *tryix I

eval(['save ' filename num2str(siggk)])