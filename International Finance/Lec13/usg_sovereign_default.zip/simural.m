%simural.m
% produces time series implied by the Eaton-Gersovitz  model with risk averse foreign lenders. The model presentation is in Chapter 11.8, `Risk Averse Lenders,' in the chapter `Sovereign Debt' 
%of Uribe and Schmitt-Grohe, `Open Economy Macroeconomics,' Princeton University Press forthcoming.   
%(c) Mart�n Uribe and Stephanie Schmitt-Groh�,  September 2014. 

clear all, format compact

load egral2.mat 
%load egral5.mat 
%produced by egral.m 

cpai = cumsum(pai,2);
cpaik = cumsum(paik,2);

%Length of simulation and burning period
T = 1e6;
Tburn = 1e5;

Y = zeros(Tburn+T,1);
KERNEL = zeros(Tburn+T,1);
Ytilde = zeros(Tburn+T,1);
YA = zeros(Tburn+T,1);
D = zeros(Tburn+T,1);
C = zeros(Tburn+T,1);
Q = zeros(Tburn+T,1);
F = zeros(Tburn+T,1);
TAU = zeros(Tburn+T,1);
STATE = zeros(Tburn+T,1);
PM = zeros(Tburn+1,1);
RS = zeros(Tburn+1,1);
G = zeros(Tburn+1,1);
PM = zeros(Tburn+1,1);
B = zeros(Tburn+T,1); %B(t)=0==>good standing at the beginning of t. This could happen either because the country ended t-1 in good standing or because of exogenous reentry  at the beginning of t. 
%B(t,1)=1==> bad standing at  the beginning of t. This happens because the country ended t-1 in bad standing and did not get to exogenously reeentry at the beginning of t. 


%Initial conditions
[~,i] = min(abs(ygrid-0)); %position of average domestic. comp. endowment
[~,j] = min(abs(kgrid-0)); %position of average global. comp. endowment
k = nd0; %no external debt
b = 0; %for any t, if b=1==>bad standing at the end of  t-1 and  b=1==>good standing at the end of  t-1

for t=1:T+Tburn

G(t,1) = exp(kgrid(j)); %detrended gross growth rate of foreign consumption, i.e.,  g_t/barg;
F(t,1) = f(i,j,k);
B(t,1) = b;  %this will be corrected later in this program if  the country reentries
D(t,1) = d(k);
Y(t,1) = y(i,j,k);
KERNEL(t,1) = kernel(i,j,k);
YA(t,1) = ya(i,j,k); 
STATE(t,1) = sub2ind([ny nk nd],i,j,k);

if (b==0) & (F(t)==0) ; %gov't chooses to continue 
Ytilde(t,1) = Y(t);
C(t,1) = cc(i,j,k);
Q(t,1) = q(i,j,dpix(i,j,k));
TAU(t,1) = tauc(i,j,k)*100;
kp  = dpix(i,j,k); %update debt state
end % if b==0 & F(t) ==0

if (b==0) & (F(t) ==1); %choose to default
Ytilde(t,1) = YA(t);
C(t,1) = Ytilde(t);
Q(t,1) = 0;
TAU(t,1) = 0;
kp = nd0; 
end % if F(t) ==1 & b==0

rr = rand; %random number  determining reentry if applicable

if (b==1) & (rr>theta);  %==> autarky (bad standing at the beginning of the period and did not get to re-enter)
Ytilde(t,1) = YA(t);
C(t,1) = Ytilde(t);
Q(t,1) = 0;
TAU(t,1) = 0;
kp = nd0; 
end % if (b==1) & (rr>theta);  %==> autarky (bad standing and did not get to re-enter)

if (b==1) & (rr<=theta) ; %reentry after having been in bad standing 
B(t,1) = 0; 
Ytilde(t,1) = Y(t);
C(t,1) = cc(i,j,nd0);
Q(t,1) = q(i,j,dpix(i,j,nd0));
TAU(t,1) = tauc(i,j,nd0)*100;
kp = dpix(i,j,nd0); 
end % if (b==1) & (rr<=theta) ; %reentry after having been in bad standing 

RS(t,1) = (1+rs(i,j,k))^4-1;
R(t,1) = (1/Q(t,1))^4-1; %country interest rate 
PM(t,1) = (R(t,1)-RS(t,1))*100; %country risk premium

find(cpai(i,:)>rand);
i = ans(1);
find(cpaik(j,:)>rand);
j = ans(1);

b = B(t) + F(t); 

k = kp; 

end %for t=1:T+Tburn


STATE = STATE(Tburn+1:end);
Y = Y(Tburn+1:end);
KERNEL = KERNEL(Tburn+1:end);
YA = YA(Tburn+1:end);
Ytilde = Ytilde(Tburn+1:end);
B = B(Tburn+1:end);
D = D(Tburn+1:end);
C = C(Tburn+1:end);
Q = Q(Tburn+1:end);
F = F(Tburn+1:end);
TAU = TAU(Tburn+1:end);
PM = PM(Tburn+1:end);
R = R(Tburn+1:end);
RS = RS(Tburn+1:end);
G = G(Tburn+1:end);



GDP = Ytilde; %GDP in terms of tradables
D_O_GDP = D./(4*GDP); 

for i=1:nd
lad(i,1) = mean(D==d(i));
end

plot(d,lad,'x-' ,'linewidth', 2)
xlabel('d')
ylabel('lad')
shg

eval(['save simural' num2str(siggk) '.mat'])