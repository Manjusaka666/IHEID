%eg_no_exclusion.m
% Use a value-function-iteration procedure to obtain the policy function of  the Eaton and Gersovitz 
%default model under the special case that default does not lead to exclusion from credit markets 
%(although it still entails an output loss). 
%output:
%dpc is the policy function for debt under continuation. It is an ny-by-nd matrix, where ny is the number of  output grid points and nd is the number of debt grid points
%dpix is the policy function for debt under continuation (dpc) but expressed in terms of the index in the debt grid. That is, dpc=d(dpix). 
%vc is the value function under continuation, an ny-by-nd matrix.
%vb value function under bad standing, an ny-by-nd matrix.
%vg value function under good financial standing, an ny-by-nd matrix.
%q price of debt, an ny-by-nd .  Note, the rows of q indicate y_t and the columns d_{t+1} (not d_t). 
%tauc capital control tax under continuation, an ny-by-nd matrix. This fiscal instrument is the one that decentralizes the Eaton-Gersovitz model.
%lac, lag, marginal utility of consumption under continuation and good standing, respectively, both  ny-by-nd matrices. 
%Elagp=is the expected value of  next period's marginal utility of consumption,  la_{t+1}, conditional on  continuation in t. This object is useful to cmpute the capital control tax rate, tauc, in period $t$. 
%(c) Mart�n Uribe and Stephanie Schmitt-Groh�, June 2014. 

clear all

filename = ['eg_no_exclusion']


%Parameterization of 

%Exogenous Process for Endowment: 

load tpm.mat ygrid pai  
%ygrid= vector containing  endowment grid; 
%pai=transition probability matrix of ygrid
%tpm.mat was created by c:\data\uribe\default\eg\data\tpm.m

ny = numel(ygrid), %number of grid points for log of  ouput
y = exp(ygrid(:)); %level of  output

%Calibrated Parameters: 
rstar = 0.01;  %quarterly risk-free interest rate (Chatterjee and Eyigungor, AER 2012). 

theta=0.0385; %probability of reentyy (USG  and Chatterjee and Eyigungor, AER 2012). 

sigg = 2; %intertemporal elasticity of consumption substitution 

betta = 0.85;%discount factor, from Na, Schmitt-Grohe, Uribe, and Yue (2014)

%Output loss function 
a0 = 0;
a1 = -0.35; 
a2 = (1-a1)/2/max(y); %this makes sure that: (1) the autarkic output is always increasing. (2) the autarkic output has a slope of zero and reaches a maximum at y(end).  This implies an output loss of about 7 percent per period while in default status. 

%Output net of outut loss
ytilde =  y - max(0,a0+ a1*y + a2*y.^2); %the form of the punishment function is taken from Chatterjee and Eyigungor, AER 2012. 

%debt grid
dupper = 1.5; %we tried larger grids, but in the end [0,1.5] was fine. 
dlower = 0;
nd =200; % # of grid points for debt 
d = dlower:(dupper-dlower)/(nd-1):dupper;
d = d(:);
 
%force the element closest to zero to be exactly zero
[~,nd0]=min(abs(d)); 
d(nd0) = 0; 

n = ny*nd; %total number of states 

%Consider an n-by-nd matrix Xtry. Each row of Xtry indicates one of the n possible states and each column indicates a possible value for the debt policy function under continuation. 
%The variable X could be d_t, y_t, d_{t+1}, etc. 

dtry = repmat(d',[ny 1  nd]);
dtry = reshape(dtry,n,nd);

dptryix = repmat(1:nd,n,1);
dptry = d(dptryix);

%grid for  output,  y_t
yix = repmat((1:ny)',1,nd);
yT = y(yix);

%grid for y_t try
ytryix = repmat(yix,nd,1);
ytry = y(ytryix);

%BAD STANDING 
% output under bad standing
ytilde = ytilde(yix); 
ybtry = ytilde(ytryix); 

%Initialize the Value functions
%There are 5 value functions: 

%Good standing and continue: 
vgc = zeros(ny,nd);  %continue repaying while in good standing
vgcnew = vgc;

%Bad  standing and continue: 
vbc = zeros(ny,nd);  %continue repaying while in bad standing (just for the case that the country saves)
vbcnew = vbc;

%Value  of default
vd = zeros(ny,nd); 
vdnew = vd;

%value of good standing
vg = zeros(ny,nd); %good standing
vgnew = vg; 

%value of bad standing
vb = zeros(ny,nd); %bad standing
vbnew = vb; 

%policy functions for d(t+1):  
dpgcix = vg; %dp choice in periods of good standing and continue
dpbcix = vg; %dp choice in periods of bad standing and continue
dpdix = vg; %dp choice in periods of default

%Default while in good standing: 
fg = vgc<vd; %default indicator 1 if default, 0 otherwise; f maps (y_t,d_t)--->{1,0}
qg = (1- pai*fg)/(1+rstar);
qb = qg; 
%Default while in bad standing
fb = vbc < vd; 

dpixold = 0;

dist = 1;

while dist>1e-8;

%bond price in good standing
    qgtry = repmat(qg,[nd 1]);

%bond price in bad standing
    qbtry = repmat(qb,[nd 1]);

%good standing and continue
ctry =  ytry + dptry .* qgtry - dtry ;% consumption 
utry = (ctry.^(1-sigg) -1)  / (1-sigg);
utry(ctry<=0) = -inf;
evgptry = pai *  vg;
Evgptry = repmat(evgptry, [nd 1]); 
clear evgptry 

[vgcnew(:), dpgcix(:)] = max(utry+betta*Evgptry,[],2);


%bad standing and continuing: 
cbctry =  ybtry + dptry .* qbtry - dtry  ;% consumption   in bad standing
ubctry = (cbctry.^(1-sigg) -1)  / (1-sigg);
ubctry(cbctry<=0) = -inf;
evbptry = pai*vb; 
Evbptry = repmat(evbptry, [nd 1]);
clear evbptry 
[vbcnew(:), dpbcix(:)] = max(ubctry+betta*theta*Evgptry + betta*(1-theta)* Evbptry,[],2);

%defaulting: 
cdtry =  ybtry + dptry .* qbtry   ;% consumption  in bad standing when defaulting 
udtry = (cdtry.^(1-sigg) -1)  / (1-sigg);
udtry(cdtry<=0) = -inf;
[vdnew(:), dpdix(:)] = max(udtry+betta*theta*Evgptry + betta*(1-theta)* Evbptry,[],2);

%Default decision in bad standing
fbnew = vbcnew < vdnew; 

%Default decision in good standing
fgnew = vgcnew<vdnew; 

%bond price  in good standing and continue
qgnew = (1- pai*fgnew)/(1+rstar);

%bond price when in bad standing (regardless of continue or default)
qbnew = theta*qgnew +(1-theta) *(1-pai*fbnew)/(1+rstar); 

%compute the distance between 2 iterations
dist = max(abs(qgnew(:)-qg(:))) +max(abs(qbnew(:)-qb(:)))+ max(abs(vgcnew(:)-vgc(:))) +max(abs(vbcnew(:)-vbc(:)))+ max(abs(vdnew(:)-vd(:))) + max(abs(dpgcix(:)-dpixold(:)))   + max(abs(fgnew(:)-fg(:))) + max(abs(fbnew(:)-fb(:)))

%update the 3 value functions: 
vgc = reshape(vgcnew,ny,nd);
vbc = reshape(vbcnew,ny,nd);
vd = reshape(vdnew,ny,nd);

%Value in good standing 
vg = max(vgc, vd);

%Value in bad standing 
vb = max(vbc, vd); 

%update the default decisions: 
fg = fgnew; 
fb = fbnew; 

clear fgnew fbnew 

%update the bond price in good standing
qg = qgnew;
qb = qbnew;

%update the 3 policy function for d(t+1)
dpgcix = reshape(dpgcix,ny,nd);
dpbcix = reshape(dpbcix, ny, nd); 
dpdix = reshape(dpdix, ny, nd); 

dpixold = dpgcix;
end %while dist>...


%Policy functions under continuation;

%debt choice under good standing and continuation
dpgc = d(dpgcix);

%debt choice for bad standing and continuation
dpbc = d(dpbcix); 


%debt choice under default
dpd = d(dpdix); 

%consumption under good standing  and continuation
I = sub2ind([ny nd],yix,dpgcix);
cgc = qg(I).*dpgc+yT-repmat(d',ny,1); 


%consumption under bad standing and continuation
I = sub2ind([ny nd],yix,dpbcix);
cbc = qb(I).*dpbc + ytilde -repmat(d',ny,1); 

%consumption under default
I = sub2ind([ny nd],yix,dpdix);
cd = qb(I).*dpd + ytilde ; 

clear ans *try *new *tryix I

eval(['save ' filename ])