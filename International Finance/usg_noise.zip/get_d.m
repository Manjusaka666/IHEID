%get_d.m 
%Produces the matrix D. The first column is the lower bound of a uniform prior distribution and the second column the upper bound.
%This script belongs to a suite of programs that performs a Bayesian estimation of the open economy model with stationary, nonstationary, and noise shocks and imperfect information presented in the book Open Economy Macroeconomics, by Mart�n Uribe and Stephanie Schmitt-Groh� (Princeton University Press) in  the chapter `Business Cycles in Emerging Countries: Productivity Shocks Versus Financial Frictions.'' 
%� M. Uribe and S. Schmitt-Groh�, January 2014. 


D =[    0    0.2000
   -0.9900    0.9900
         0    0.2000
   -0.9900    0.9900
         0    0.2000
   -0.9900    0.9900
         0    8.0000
    0.0001    0.0034
    0.0001    0.0057
    0.0001    0.0145
    0.0001    0.0099];