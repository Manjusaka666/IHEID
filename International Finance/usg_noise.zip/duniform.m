function [y,m,s] = duniform(x,a,b);
%y = duniform(x,a,b) evaluates at x the 
%probability density function of the uniform 
%distribution with lower bound a and upper bound b. 
%[y,m,s] = duniform(x,a,b) produeces the mean and standard deviation. 
%This script belongs to a suite of programs that performs a Bayesian estimation of the open economy model with stationary, nonstationary, and noise shocks and imperfect information presented in the book Open Economy Macroeconomics, by Mart�n Uribe and Stephanie Schmitt-Groh� (Princeton University Press) in  the chapter `Business Cycles in Emerging Countries: Productivity Shocks Versus Financial Frictions.'' 
%� M. Uribe and S. Schmitt-Groh�, January 2014. 


m = (a+b)/2;
s = 1/6*3^(1/2)*(b-a);
y = 1./(b-a) .* (0*x+1);
