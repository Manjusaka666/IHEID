%usg_noise_table_second_moments.m
%produce empirical and theoretical  standard deviations, serial correlations, and correlations with output growth in 
% the  open economy model with stationary, nonstationary, and noise shocks and imperfect information presented in the 
% book Open Economy Macroeconomics, by Mart�n Uribe and Stephanie Schmitt-Groh� (Princeton University Press) in  the chapter 
%`Business Cycles in Emerging Countries: Productivity Shocks Versus Financial Frictions.'' Theoretical second moments are computed at the posterior median of the estimated parameter vector. 
%
%� M. Uribe and S. Schmitt-Groh�, January 2014. 

%� M. Uribe and S. Schmitt-Grohe, January 2014


clc, format compact
clear all 
load usg_noise_bayes median_param Y
%produced by running
%usg_noise_run.m in
%z:\uribe\book\noise_shocks\mfiles

[Hx,Gx, nvarshock, nvarme, nETASHOCK,tby,ALFA, exitflag] = usg_noise_gx_hx_inputs(median_param);

GX = Gx(1:4,:);

%second moments model
 [mstds, mcorrs,mautocorrs] = second_moments(GX,Hx,nvarshock)

table([1 3 5],:) = [100*mstds;mcorrs;mautocorrs];

%second moments data
 [stds, corrs, autocorrs] = second_moments_data(Y);

table([2 4 6],:) = [100*stds;corrs;autocorrs];

first_col = {
'Model';
'Data';
'Model';
'Data';
'Model';
'Data'}

table_tex = tabletex(table,2,1,first_col)