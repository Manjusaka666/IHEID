%usg_noise_var_decomp.m
%Variance decomposition implied by the estimated 
%open economy model with stationary, nonstationary, and noise shocks and imperfect information presented in the book Open Economy Macroeconomics, by Mart�n Uribe and Stephanie Schmitt-Groh� (Princeton University Press) in  the chapter `Business Cycles in Emerging Countries: Productivity Shocks Versus Financial Frictions.'' 
%� M. Uribe and S. Schmitt-Groh�, January 2014. 

clear all  

load usg_noise_bayes.mat median_param
%produced by running 
%usg_noise_run.m  
%z:\uribe\book\noise_shocks\mfiles\files4web

[Hx,Gx, nvarshock, nvarme, nETASHOCK,tby,ALFA, exitflag] = usg_noise_gx_hx_inputs(median_param);

GX = Gx(1:5,:);

[Vy]=variance_decomposition(GX,Hx,nETASHOCK);

first_column = {'Stationary Tech.';
'Nonstationary Tech.'; 'Noise'}
tabletex(Vy*100,1,1,first_column)