% usg_noise_param_estim.m
% Produce a table labeled table1 displaying summary statistics of the prior and posterior distributions of the estimated parameters in 
% the  open economy model with stationary, nonstationary, and noise shocks and imperfect information presented in the 
% book Open Economy Macroeconomics, by Mart�n Uribe and Stephanie Schmitt-Groh� (Princeton University Press) in  the chapter 
%`Business Cycles in Emerging Countries: Productivity Shocks Versus Financial Frictions.'' 
%
%� M. Uribe and S. Schmitt-Groh�, January 2014. 

clear all, clc

load usg_noise_bayes
%produced by running
%usg_noise_run.m in
%z:\uribe\book\noise_shocks\mfiles\files4web

disp('The columns in table1 are: prior lower bound, prior upper bound,  prior mean, posterior mean, posterior median, opsterior 5%, posterior 95%')
table1 = [LB UB (LB+UB)/2 mean_param median(param_chain,2)];

np=size(param_chain,2);
param_chain_sorted = sort(param_chain,2);
p05 =  param_chain_sorted(:,round(0.05*np));
p95 =  param_chain_sorted(:,round(0.95*np));


table1 = [LB UB (LB+UB)/2 mean_param median(param_chain,2) p05 p95]

first_column = {
'$\sigma_x$'
'$\rho_x$'
'$\sigma_z$'
'$\rho_z$'
'$\sigma_n$'
'$\rho_n$'
'$\phi$'
'$\sigma_{g^Y}^{me}$'
'$\sigma_{g^C}^{me}$'
'$\sigma_{g^I}^{me}$'
'$\sigma_{TB/Y}^{me}$'};


%To produce table in LaTeX format
%x = tabletex(table1,2,0,first_column)