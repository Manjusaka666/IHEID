%usg_noise_run.m
%Bayesian estimation of the open economy model with stationary, nonstationary, and noise shocks and imperfect information presented in the book Open Economy Macroeconomics, by Mart�n Uribe and Stephanie Schmitt-Groh� (Princeton University Press) in  the chapter `Business Cycles in Emerging Countries: Productivity Shocks Versus Financial Frictions.'' 
%The main ouput is the chain of posterior draws of the vector of structural parameters. This chain is stored in the file usg_noise_bayes.mat under the name param_chain (see the preamble of the sub-routine usg_noise_bayes.m for more details). 
%Byproducts are the files param0.xls, std_param0.xls, and k.xls, which are used as inputs in usg_noise_bayes.m, these files contain, respectively:
%param0 = initial value of the vector of estimated parameters. 
%std_param0 = matrix such that std_param0*std_param0' is the variance/covariance matrix of the stand-in distribution. 
%k = scale factor of the stand_in distribution calibrated to deliver an acceptance rate of about 35 percent. 
%The algorithm involves running the program 
%usg_noise_bayes1.m twice and the program usg_noise_bayes.m twice as well. 
%After running usg_noise_run.m  it is not necessary to  run usg_noise_bayes.m since
% the output of the latter is a byproduct of the output of the former.  
%Running time:  7 hours in 2014. 
%� M. Uribe and S. Schmitt-Groh�, January 2014. 

clear all, format compact

tar = 0.35; %target acceptance rate (percentage of draws from the stand-in distribution that are rejected)

%Upper and lower bounds of supports of parameter distributions (see usg_noise_bayes.m for what parameter is represented in each row of this matrix). 
get_d
%The last 4 elements of the second column of D  were obtained as std(Y)'*0.25;  This implies that the upper bound of the prior distribution of the standard  deviation of measurement errors is 25 percent of the standard deviation of the observables.  Equivalently, measurement errors are allowed to explain at most 6.25 percent of the variance of the observable. 

LB = D(:,1); %lower bound
UB = D(:,2);%upper bound

param0 =[
   0.001336220704116
   0.974791254814558
   0.021872315770613
   0.668126042268261
   0.002018104702389
   0.980711041302098
   0.536140705993400
   0.003390542713916
   0.005639624911975
   0.014459869768743
   0.009597478355929];

if exist('param0.xls')
!del param0.xls
end
xlswrite('param0.xls',param0);

np = length(param0); %length of parameter vector

k = 0.003; %parameter scaling the variance of the stand-in distribution

%iniital standard deviation of stand-in  distribution
std_param0 =  eye(np); 
if exist('std_param0.xls')
!del std_param0.xls
end
xlswrite('std_param0.xls',std_param0);

disp('running usg_noise_bayes1.m for the first time')
usg_noise_bayes1(std_param0,param0,k,LB,UB,tar);
load usg_noise_bayes1 mean_k 
k= mean_k
if exist('k.xls')
!del k.xls
end
xlswrite('k.xls',k);

disp('running usg_noise_bayes.m for the first time')
usg_noise_bayes
load usg_noise_bayes std_param
std_param0 = std_param;
if exist('std_param0.xls')
!del std_param0.xls
end
xlswrite('std_param0.xls',std_param0);

k = 0.3;
disp('running usg_noise_bayes1.m for the second time')
usg_noise_bayes1(std_param0,param0,k,LB,UB,tar);
load usg_noise_bayes1 mean_k 
k= mean_k
if exist('k.xls')
!del k.xls
end
xlswrite('k.xls',k);

disp('running usg_noise_bayes.m for the second time.')
usg_noise_bayes