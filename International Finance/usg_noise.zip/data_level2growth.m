%data_level2growth.m
%Convert quarterly level data to growth rates. The data is an extract from the 
%file data_q_1101.xls that publicly available with the online materials for the 
%chapter ``A First Look At The Data,'' of the book ``Open Economy 
%Macroeconomics,'' by M. Uribe and S. Schmitt-Grohe.  This program produces a 
%matrix Y with the columns: date,   growth rate of output, growth rate of 
%consumption, growth rate of investment, and trade-balance-to-gdp ratio
%Rows: year/quarter. 
%(c) M. Uribe 2014. 
 
data = xlsread('mexico_data_level.xls');
date = data(1,:)'; %year/quarter
y = data(2,:)'; %real GDP level
si = data(3,:)'; %share investment
sg = data(4,:)'; %share gov't consumption
sm = data(5,:)'; %share imports
sx = data(6,:)'; %share exports
pop = data(7,:)'; %population
sc = data(8,:)'; %share private consumption

%Levels of consumption and investment and trade-balance-to-gdp ratio
c = y.*sc;
i = y.*si;
tby = sx-sm;

%growth rates of gdp, consumption, and investment
gy = diff(log(y));
gc = diff(log(c));
gi = diff(log(i));
tby = tby(2:end);
date = date(2:end);
Y = [date gy gc gi tby];
xlswrite('mexico_data',Y)
