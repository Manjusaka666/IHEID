%usg_noise_impulse responses.m
%produce impulse responses of TFP growth and its ancual and perceived components in the estimated open economy model with stationary, nonstationary, and noise shocks and imperfect information presented in the book Open Economy Macroeconomics, by Mart�n Uribe and Stephanie Schmitt-Groh� (Princeton University Press) in  the chapter `Business Cycles in Emerging Countries: Productivity Shocks Versus Financial Frictions.'' 
%� M. Uribe and S. Schmitt-Groh�, January 2014. 
 
clear all  
clf

load usg_noise_bayes median_param
%produced by running usg_noise_run.m in
%z:\uribe\book\noise_shocks\mfiles

%Compute policy functions
[Hx,Gx, nvarshock, nvarme, nETASHOCK,tby,ALFA, exitflag] = usg_noise_gx_hx_inputs(median_param);

nx = size(Hx,1); %number of states

T=11; %length of impulse responses
t = (0:T-1)';

figure(1)
%Temporary technology shock, z_0=1
x0 = zeros(nx,1);
x0(end-3)=1;
[ans,iry,irx]=ir(Gx,Hx,x0,T) ;
aux = zeros(4,nx);
aux(:,end-3:end) = eye(4);
[ans,irs]=ir(aux,Hx,x0,T) ;
irz = irs(:,1);
irzb = irs(:,2);
irgx = irs(:,3);
irn = irs(:,4);
irEz = iry(:,end-5);
irEzb = iry(:,end-4);
irEgxhat = iry(:,end-3);
irEn = iry(:,end-2);
irghat = iry(:,end-1);
irsig = iry(:,end);


subplot(2,2,1)
plot(t,irghat,'w','linewidth',3);
LEG = legend('$\hat{g}_t$');
set(LEG,'interpreter','latex')
hold on

subplot(2,2,2)
plot(t,irz,'w','linewidth',3);
hold on
plot(t,irEz,'w--','linewidth',3);
LEG =legend('$z_t$','$E_tz_t$')
 set(LEG,'interpreter','latex')

subplot(2,2,3)
plot(t,irEzb,'w--','linewidth',3);
LEG = legend('$E_tz_{t-1}$')
 set(LEG,'interpreter','latex')


subplot(2,2,4)
plot(t,irEgxhat,'w--','linewidth',3);
LEG= legend('$E_t\hat{g}^x_t$')
 set(LEG,'interpreter','latex')


figure(2)
%Permanent technology shock, z_0=1
x0 = zeros(nx,1);
x0(end-1)=1;
[ans,iry,irx]=ir(Gx,Hx,x0,T) ;
aux = zeros(4,nx);
aux(:,end-3:end) = eye(4);
[ans,irs]=ir(aux,Hx,x0,T) ;
irz = irs(:,1);
irzb = irs(:,2);
irgx = irs(:,3);
irn = irs(:,4);
irEz = iry(:,end-5);
irEzb = iry(:,end-4);
irEgxhat = iry(:,end-3);
irEn = iry(:,end-2);
irghat = iry(:,end-1);
irsig = iry(:,end);

subplot(2,2,1)
plot(t,irghat,'w','linewidth',3);
LEG = legend('$\hat{g}_t$')
set(LEG,'interpreter','latex')
hold on

subplot(2,2,2)
plot(t,irEz,'w--','linewidth',3);
LEG = legend('$E_tz_t$')
set(LEG,'interpreter','latex')

subplot(2,2,3)
plot(t,irEzb,'w--','linewidth',3);
LEG = legend('$E_tz_{t-1}$')
set(LEG,'interpreter','latex','location','Southeast')

subplot(2,2,4)
plot(t,irgx,'w','linewidth',3);
hold on
plot(t,irEgxhat,'w--','linewidth',3);
LEG = legend('$\hat{g}^x_t$','$E_t\hat{g}^x_t$')
set(LEG,'interpreter','latex')

figure(3)
%Noise shock, n_0=1
x0 = zeros(nx,1);
x0(end)=1;
[ans,iry,irx]=ir(Gx,Hx,x0,T) ;
aux = zeros(4,nx);
aux(:,end-3:end) = eye(4);
[ans,irs]=ir(aux,Hx,x0,T) ;
irz = irs(:,1);
irzb = irs(:,2);
irgx = irs(:,3);
irn = irs(:,4);
irEz = iry(:,end-5);
irEzb = iry(:,end-4);
irEgxhat = iry(:,end-3);
irEn = iry(:,end-2);
irghat = iry(:,end-1);
irsig = iry(:,end);

subplot(2,2,1)
plot(t,irghat,'w','linewidth',3);
LEG = legend('$\hat{g}_t$')
set(LEG,'interpreter','latex')
hold on

subplot(2,2,2)
plot(t,irEz,'w--','linewidth',3);
LEG = legend('$E_tz_t$')
set(LEG,'interpreter','latex')

subplot(2,2,3)
plot(t,irEzb,'w--','linewidth',3);
LEG = legend('$E_tz_{t-1}$')
set(LEG,'interpreter','latex')

subplot(2,2,4)
plot(t,irEgxhat,'w--','linewidth',3);
LEG = legend('$\hat{g}^x_t$')
set(LEG,'interpreter','latex')

figure(4)
%Permanent technology shock, z_0=1
x0 = zeros(nx,1);
x0(end-1)=1;
[ans,iry,irx]=ir(Gx,Hx,x0,T) ;
aux = zeros(4,nx);
aux(:,end-3:end) = eye(4);
[ans,irs]=ir(aux,Hx,x0,T) ;
irghat = iry(:,end-1);
irgy = iry(:,1);
irY = cumsum(irgy);
irgc = iry(:,2);
irC = cumsum(irgc);

subplot(2,2,1)
plot(t,irY,'w','linewidth',3);
hold on
plot(t,irC,'w--','linewidth',3);
legend('Output', 'Consumption')