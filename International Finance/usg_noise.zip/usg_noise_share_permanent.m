%usg_noise_share_permanent.m computes the noise-to-signal 
%ratio and the  share of the variance of the growth rate of 
%the permanent shock X_t in the variance of the growth rate of TFP. 
%The parameter values come from the Bayesian estimation of  the open economy 
%model with stationary, nonstationary, and noise shocks and imperfect information 
%presented in the book Open Economy Macroeconomics, 
%by Mart�n Uribe and Stephanie Schmitt-Groh� (Princeton University Press) 
%in  the chapter 
%``Business Cycles in Emerging Countries: Productivity Shocks Versus Financial Frictions.'' 
%� M. Uribe and S. Schmitt-Groh�, January 2014. 
clear all, format compact
load usg_noise_bayes median_param
%produced with 
%usg_noise_run.m in 
%z:\uribe\book\noise_shocks\mfiles\
param_estim = median_param;
SIGMAX = param_estim(1);
RHOX = param_estim(2);
SIGMAZ = param_estim(3);
RHOZ = param_estim(4);
SIGMAN = param_estim(5);
RHON = param_estim(6);
PHI = param_estim(7);
STDmey = param_estim(8);
STDmec = param_estim(9);
STDmeiv = param_estim(10);
STDmetby = param_estim(11);

var_perm = SIGMAX^2 / (1-RHOX^2);

var_temp = 2*SIGMAZ^2 / (1+RHOZ);

var_noise = SIGMAN^2 / (1-RHON^2);

share_perm = var_perm/(var_perm+var_temp)

share_noise = var_noise/(var_noise+var_perm)