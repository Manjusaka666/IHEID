%-------------------------------------------
% Housekeeping
%-------------------------------------------

% clear all
restoredefaultpath
setpathdynare4

global oo00_  M00_ M10_  M01_  M11_
global params_labels params
global cof cof10 cof01 cof11 ...
    Jbarmat Jbarmat10 Jbarmat01 Jbarmat11 ...
    Dbarmat10 Dbarmat01 Dbarmat11 ...
    decrulea decruleb
global filtered_errs_switch filtered_errs_init model_temp
global datavec irep xstory fstory

irep=1;
datavec=[]; xstory=[]; fstory=[];


set(0,'DefaultLineLineWidth',2)
format compact




%----------------------------------------------------------------------
% Invoke parameter values
%----------------------------------------------------------------------

paramfile_baby00

BETA1      =0.9922;  
EC         =0.6842; 
EH         =0.8799; 
PHIK       =4.1209;
SIGMA      =0.5013; 
TAYLOR_P   =1.7196; 
TAYLOR_R   =0.5509; 
TAYLOR_Y   =0.0944; 
TETAP      =0.9182; 
TETAW      =0.9163;
RHOD       =0.6945; 
RHO_J      =0.9835;  
RHO_K      =0.7859; 
RHO_R      =0.6232;  
RHO_Z      =0.7556; 
STD_J      =0.0737;   
STD_K      =0.0360;  
STD_P      =0.0030;
STD_R      =0.0013;  
STD_W      =0.0100;  
STD_Z      =0.0163; 
 
ALPHA   =   0.300000;
BETA    =   0.995000;
DK      =   0.025000;
ETA     =   1.000000;
JEI     =   0.040000;
LAGP    =   0.000000;
LAGW    =   0.000000;
M       =   0.900000;
PIBAR   =   1.005000;
RHO_P   =   0.000000;
RHO_W   =   0.000000;
XP_SS   =   1.200000;
XW_SS   =   1.200000;

save  PARAM_EXTRA ...
    ALPHA BETA BETA1 DK EC EH ETA JEI LAGP LAGW M PHIK PIBAR ...
    SIGMA TAYLOR_P TAYLOR_R TAYLOR_Y TETAP TETAW XP_SS XW_SS ...
    RHO_J RHO_K RHO_P RHO_R RHO_W RHO_Z ...
    STD_J STD_K STD_P STD_R STD_W STD_Z RHOD



err_list = char('eps_j','eps_k','eps_p','eps_r','eps_w','eps_z');




%-------------------------------
% Load data and Declare observables
%-------------------------------

load data_est
obs_list = char('data_ctot','data_dp','data_dwtot','data_ik','data_q','data_r');
obs=[ ctot_d(tstar:end) dp_d(tstar:end)-(PIBAR-1) dwtot_d(tstar:end)-(PIBAR-1) ...
    ik_d(tstar:end) q_d(tstar:end) r_d(tstar:end)/400-(PIBAR/BETA-1) ];
save observables obs
tt_obs = tt_d(tstar:end);
rzlb = -(PIBAR/BETA-1);
ntrain = 20;


%-----------------------------------
% Create script to speed up filtering
%-----------------------------------

call_process_mod_files







%-----------------------------------
% Evaluate model's posterior at the parameter values specified above
%-----------------------------------
filtered_errs_init = zeros(size(obs,1),size(err_list,1));

[filtered_errs resids Emat requalzero ] = myfilterzlbrnot(constraint1_difference, constraint2_difference,...
        constraint_relax1_difference, constraint_relax2_difference,err_list,obs_list,obs,rzlb);
  




%------------------------------------------
% Feed filtered shocks back into model
% -- add observation block in model, check that final_samples matches obs
%------------------------------------------

init0=zeros(M00_.endo_nbr,1);


sample_length = size(obs,1);




[zdatal zdatap zdatass oo00_ M00_ ] = solve_two_constraints_fast2_temp1(...
  modnam_00,modnam_10,modnam_01,modnam_11,...
  constraint1, constraint2,...
  constraint_relax1, constraint_relax2,...
  filtered_errs,err_list,sample_length,curb_retrench,maxiter,init0);

tt_obs2=[tt_obs];

for i=1:M00_.endo_nbr
  eval([deblank(M00_.endo_names(i,:)),'_l=zdatal(1:sample_length,i);']);
  eval([deblank(M00_.endo_names(i,:)),'_p=zdatap(1:sample_length,i);']);
  eval([deblank(M00_.endo_names(i,:)),'_ss=zdatass(i);']);
end


% Plots actual data vs model simulations given filtered shocks
figure
final_sample = [];
for index=1:size(obs_list,1)
  subplot(3,3,index)
  eval([ 'final_sample(:,index) = ' deblank(obs_list(index,:)) '_p;'])
  plot(tt_obs,obs(:,index)); hold on
  plot(tt_obs2,eval([deblank(obs_list(index,:)) '_p']),'r')
  axis tight
  title(obs_list(index,:))
end
legend('data','model')
subtitle('Filtered Data vs Model')

% Plots estimated shocks
figure
for index=1:size(err_list,1)
  subplot(3,3,index)
  plot(tt_obs,filtered_errs(:,index)); hold on
  axis tight
  title(err_list(index,:))
end
subtitle('Estimated Shocks')


display('The magnitude of the largest difference between the original sample and the synthetic sample is:')
max(max(abs(final_sample-obs)))

































