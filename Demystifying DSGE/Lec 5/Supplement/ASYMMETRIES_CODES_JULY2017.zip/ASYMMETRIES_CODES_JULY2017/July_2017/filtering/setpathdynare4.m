% uncomment a location below -- adapt to local installation


restoredefaultpath

addpath('C:\Dropbox\E\dynare\4.3.1\matlab')
addpath('toolkit_files');
addpath('filtering_functions')


