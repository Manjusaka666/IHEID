
function [ys,check]=baby00_steadystate(junk,ys);

global M_

paramfile_baby00

nparams = size(M_.param_names,1);
for icount = 1:nparams
    eval(['M_.params(icount) = ',M_.param_names(icount,:),';'])
end

check = 0;

r = PIBAR / BETA ;
rk = 1/BETA - (1-DK) ;
xp = XP_SS ;
xw = XW_SS ;
xw1 = XW_SS ;
lm = (1 - BETA1/BETA) / (1 - BETA1*RHOD/PIBAR) ;

QHTOC = JEI/(1-BETA);
QH1TOC1 = JEI/(1-BETA1-lm*(1-RHOD)*M);
KTOY = ALPHA/(xp*rk);
BTOQH1 = M*(1-RHOD)/(1-RHOD/PIBAR) ;
C1TOY = (1-ALPHA)*SIGMA/(1+(1/BETA-1)*BTOQH1*QH1TOC1)*(1/xp) ;
CTOY = (1-C1TOY-DK*KTOY) ;

n = ((1-SIGMA)*(1-ALPHA)/(xp*xw*CTOY))^(1/(1+ETA));
n1 = (SIGMA*(1-ALPHA)/(xp*xw1*C1TOY))^(1/(1+ETA));

y = KTOY^(ALPHA/(1-ALPHA))*(n^(1-SIGMA))*n1^SIGMA ;

c = CTOY*y;
c1 = C1TOY*y;
k = KTOY*y;
ik = DK*k;

w = xw*c*n^ETA;
w1 = xw1*c1*n1^ETA;
q = QHTOC*c + QH1TOC1*c1 ;
h = QHTOC*c/q ;
h1 = QH1TOC1*c1/q ;
b = BTOQH1*q*h1 ;
uc = 1/c;
uc1 = 1/c1;
uh = JEI/h;
uh1 = JEI/h1;
un = n^ETA ;
un1 = n1^ETA ;
dp = PIBAR ;
dp1 = dp;
dp2 = dp;
dp3 = dp;
dw = PIBAR ;
dw1 = PIBAR ;
aa = 1;
af=1;
aj = 1 ;
am = 1;
arr =1;
az = 1;
ak=1;
ap=1;
aw=1;
an=1;

qk = 1;
rnot = r;

lev = b/(q*h1);
bnot = b;
maxlev = 0;


data_ctot = 0 ;
data_ik = 0;   
data_q = 0;
data_r = 0; 
data_rnot = 0;
data_dp = 0 ;
data_dwtot =0;
data_ntot=0;
  
z_j=0;
  

ys = [ 
aj
ak
ap
arr
aw
az
b    
bnot
c    
c1
data_ctot
data_dp
data_dwtot
data_ik  
data_ntot
data_q
data_r
data_rnot
dp 
dp1
dp2
dp3
dw
dw1
h1
ik
k
lm
maxlev
n    
n1  
q    
qk
r    
rk
rnot
uc   
uc1  
uh
uh1
w    
w1   
xp   
xw   
xw1  
y 
z_j ];


