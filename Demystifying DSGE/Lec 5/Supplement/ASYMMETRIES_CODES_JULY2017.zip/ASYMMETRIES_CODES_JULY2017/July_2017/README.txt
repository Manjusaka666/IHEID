---------------------------------------
The folder REPLICATION_FIGURE2_BASIC contains files to reproduce
Figure 2 in the paper. Launch 
1. run_houseprice1.m in the folder

-----------------------------------------
The folder REPLICATION_FIGURE3_4 contains files to reproduce
Figures 3 and 4 in the paper. These codes also use Dynare 4.3.1
which can be downloaded from Dynare's website.
1.runsim_plot_figure3: the title says it all
2.runsim_plot_figure4: the title says it all

------------------------------------------
The folder FILTERING contains files to filter the shocks based on
the model's estimated parameters. Call 
1. runsim_filter.m to extract the shocks

------------------------------------------
The folder ESTIMATION contains files to either maximize posterior or to run the mh algorithm. Call 
1. runsim_estimation.m (method: fminsearch) to maximize the posterior
2. runsim_metropolis.m to run the MH algorithm after estimation (saves every 100 draws)
3. runsim_decomposition.m to do decompositions, IRF, counterfactuals...
4. check_metropolis.m to see intermediate or final results of MH algorithm (up to the latest # of draws saved)
The mode calculated after maximizing the posterior is close to the mode in the published version of the paper.

