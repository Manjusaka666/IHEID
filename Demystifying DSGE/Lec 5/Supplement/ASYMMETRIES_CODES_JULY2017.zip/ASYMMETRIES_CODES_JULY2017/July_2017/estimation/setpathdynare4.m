% uncomment a location below -- adapt to local installation


restoredefaultpath

addpath('C:\Dropbox\E\Consumption\Replication_Estimation_Web\July_2017\dynare\4.3.1\matlab')
addpath('toolkit_files');
addpath('estimation_functions')

dynare_config
