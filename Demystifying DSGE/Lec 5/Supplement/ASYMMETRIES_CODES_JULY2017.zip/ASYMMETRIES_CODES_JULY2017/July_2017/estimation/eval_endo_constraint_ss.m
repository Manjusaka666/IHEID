lm_ss=oo00_.dr.ys(23);
maxlev_ss=oo00_.dr.ys(24);
r_ss=oo00_.dr.ys(27);
rnot_ss=oo00_.dr.ys(28);
