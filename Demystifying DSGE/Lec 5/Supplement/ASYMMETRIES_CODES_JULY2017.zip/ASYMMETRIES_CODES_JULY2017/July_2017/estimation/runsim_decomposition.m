%-------------------------------------------
% Housekeeping
%-------------------------------------------
clear all
restoredefaultpath
setpathdynare4
set(0,'DefaultLineLineWidth',2)
format compact

global oo00_  M00_ M10_  M01_  M11_
global params_labels params
global cof cof10 cof01 cof11 ...
    Jbarmat Jbarmat10 Jbarmat01 Jbarmat11 ...
    Dbarmat10 Dbarmat01 Dbarmat11 ...
    decrulea decruleb
global filtered_errs_switch filtered_errs_init model_temp
global datavec irep xstory fstory




%-------------------------------
% Load estimated stuff needed to compile model
%-------------------------------
load mle_estimates_fminsearch.mat


%-------------------------------
% Overwrite calibrated and estimated parameters if needed
%-------------------------------
ALPHA   =   0.300000;
BETA    =   0.995000;
DK      =   0.025000;
ETA     =   1.000000;
JEI     =   0.040000;
LAGP    =   0.000000;
LAGW    =   0.000000;
M       =   0.900000;
PIBAR   =   1.005000;
RHO_P   =   0.000000;
RHO_W   =   0.000000;
XP_SS   =   1.200000;
XW_SS   =   1.200000;

BETA1      = 0.9912;    
EC         = 0.6653;    
EH         = 0.7793;    
PHIK       = 4.2730;    
SIGMA      = 0.4290;    
TAYLOR_P   = 1.7844;    
TAYLOR_R   = 0.5322;    
TAYLOR_Y   = 0.0937;    
TETAP      = 0.9175;    
TETAW      = 0.9078;    
RHOD       = 0.5685;    
RHO_J      = 0.9821;    
RHO_K      = 0.7647;   
RHO_R      = 0.6271;    
RHO_Z      = 0.7599;    
STD_J      = 0.0837;    
STD_K      = 0.0385;    
STD_P      = 0.0030;    
STD_R      = 0.0013;    
STD_W      = 0.0102;    
STD_Z      = 0.0154;    

save  PARAM_EXTRA_CALIBRATED ...
  ALPHA BETA BETA1 DK EC EH ETA JEI LAGP LAGW M PHIK PIBAR ...
  SIGMA TAYLOR_P TAYLOR_R TAYLOR_Y TETAP TETAW XP_SS XW_SS ...
  RHO_J RHO_K RHO_P RHO_R RHO_W RHO_Z ...
  STD_J STD_K STD_P STD_R STD_W STD_Z RHOD

XX = [ ];
save PARAM_EXTRA_BABY XX



%-------------------------------
% Load data and Declare observables
% Create script to speed up filtering
%-------------------------------

err_list = char('eps_j','eps_k','eps_p','eps_r','eps_w','eps_z');
load data_est
obs_list = char('data_ctot','data_dp','data_dwtot','data_ik','data_q','data_r');
obs=[ ctot_d(tstar:end) dp_d(tstar:end)-(PIBAR-1) dwtot_d(tstar:end)-(PIBAR-1) ...
    ik_d(tstar:end) q_d(tstar:end) r_d(tstar:end)/400-(PIBAR/BETA-1) ];
save observables obs
tt_obs = tt_d(tstar:end);
rzlb = -(PIBAR/BETA-1);
ntrain = 20;

call_process_mod_files







%-----------------------------------
% Filter shocks at the parameter values specified above
%-----------------------------------
filtered_errs_init = zeros(size(obs,1),size(err_list,1));

[filtered_errs resids Emat requalzero ] = myfilterzlbrnot(constraint1_difference, constraint2_difference,...
        constraint_relax1_difference, constraint_relax2_difference,err_list,obs_list,obs,rzlb);
  

%------------------------------------------
% Feed filtered shocks back into model
%------------------------------------------
% filtered_errs(:,[2:6])=0;



[zdatal zdatap zdatass oo00_ M00_ ] = solve_two_constraints_fast2_temp1(...
  modnam_00,modnam_10,modnam_01,modnam_11,...
  constraint1, constraint2,...
  constraint_relax1, constraint_relax2,...
  filtered_errs,err_list,size(obs,1),curb_retrench,maxiter,zeros(M00_.endo_nbr,1));


for i=1:M00_.endo_nbr
  eval([deblank(M00_.endo_names(i,:)),'_l=zdatal(:,i);']);
  eval([deblank(M00_.endo_names(i,:)),'_p=zdatap(:,i);']);
  eval([deblank(M00_.endo_names(i,:)),'_ss=zdatass(i);']);
end



figure
final_sample = [];
for index=1:size(obs_list,1)
  subplot(3,3,index)
  eval([ 'final_sample(:,index) = ' deblank(obs_list(index,:)) '_p;'])
  plot(tt_obs,obs(:,index)); hold on
  plot(tt_obs,eval([deblank(obs_list(index,:)) '_p']),'r')
  axis tight
  title(obs_list(index,:))
end
legend('data','model')




