%-------------------------------------------
% Housekeeping
%-------------------------------------------

clear all 
global oo00_  M00_ M10_  M01_  M11_ params_labels params

global cof cof10 cof01 cof11 Jbarmat Jbarmat10 Jbarmat01 Jbarmat11 ...
  Dbarmat10 Dbarmat01 Dbarmat11 decrulea decruleb

global filtered_errs_switch filtered_errs_init model_temp datavec irep xstory fstory

setpathdynare4
irep=1; datavec=[]; xstory=[]; fstory=[];

set(0,'DefaultLineLineWidth',2)
randn('seed',1);
format compact
filtered_errs_switch=0;


%----------------------------------------------------------------------
% Invoke calibrated parameters 
%----------------------------------------------------------------------

paramfile_baby00

LAGP = 0;
LAGW = 0;
RHO_P = 0.0000  ;
RHO_W = 0.0000  ;

ALPHA = 0.3;
BETA = 0.995 ; 
DK = 0.025;
ETA	= 1 ;
JEI = 0.04 ;
M = 0.9 ;
PIBAR = 1.005 ;
XP_SS = 1.2 ;
XW_SS = 1.2 ;
EH = 0.9;


BETA1      = 0.9924;   
EC         = 0.6352;   
PHIK       = 5.9425;   
SIGMA      = 0.4854;   
TAYLOR_P   = 1.7881;   
TAYLOR_R   = 0.5469;   
TAYLOR_Y   = 0.0926;   
TETAP      = 0.9226;   
TETAW      = 0.9191;   
RHOD       = 0.5623;   
RHO_J      = 0.9934;   
RHO_K      = 0.7728;   
RHO_R      = 0.6825;   
RHO_Z      = 0.7914;   
STD_J      = 0.0454;   
STD_K      = 0.0488;   
STD_P      = 0.0030;   
STD_R      = 0.0013;   
STD_W      = 0.0100;   
STD_Z      = 0.0146;

save  PARAM_EXTRA_CALIBRATED ...
  ALPHA BETA BETA1 DK EC EH ETA JEI LAGP LAGW M PHIK PIBAR ...
  SIGMA TAYLOR_P TAYLOR_R TAYLOR_Y TETAP TETAW XP_SS XW_SS ...
  RHO_J RHO_K RHO_P RHO_R RHO_W RHO_Z ...
  STD_J STD_K STD_P STD_R STD_W STD_Z RHOD


% params_matrix = {  ...
%   'BETA1 '    0.9921839201   0.9000      0.9940     1     'BETA_PDF'  0.8743  0.025^2
%   'EC '       0.6841541964   0.0001 	 0.9999     1     'BETA_PDF'  0.7 0.10
%   'EH '       0.8797126240   0.0001 	 0.9999     1     'BETA_PDF'  0.7 0.10
%   'PHIK '     4.1183992782   0.0001 	50.0000     1     'GAMMA_PDF' 5 2
%   'SIGMA '    0.5013055409   0.0001 	 0.9900     1     'BETA_PDF'  0.333 0.20
%   'TAYLOR_P ' 1.7189450565   1.0000 	 5.0000     1     'NORMAL_PDF' 1.5 0.25
%   'TAYLOR_R ' 0.5507879737   0.0000 	 0.9500     1     'BETA_PDF'   0.75 0.1
%   'TAYLOR_Y ' 0.0943468303   0.0000  	 0.5000     1     'NORMAL_PDF' 0.125 0.025
%   'TETAP '    0.9181916263   0.1000 	 0.9900     1     'BETA_PDF'   0.5 0.075
%   'TETAW '    0.9162672537   0.1000 	 0.9900     1     'BETA_PDF'   0.5 0.075
%   'RHOD '     0.6943692127   0.0000  	 0.9990     1     'BETA_PDF'  0.75 0.10
%   'RHO_J '    0.9834830207   0.0000  	 0.9990     1     'BETA_PDF'  0.75 0.10
%   'RHO_K '    0.7858728368   0.0000  	 0.9990     1     'BETA_PDF'  0.75 0.10 
%   'RHO_R '    0.6231982784   0.0000  	 0.9990     1     'BETA_PDF'  0.5 0.10 
%   'RHO_Z '    0.7555151295   0.0000  	 0.9990     1     'BETA_PDF'      0.75 0.10
%   'STD_J '    0.0736513752   0.0001  	 0.9999     1     'INV_GAMMA_PDF' 0.01 1
%   'STD_K '    0.0360138807   0.0001  	 0.9999     1     'INV_GAMMA_PDF' 0.01 1
%   'STD_P '    0.0029662412   0.0001  	 0.9999     1     'INV_GAMMA_PDF' 0.01 1
%   'STD_R '    0.0013157506   0.0001  	 0.9999     1     'INV_GAMMA_PDF' 0.01 1
%   'STD_W '    0.0099675399   0.0001  	 0.9999     1     'INV_GAMMA_PDF' 0.01 1
%   'STD_Z '    0.0163342315   0.0001  	 0.9999     1     'INV_GAMMA_PDF' 0.01 1     } ;   

params_matrix = {  ...
  'BETA1 '    0.9925    0.9000      0.9940     1     'BETA_PDF'      0.8743 0.025^2
  'EC '       0.6       0.0001      0.9999     1     'BETA_PDF'      0.7    0.10
  'EH '       0.8       0.0001      0.9999     1     'BETA_PDF'      0.7    0.10
  'PHIK '     4.0       0.0001     50.0000     1     'GAMMA_PDF'     5      2
  'SIGMA '    0.5       0.0001      0.9900     1     'BETA_PDF'      0.333  0.20
  'TAYLOR_P ' 1.7       1.0000      5.0000     1     'NORMAL_PDF'    1.5    0.25
  'TAYLOR_R ' 0.5       0.0000      0.9500     1     'BETA_PDF'      0.75   0.1
  'TAYLOR_Y ' 0.1       0.0000      0.5000     1     'NORMAL_PDF'    0.125  0.025
  'TETAP '    0.92  	0.1000      0.9900     1     'BETA_PDF'      0.5    0.075
  'TETAW '    0.92      0.1000   	0.9900     1     'BETA_PDF'      0.5    0.075
  'RHOD '     0.40      0.0000  	0.9990     1     'BETA_PDF'      0.75   0.10
  'RHO_J '    0.98      0.0000  	0.9990     1     'BETA_PDF'      0.75   0.10
  'RHO_K '    0.8       0.0000  	0.9990     1     'BETA_PDF'      0.75   0.10 
  'RHO_R '    0.6       0.0000      0.9990     1     'BETA_PDF'      0.5    0.10 
  'RHO_Z '    0.7       0.0000  	0.9990     1     'BETA_PDF'      0.75   0.10
  'STD_J '    0.08      0.0001  	0.9999     1     'INV_GAMMA_PDF' 0.01   1
  'STD_K '    0.04      0.0001   	0.9999     1     'INV_GAMMA_PDF' 0.01   1
  'STD_P '    0.003     0.0001  	0.9999     1     'INV_GAMMA_PDF' 0.01   1
  'STD_R '    0.001     0.0001  	0.9999     1     'INV_GAMMA_PDF' 0.01   1
  'STD_W '    0.010     0.0001  	0.9999     1     'INV_GAMMA_PDF' 0.01   1
  'STD_Z '    0.016     0.0001  	0.9999     1     'INV_GAMMA_PDF' 0.01   1     } ;   


save params_matrix params_matrix



err_list = char('eps_j','eps_k','eps_p','eps_r','eps_w','eps_z');

H0 = diag(cell2mat(params_matrix(:,5)).^2) ;

params_labels = params_matrix(:,1);
params0 =   cell2mat(params_matrix(:,2));
params_lo = cell2mat(params_matrix(:,3));
params_hi = cell2mat(params_matrix(:,4));
params_mean = cell2mat(params_matrix(:,7));
params_std = cell2mat(params_matrix(:,8));

dist_names = params_matrix(:,6);
codes = dist_names2codes(dist_names);
[p6 p7] = get_dist_inputs(codes,params_mean,params_std);




for i=1:numel(params_labels)
  evalc([ cell2mat(params_labels(i)) '= params0(' num2str(i) ')']) ;
end






%-------------------------------
% Load data and Declare observables
%-------------------------------
 
load data_est
obs_list = char('data_ctot','data_dp','data_dwtot','data_ik','data_q','data_r');
  obs=[ ctot_d(tstar:end) dp_d(tstar:end)-(PIBAR-1) dwtot_d(tstar:end)-(PIBAR-1) ...
    ik_d(tstar:end) q_d(tstar:end) r_d(tstar:end)/400-(PIBAR/BETA-1) ];
save observables obs
tt_obs = tt_d(tstar:end);
rzlb = -(PIBAR/BETA-1);
ntrain = 20;


%-----------------------------------
% Create script to speed up filtering
%-----------------------------------

modnam_00 = 'minibaby00'; % base model (constraint 1 and 2 below don't bind)
modnam_10 = 'minibaby10'; % first constraint is true
modnam_01 = 'minibaby01'; % second constraint is true
modnam_11 = 'minibaby11'; % both constraints bind
constraint1 = 'lm<-lm_ss';
constraint_relax1 = 'maxlev > 0';
constraint2 = 'rnot < -log(r_ss)';
constraint_relax2 = 'r > -log(r_ss)';

call_process_mod_files


% method = 'initial_check'
  method = 'fminsearch'



if strmatch(method,'initial_check')==1
  
%-----------------------------------
% Check value of the likelihood at the initial guess
%-----------------------------------


  [posterior filtered_errs like prior resids ]=...
   posteriorzlb(params0,params_labels,params_lo,params_hi,...
   modnam_00,modnam_10,modnam_01,modnam_11,...
   constraint1_difference, constraint2_difference,...
   constraint_relax1_difference, constraint_relax2_difference,...
   err_list,obs_list,obs,ntrain,rzlb, codes, p6, p7);

  params=params0;
  sample_length = size(obs,1);
      
  save mle_initial_guess

  

end      












if strmatch(method,'fminsearch')==1
  
  tolerance = 1e-5;
  options = optimset('Display','Iter','TolFun',tolerance,'TolX',tolerance,'TolFun',tolerance,...
    'MaxFunEvals',10000,'MaxIter',500,...
    'DiffMinChange',tolerance,'Algorithm','Interior-Point'); 
  
  [params,fval]=fminsearchbnd(@(current_params) posteriorzlb...
    (current_params,params_labels,params_lo,params_hi,...
    modnam_00,modnam_10,modnam_01,modnam_11,...
    constraint1_difference, constraint2_difference,...
    constraint_relax1_difference, constraint_relax2_difference,...
    err_list,obs_list,obs,ntrain,rzlb,codes,p6,p7),params0,params_lo,params_hi,options);
  
  params0 = params;
  params1 = params;
  
  [posterior filtered_errs like prior] = ...
    posteriorzlb(params1,params_labels,params_lo,params_hi,...
    modnam_00,modnam_10,modnam_01,modnam_11,...
    constraint1_difference, constraint2_difference,...
    constraint_relax1_difference, constraint_relax2_difference,...
    err_list,obs_list,obs,ntrain,rzlb,codes,p6,p7);

  
  params1=params;
 [ hessian_reg stdh_reg hessian_fmin stdh_fmin ] = compute_hessian(xstory,fstory,30);

  save mle_estimates_fminsearch 

  
end



  
