%------------------------------------------
% Feed filtered shocks back into model
% -- add observation block in model, check that final_samples matches obs
%------------------------------------------

init0=zeros(M00_.endo_nbr,1);


sample_length = size(obs,1);
load PARAM_EXTRA_CALIBRATED
for i=1:numel(params_labels)
  evalc([ cell2mat(params_labels(i)) '= params0(' num2str(i) ')']) ;
end
eval([ 'save PARAM_EXTRA_BABY ' cell2mat(params_labels') ]);







[zdatal zdatap zdatass oo00_ M00_ ] = solve_two_constraints_fast2_temp1(...
  modnam_00,modnam_10,modnam_01,modnam_11,...
  constraint1, constraint2,...
  constraint_relax1, constraint_relax2,...
  filtered_errs,err_list,sample_length,curb_retrench,maxiter,init0);
tt_obs2=[tt_obs];

for i=1:M00_.endo_nbr
  eval([deblank(M00_.endo_names(i,:)),'_l=zdatal(1:sample_length,i);']);
  eval([deblank(M00_.endo_names(i,:)),'_p=zdatap(1:sample_length,i);']);
  eval([deblank(M00_.endo_names(i,:)),'_ss=zdatass(i);']);
end


% Plots actual data vs model simulations given filtered shocks
figure
final_sample = [];
for index=1:size(obs_list,1)
  subplot(3,3,index)
  eval([ 'final_sample(:,index) = ' deblank(obs_list(index,:)) '_p;'])
  plot(tt_obs,obs(:,index)); hold on
  plot(tt_obs2,eval([deblank(obs_list(index,:)) '_p']),'r')
  axis tight
  title(obs_list(index,:))
end
legend('data','model')

% Plots estimated shocks
figure
for index=1:size(err_list,1)
  subplot(3,3,index)
  plot(tt_obs,filtered_errs(:,index)); hold on
  axis tight
  title(err_list(index,:))
end



display('The magnitude of the largest difference between the original sample and the synthetic sample is:')
max(max(abs(final_sample-obs)))

