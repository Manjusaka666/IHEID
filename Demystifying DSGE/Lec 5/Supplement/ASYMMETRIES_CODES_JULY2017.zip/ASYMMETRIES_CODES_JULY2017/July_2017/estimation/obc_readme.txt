//% OBC 00
b = bnot;
bnot = M*q*h1 ;
maxlev = b-bnot;
log(r) = log(rnot) ;


//% OBC 01
b = bnot;
bnot = M*q*h1 ;
maxlev = b-bnot;
log(r) = 0 ;


//% OBC 10
lm=0;
bnot = M*q*h1 ;
maxlev = b-bnot;
log(r) = log(rnot) ;


//% OBC 11
lm=0;
bnot = M*q*h1 ;
maxlev = b-bnot;
log(r) = 0 ;


