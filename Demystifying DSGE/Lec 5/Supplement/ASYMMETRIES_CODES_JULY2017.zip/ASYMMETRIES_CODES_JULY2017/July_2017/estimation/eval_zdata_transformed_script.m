zdatal(:,14)=exp(zdatal(:,14))-1;
zdatap(:,14)=exp(zdatap(:,14))-1;
zdatal(:,15)=exp(zdatal(:,15))-1;
zdatap(:,15)=exp(zdatap(:,15))-1;
