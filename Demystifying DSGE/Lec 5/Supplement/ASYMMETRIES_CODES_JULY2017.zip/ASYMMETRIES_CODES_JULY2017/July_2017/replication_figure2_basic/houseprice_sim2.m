% HD_SIM.M : Simulates the economy based on policy functions
% randn('seed',1);


T = 1000;


% Initialiqation of series
clear simB simQ simC simH sQ sB sH 
sQ    = zeros(1,T);
simQ  = 1+zeros(1,T);
simB(1) = bss;
simH(1) = hss;
simC(1) = css;


PSIM=PS;

[ Bm2 Hm2 ] = ndgrid(B,H);

rr=randn(1,T);
 

for t = 2:T
    
	simQ(t) = exp(RHO*log(simQ(t-1)) + SIGMA*rr(t)) ;
    

  
  
  
warning off  
  if nh>1
    simH(t)=lininterpn(Q,B,H,Hdec,simQ(t),simB(t-1),simH(t-1));
    simH(t)=min(simH(t),H(end));
    simH(t)=max(simH(t),H(1));
    simB(t)=lininterpn(Q,B,H,Bdec,simQ(t),simB(t-1),simH(t-1));
    simB(t)=min(simB(t),M*simQ(t)*simH(t));
    simB(t)=min(simB(t),B(end));
    simB(t)=max(simB(t),B(1));
  else
    warning off
    methodnh1='linear';
    simH(t)=H(1);
    simB(t)=lininterpn(Q,B,Bdec,simQ(t),simB(t-1));
    simB(t)=min(simB(t),M*simQ(t)*simH(t));
    simB(t)=min(simB(t),B(end));
    simB(t)=max(simB(t),B(1));
  end
  
  
end



% drop first % observations and calculate simulated series
drop=0;
simC(1)=css;
simC(2:T)= yss - simQ(2:end).*simH(2:end) + simB(2:end) - R*simB(1:end-1) + ...
  (1-DH)*simQ(2:end).*simH(1:end-1) - (simH(2:end)-simH(1:end-1)).^2*COSTH ;
TT = cumsum(ones(1,length(simC))) ;



  
  figure
  subplot(4,1,1)
  plot(TT',simQ','b','Linewidth',2) ;
  axis tight
  set(gca, 'XTick', [])
  legend('q')
  
  subplot(4,1,2)
  plot(TT',simC','b','Linewidth',2) ;
  axis tight
  set(gca, 'XTick', [])
  legend('C')
  
  subplot(4,1,3)
  plot(TT',simB','Linewidth',2) ; hold on
  plot(TT',simB'.^0-1+B(1),'g','Linewidth',1) ; hold on
  plot(TT',simB'.^0-1+B(end),'g','Linewidth',1) ;
  set(gca, 'XTick', [])
  legend('B')
  axis tight
    
  subplot(4,1,4)
  plot(TT',simB'./simH'./simQ','Linewidth',2) ;
  legend('b/(qH)')
  xlabel('Periods')
