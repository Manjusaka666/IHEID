
Bdec = B(idecB(:,:,:)) ;
Hdec = H(idecH(:,:,:)) ;

Cd = max( small_no, yss - Qm.*Hdec + Bdec - R*Bm + (1-DH)*Qm.*Hm - (Hdec-Hm).^2*COSTH) ;

Cd(Bdec>M*Qm.*Hdec) = small_no ;

U =  log(Cd) + JEI*log(Hdec) ;

idecB2=idecB(:);
idecH2=idecH(:);
newV2=newV(:);
EV2=EV(:);

for iHOWARD = 1:nhowards
  
  
  for iq=1:nq
    for ib=1:nb
      for ih=1:nh
        newV(iq,ib,ih) = U(iq,ib,ih) + BETA * EV(iq,idecB(iq,ib,ih),idecH(iq,ib,ih)) ;
      end
    end
  end
   
           
  for ih=1:nh
    EV(:,:,ih)=P*newV(:,:,ih) ;
  end
  

end