clear
close all
tic
warning off
restoredefaultpath

%-----------------------------------------------------
% COMPUTATIONAL ASSUMPTIONS
%-----------------------------------------------------

small_no = 1e-20 ; % A very small number associated with zero consumption.
nhowards=100;
maxdiff=1e-6;


%-----------------------------------------------------
% MODEL PARAMETERS
%-----------------------------------------------------
JEI = 0.12 ;
DH = 0.01 ;
M = 0.9;
RHO=0.96;
SIGMA=0.0175;
BETA=.99; % First agent is impatient
R=1.005;
COSTH=0.0;



% % For paper
% nb = 95;
% nh = 91;
% nq = 71;


% % For paper
 nb = 55;
 nh = 51;
 nq = 31;



[ PS, logQ, probst, alambda, asigmaq ] = markovappr(RHO,SIGMA,3,nq);
Q = exp(logQ) ;


% 1-Steady-state
hss = JEI / ( DH*JEI + (R-1)*JEI*M + (1-BETA*(1-DH)) - (1-BETA*R)*M );
bss = M*hss;
yss = 1 ;
css = yss-(R-1)*bss-DH*hss;

% 2-Grid for h
hmin=0.5*hss;
hmax=1.5*hss;

if nh==1
  hmax=hss;
  hmin=hss;
end

% 3-Grid for b
bmin=0.5*bss ;
bmax=1.5*bss ;

% 4-Create grid
B = linspace(bmin,bmax,nb) ;
H = linspace(hmin,hmax,nh) ;




for stochastic=[1]
  
  disp('Expected time in minutes')
  disp(nb*nh*nq/135/60)
  disp(' ')
  
  if stochastic==0
    P=perfforappr(PS,logQ,RHO);
    PD=P;
  else
    P=PS;
    PD=perfforappr(PS,logQ,RHO);
  end
  
  
  
  
  
  % Meshgrid for the choice variables
  [ BME HME ] = ndgrid(B,H);
  
  % Meshgrid for all states
  [ Qm Bm Hm ] = ndgrid(Q,B,H);
  
  
  V_init=zeros(nq,nb,nh)/(1-BETA);
    
  
  
  %-----------------------------------------------------
  % Initialization of value functions
  %-----------------------------------------------------
  v=ones(nb,nh);
  c=ones(nb,nh)/2;
  
  V = V_init;
  
  %-----------------------------------------------------
  % Iterate on value function until convergence
  %-----------------------------------------------------
  diffV = 1;
  diffidecB = 1;
  diffidecH = 1;
  iter    = 1;
  
  % Initialize choices and value
  newV = zeros(nq,nb,nh);        % new value matrix
  idecB = 1+zeros(nq,nb,nh);       % index to decisions in B grid
  idecH = 1+zeros(nq,nb,nh);       % index to decisions in H grid
  idecB_old = 1+zeros(nq,nb,nh);       % index to decisions in B grid
  idecH_old = 1+zeros(nq,nb,nh);       % index to decisions in H grid
  EV = zeros(nq,nb,nh);
  
  JEI_log_HME = JEI*log(Hm) ;
  
  
  while (iter <= 40) & (diffidecB+diffidecH > 0)
    
    
    % Calculate expected future value
    for ih=1:nh
      EV(:,:,ih)=P*V(:,:,ih) ;
    end
    BETAEVJEIlogHME=BETA*EV+JEI_log_HME;
    
    % For each income realization, c1 is a nbxnh vector
    for ib = 1:nb
      RBB=R*B(ib);
      for ih = 1:nh
        
        if B(ib)<M*max(Q)*H(ih)
          
          
          for iq = 1:nq
            
            
            c = max( small_no, yss + BME - Q(iq)*HME - RBB + Q(iq)*(1-DH)*H(ih) );
            
            c(BME>M*Q(iq)*HME) = small_no ;
            
            BETAEVJEIlogHMEtemp = reshape(BETAEVJEIlogHME(iq,:,:),[nb nh]);
            
            % v = log(c) + JEI_log_HME + BETA*EVtemp ;
            
            v=zeros(nb,nh)-100;
            icpos=find(c>small_no);
            v(icpos)=log(c(icpos))+BETAEVJEIlogHMEtemp(icpos);
            
            % for each H', find B' that maximizes v
            [ v_temp, idecB_temp ] = max ( v ) ;
            
            % find H' that maximizes v, given B'
            [newV(iq,ib,ih), idecH(iq,ib,ih)] = max ( v_temp ) ;
            
            idecB(iq,ib,ih) = idecB_temp(idecH(iq,ib,ih)) ;
            
          end
          
        else
          idecB(1:nq,ib,ih) = 1 ;
          idecH(1:nq,ib,ih) = 1 ;
          newV(1:nq,ib,ih) = NaN ;
          
          
        end
      end
    end
    
    % Do Howard improvement step
    houseprice_hwd
    
    diffidecB = max(abs(idecB_old(:)-idecB(:)));
    diffidecH = max(abs(idecH_old(:)-idecH(:)));
    diffV = max(abs(newV(:)-V(:)));
    
    iter  = iter + 1;
    idecB_old=idecB;
    idecH_old=idecH;
    V     = newV ;
    disp([ diffidecB diffidecH])
    
  end
  
  
  %---------------------------------------------------------------------------
  % "Smooth the policy functions: see script houseprice_interpola for details
  %---------------------------------------------------------------------------
  interpola=3;
  houseprice_interpola
  

  file=mfilename;

  
  %---------------------------------------------------------------------------
  % Run a stochastic simulation of the model
  %---------------------------------------------------------------------------
  houseprice_sim2
    
  %---------------------------------------------------------------------------
  % Plot the policy functions
  %---------------------------------------------------------------------------
  houseprice_plotpolicy

end

toc