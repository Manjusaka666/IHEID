[ Qm Bm Hm ] = ndgrid(Q,B,H);
warning off


% calculate decision rules given indices for decisions
Bdec_old = B(idecB(:,:,:)) ;
Hdec_old = H(idecH(:,:,:)) ;
Cdec_old = max( small_no, yss - Qm.*Hdec_old + Bdec_old - R*Bm + (1-DH)*Qm.*Hm - (Hdec_old-Hm).^2*COSTH) ;
LEVdec_old = Bdec_old./(Qm.*Hdec_old);

Cdec_old(Cdec_old==small_no)=NaN;
Bdec_old(isnan(Cdec_old)==1)=NaN;
Hdec_old(isnan(Cdec_old)==1)=NaN;


Cdec_old(LEVdec_old>M)=NaN;
Bdec_old(LEVdec_old>M)=NaN;
Hdec_old(LEVdec_old>M)=NaN;
LEVdec_old(LEVdec_old>M)=NaN;


if interpola==0
  
  Cdec=Cdec_old;
  Hdec=Hdec_old;
  Bdec=Bdec_old;
  LEVdec=LEVdec_old;

elseif interpola==1
    
    cloess=0.3;
    for iq=1:nq
        for ih=1:nh            
            Hdec(iq,:,ih)=smooth(Hdec_old(iq,:,ih),cloess,'loess');
            Bdec(iq,:,ih)=smooth(Bdec_old(iq,:,ih),cloess,'loess');
        end
    end
    Cdec = max(0.0001,yss - Qm.*Hdec + Bdec - R*Bm + (1-DH)*Qm.*Hm - (Hdec-Hm).^2*COSTH) ;
    Cdec(isnan(Cdec_old)==1)=NaN;
    Cdec(Cdec<0.0001)=NaN;
    Bdec(isnan(Cdec)==1)=NaN;
    Hdec(isnan(Cdec)==1)=NaN;
    LEVdec = Bdec./(Qm.*Hdec);

    

elseif interpola==2
    
    cloess=0.3;
    for ib=1:nb
        for ih=1:nh            
            Hdec(:,ib,ih)=smooth(Hdec_old(:,ib,ih),cloess,'loess');
            Bdec(:,ib,ih)=smooth(Bdec_old(:,ib,ih),cloess,'loess');
        end
    end
    Bdec=min(Bdec,M*Qm.*Hdec);
    Cdec = max(0.0001,yss - Qm.*Hdec + Bdec - R*Bm + (1-DH)*Qm.*Hm - (Hdec-Hm).^2*COSTH) ;
    Cdec(isnan(Cdec_old)==1)=NaN;
    Cdec(Cdec<0.0001)=NaN;
    Bdec(isnan(Cdec)==1)=NaN;
    Hdec(isnan(Cdec)==1)=NaN;
    LEVdec = Bdec./(Qm.*Hdec);

    
elseif interpola==3

    [Bdec,smb]=smoothn(Bdec_old,2);
    [Hdec,smh]=smoothn(Hdec_old,2);
    Bdec(isnan(Bdec_old)==1)=NaN;
    Hdec(isnan(Hdec_old)==1)=NaN;
    Bdec=min(Bdec,M*Qm.*Hdec);
    Cdec = yss - Qm.*Hdec + Bdec - R*Bm + (1-DH)*Qm.*Hm - (Hdec-Hm).^2*COSTH ;
    LEVdec = Bdec./(Qm.*Hdec);

elseif interpola==4

    [Bdec,smb]=smoothn(Bdec_old,4,'gaussian','robust');
    [Hdec,smh]=smoothn(Hdec_old,4,'gaussian','robust');
    Bdec=min(Bdec,M*Qm.*Hdec);
    Cdec = yss - Qm.*Hdec + Bdec - R*Bm + (1-DH)*Qm.*Hm - (Hdec-Hm).^2*COSTH ;
    LEVdec = Bdec./(Qm.*Hdec);
    
end
