% Create grid that gives more mass to simulated points

nbold=nb;
nhold=nh;
Bold=B;
Hold=H;
save oldworkspace


load houseprice4s

clear T
overwrite=0; 
T=2500;
interpola=0;
houseprice_interpola
houseprice_sim2;

bsort=sort(simB);
binsb=floor(T/(nbold*0.8));
nbcenter=round(nbold*0.8);
nbleft=round((nbold-nbcenter)/2);
nbright=nbold-nbleft-nbcenter;
for i=1:nbcenter  
  Bnew(i)=bsort(round(i*binsb));
end
Bstart=linspace(B(1),Bnew(1),nbleft+1);
Bend=linspace(Bnew(end),B(end),nbright+1);
Bnew2 = [ Bstart(1:nbleft) Bnew Bend(2:end) ];
Bnew3 = smooth(Bnew2,20)';


if nh>1
hsort=sort(simH);
binsh=floor(T/(nhold*0.8));
nhcenter=round(nhold*0.8);
nhleft=round((nhold-nhcenter)/2);
nhright=nhold-nhleft-nhcenter;
for i=1:nhcenter  
  Hnew(i)=hsort(round(i*binsh));
end
Hstart=linspace(H(1),Hnew(1),nhleft+1);
Hend=linspace(Hnew(end),H(end),nhright+1);
Hnew2 = [ Hstart(1:nhleft) Hnew Hend(2:end) ];
Hnew3 = smooth(Hnew2,20)';
else
  Hnew3=H;
end


keep Bnew3 Hnew3


load oldworkspace

B = Bnew3;
H = Hnew3;
