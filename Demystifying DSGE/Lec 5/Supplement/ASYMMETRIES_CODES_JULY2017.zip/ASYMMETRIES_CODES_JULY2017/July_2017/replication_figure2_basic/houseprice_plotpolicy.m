indexh=findnearest(hss,H,1);

figure((interpola*10+1))
subplot(3,1,1)
for iq=1:nq
plot(B,squeeze(LEVdec(iq,:,indexh)),'color',[iq/(nq+1) 0*iq/(nq+1) 0*iq/(nq+1)]); hold on
end
xlabel('B')
ylabel('Leverage')

subplot(3,1,2)
for iq=1:nq
plot(B,squeeze(Cdec(iq,:,indexh)),'color',[iq/(nq+1) 0*iq/(nq+1) 0*iq/(nq+1)]); hold on
end
xlabel('B')
ylabel('Cdec')

subplot(3,1,3)
for iq=1:nq
plot(B,squeeze(Bdec(iq,:,indexh)),'color',[iq/(nq+1) 0*iq/(nq+1) 0*iq/(nq+1)]); hold on
end
xlabel('B')
ylabel('Bdec')

if exist('simB')==1
disp('sim B exists, will use it')
indexb1=findnearest(mean(simB)-1.0*std(simB),B,0);
indexb2=findnearest(mean(simB),B,0);
indexb3=findnearest(mean(simB)+1.0*std(simB),B,0);

indexh1=findnearest(mean(simH),H,0);
indexh2=findnearest(mean(simH),H,0);
indexh3=findnearest(mean(simH),H,0);

% to find best index for h, condition on the index for b
% s = regstats(simH,simB,'linear');
%  indexh1=findnearest(s.beta(1)+s.beta(2)*(mean(simB)-2*std(simB)),H,0);
%  indexh2=findnearest(s.beta(1)+s.beta(2)*(mean(simB)),H,0);
%  indexh3=findnearest(s.beta(1)+s.beta(2)*(mean(simB)+2*std(simB)),H,0);



rangeb=[indexb1 indexb2 indexb3 ];
rangeh=[indexh1 indexh2 indexh3 ];
rangeq=round([ 0.4*nq 0.9*nq ]);

figure(gcf+1)
subplot(2,1,1)
lw=1;

for i=1:3
plot(Q(rangeq(1):rangeq(2)),squeeze(LEVdec(rangeq(1):rangeq(2),rangeb(i),rangeh(i))),...
  'color',[rangeb(i)/(nb+1) 0*rangeb(i)/(nb+1) 0*rangeb(i)/(nb+1)],'Linewidth',lw); hold on
lw=lw+1;
end
plot(Q(rangeq(1):rangeq(2)),Q(rangeq(1):rangeq(2)).^0-1+M,'color','b','Linewidth',2); hold on
xlabel('Housing Price')
ylabel('Choice of Leverage')

subplot(2,1,2)
lw=1;
for i=1:3
plot(Q(rangeq(1):rangeq(2)),squeeze(Cdec(rangeq(1):rangeq(2),rangeb(i),rangeh(i))),...
  'color',[rangeb(i)/(nb+1) 0*rangeb(i)/(nb+1) 0*rangeb(i)/(nb+1)],'Linewidth',lw); hold on
lw=lw+1;
end
xlabel('Housing Price')
ylabel('Consumption')

legend('Low debt','Average debt','High Debt')
end
