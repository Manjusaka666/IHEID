
1. runsim_plot_figure3: the title says it all

2. runsim_plot_figure4: the title says it all
