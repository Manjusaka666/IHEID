%% runsim


format short
setpathdynare4
clear
set(0,'DefaultLineLineWidth',2)
opaths=0;plot_irf=0;colors=char('b','r','k');
close all
tlast=2011.875;



imodel=[1 2 3 4 ]; opaths=1; maxindi=1; colorpaths='r.';




load PARAM_EXTRA_CALIBRATED
load mle_estimates_fminsearch params_labels params* filtered_errs sample_length err_list
for i=1:numel(params_labels)
    evalc([ cell2mat(params_labels(i)) '= params1(' num2str(i) ')']) ;
end






save  PARAM_EXTRA ...
    BETA BETA1 EC EH ETA JEI M ALPHA PHIK DK LAGP LAGW PIBAR  ...
    SIGMA TAYLOR_P TAYLOR_R TAYLOR_Y TETAP TETAW XP_SS XW_SS  ...
    RHO_J RHO_K RHO_P RHO_R RHO_W RHO_Z ...
    STD_J STD_K STD_P STD_R STD_W STD_Z RHOD


for model=[imodel]
    
    
    modnam_00 = 'baby00'; % base model (constraint 1 and 2 below don't bind)
    modnam_10 = 'baby10'; % first constraint is true
    modnam_01 = 'baby01'; % second constraint is true
    modnam_11 = 'baby11'; % both constraints bind
    
    % compile constraint
    constraint1 = 'lm<-lm_ss';
    constraint_relax1 = 'maxlev > 0';
    constraint2 = 'rnot < -log(r_ss)';
    constraint_relax2 = 'r > -log(r_ss)';
    
    
    curb_retrench = 0;           % if 1 slow down relaxation of constraints
    maxiter = 10;                % number of iterations allowed to look for a solution
    
%     irfshock =char('eps_j','eps_k','eps_p','eps_r','eps_w','eps_z');
    
    
    
%     sequence1 = [ STD_J STD_K STD_P STD_R STD_W STD_Z ];
%     nperiods = 40;
%     
%     sequence=sequence1; sequence(:,setdiff([1:6],[model]))=0
%     
    sample_length=size(filtered_errs,1);
    yearplot=tlast-(sample_length-1)/4
    if model==1; model2=[1]; end
    if model==2; model2=[1 2]; end
    if model==3; model2=[1 2 3 4 5]; end
    if model==4; model2=[1 2 3 4 5 6]; end
    irfshock = char(err_list(model2,:));
    sequence = filtered_errs(:,model2);
    nperiods=size(filtered_errs,1);
    
    
    
    [zdatal zdatap zdatass oobase_ Mbase_] = solve_two_constraints_fast2_temp1(...
        modnam_00,modnam_10,modnam_01,modnam_11,...
        constraint1, constraint2,...
        constraint_relax1, constraint_relax2,...
        sequence,irfshock,nperiods+50,curb_retrench,maxiter);
    
    
    
    
    for i=1:Mbase_.endo_nbr
        eval([deblank(Mbase_.endo_names(i,:)),'_l=zdatal(1:nperiods,i);']);
        eval([deblank(Mbase_.endo_names(i,:)),'_p=zdatap(1:nperiods,i);']);
        eval([deblank(Mbase_.endo_names(i,:)),'_ss=zdatass(i);']);
    end
    
    for i = 1:size(Mbase_.param_names,1)
        eval([Mbase_.param_names(i,:),'= Mbase_.params(i);']);
    end
    
    ctot_ss = c_ss + c1_ss;
    ctot_l = c_l + c1_l;
    ctot_p = c_p + c1_p;
    levbor_p = (exp(b_p/b_ss)*b_ss)./(exp(q_p/q_ss)*q_ss)./(exp(h1_p/h1_ss)*h1_ss);
    levagg_p = (exp(b_p/b_ss)*b_ss)./(exp(q_p/q_ss)*q_ss);
    levbor_l = (exp(b_l/b_ss)*b_ss)./(exp(q_l/q_ss)*q_ss)./(exp(h1_l/h1_ss)*h1_ss);
    dwtot_p=SIGMA*dw1_p+(1-SIGMA)*dw_p;
    dwtot_l=SIGMA*dw1_l+(1-SIGMA)*dw_l;
    dwtot_ss=SIGMA*dw1_ss+(1-SIGMA)*dw_ss;
    
    
    
    
    line_p(:,:,model)=100*[q_p/q_ss,ctot_p/ctot_ss,4*r_p];
    
    shocks_p(:,:,model)=[exp(aj_p)*JEI exp(ak_p) 400*ap_p 400*arr_p 400*aw_p exp(az_p)];

    shocks_p2(:,:,model)=[sequence(:,end)];
    
    
    
    
    
    
    
    
    load data_est
    
    cmod(:,model)=100*data_ctot_p;
    qmod(:,model)=100*data_q_p;
    cdata=100*ctot_d(tstar:end);
    qdata=100*q_d(tstar:end);
    tt=tt_d(tstar:end);
    
    
    
    
    
    
    
    
end














close all

bars_color1 = ...
    [        0    0.5000         0
    0    0.4100    0.5500
    0.6900    0.8900    1.0000
    0.8000    0.1500    0.1500
    0.9300    0.4600         0
    0.8000    0.8000    0.8000];

sup_title = '';
titlelist = char('House Prices','Consumption');
Tvec = tt_d(tstar);
Tdelta = 1/4;
npers = size(cmod,1)
Tmax = Tvec+npers*Tdelta ;
ylabels = char('%','%');

opts.legendplace = [.4,0,.2,.1];
opts.shading = 1;

tt=tt_d(tstar:end);

legendlist2 =char('Data','Housing Preference','Technology',...
    'Monetary Policy and Price and Wage Shocks','Intertemporal Preference');

bars_color2=[         0    0.5000         0
    0    0.4100    0.5500
    0.6900    0.8900    1.0000
    0.8000    0.1500    0.1500 ];

figure
makebardec4(bars_color2,titlelist,legendlist2,sup_title,Tvec,Tdelta,Tmax,ylabels,opts,...
    [qdata cdata],...
    [qmod(:,1) cmod(:,1)],...
    [qmod(:,2)-qmod(:,1) cmod(:,2)-cmod(:,1)],...
    [qmod(:,3)-qmod(:,2) cmod(:,3)-cmod(:,2)],...
    [qmod(:,4)-qmod(:,3) cmod(:,4)-cmod(:,3)])

for i=1:2
    hold on
    subplot(3,1,1)
    ylim([-40 20])
    hold on
    subplot(3,1,2)
    ylim([-9 6])
end










