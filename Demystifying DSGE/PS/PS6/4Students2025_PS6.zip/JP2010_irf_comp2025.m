%for JP2010 model 
%Comparing IRF under different calibration

load 'J:\...Q3\Output\JP2010_Q3_results';
OOPT.MODELS.oo_EHL = oo_;
load 'J:\...Q6a\Output\JP2010_Q4_results';
OOPT.MODELS.oo_EHL1 = oo_;
load 'J:\...Q6a\Output\JP2010_Q6a_results';
OOPT.MODELS.oo_EHL2 = oo_;
load 'J:\...Q6b\Output\JP2010_Q6b_results';
OOPT.MODELS.oo_EHL3 = oo_;

OOPT.NN=20;
OOPT.plot_color={'b' '--k' 'r' 'g'}
OOPT.shocks_names={'epsilon_cp'};
OOPT.tit_shocks={'MonPol Shock'};
OOPT.type_models={'oo_EHL' 'oo_EHL1' 'oo_EHL2' 'oo_EHL3'};
OOPT.legend_models={'v1','v2','v3','v4'}
OOPT.list_endo={'y' 'c' 'i' 'pi' 'pi_h' 'pi_f' 'e' 'nfa' 'mc'};
OOPT.label_variables={'Output' 'Consumption' 'Investment' 'Inflation' 'Home inflation' 'Foreign inflation' 'Exchange rate' 'Net Foreign Assets' 'Marginal cost'};
plot_comp(OOPT);

