function F = root4d(x)

phicap=1.5;
epsp=10;
alfa=.14;
xiw=   0.82;
xip=   0.77;
sigmal=    4.79;
sigmac=0.97;
theta = 0.135;
ctrend=0.3982;
constebeta=0.23;

gammma=1+ctrend/100 ; 
betta=1/(1+constebeta/100);
betabar=betta*gammma^(-sigmac); 
A = 1/((phicap - 1)*epsp + 1); 

% Let tau1 = x(1), tau2=x(2) lambdacap = x(3) thetacap = x(4)
F(1) = x(1) - (A*(1 - alfa)*((1 - betabar*xip)*xiw)/((1 - betabar*xip*xiw)*(1 + x(4))));
F(2) = x(3) - (((x(1)*betabar*gammma*xiw*theta)/(alfa + (1/sigmal)))*(1 - (xip*(1 - betabar*gammma*xiw)/(1 - betabar*gammma*xip*xiw))));
F(3) = x(2) - (theta*(1 - betabar*gammma*xiw)/((alfa + (1/sigmal))*(1 - betabar*gammma*xip*xiw)*(1 + x(3))));
F(4) = x(4) - (x(2)*(1 - ((1 - betabar*gammma*xip)*xiw))/(1 - betabar*gammma*xip*xiw));
end