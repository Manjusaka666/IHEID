EA_PV16 original model codes were provided by the authors

+ last change: 2019-02-06

+ the IRFs were produced with a shock sequence of an 8 Quarter QE program and a zero lower bound of 8 quarters
	- as the paper does not contain IRFs they are meant to be illustrative.              

+ file to produce IRF: run.m 

+ literature:
	- Romanos Priftis & Lukas Vogel, 2016. "The Portfolio Balance Mechanism and QE in the Euro Area," 
	  Manchester School, vol. 84(S1), pages 84-105.
 
