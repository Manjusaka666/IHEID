EA_PV17 original model codes were provided by the authors

+ last change: 2019-02-06

+ the IRFs were produced with a shock sequence of an 8 Quarter QE program and a zero lower bound of 8 quarters
	- as the paper does not contain IRFs they are meant to be illustrative.              

+ file to produce IRF: run.m 

+ literature:
	- Romanos Priftis & Lukas Vogel, 2017. "The macroeconomic effects of the ECB�s evolving QE programme: 
	 	a model-based analysis," Open Economies Review, vol. 28(5), pages 823-845. 
